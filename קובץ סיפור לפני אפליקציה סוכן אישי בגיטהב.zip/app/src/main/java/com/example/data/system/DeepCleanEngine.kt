package com.example.data.system

import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import com.example.data.model.CleanCandidateItem
import com.example.data.model.CleanItemType
import com.example.data.model.CleanerSafetyTier
import com.example.data.model.DeepCleanExecutionResult
import com.example.data.model.DeepCleanScanResult
import com.example.data.model.FolderScanSummary
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeepCleanEngine(
  private val context: Context,
  private val telemetryProvider: SystemTelemetryProvider
) {

  companion object {
    private const val LARGE_FILE_THRESHOLD_BYTES = 15L * 1024L * 1024L // 15 MB
    private const val MAX_SAF_FILES_TO_SCAN = 1200
    private val TEMP_EXTENSIONS = setOf("tmp", "temp", "log", "bak", "old", "chk", "dmp")
  }

  private data class SafDocEntry(
    val treeUri: Uri,
    val docUri: Uri,
    val name: String,
    val sizeBytes: Long,
    val lastModified: Long
  )

  suspend fun scanSystem(safTreeUris: Set<String>): DeepCleanScanResult =
    withContext(Dispatchers.IO) {
      val candidates = mutableListOf<CleanCandidateItem>()
      val folderSummaries = mutableListOf<FolderScanSummary>()

      // 1. Real NEXUS internal + external cache
      val nexusCacheFiles = collectNexusCacheFiles()
      val nexusCacheBytes = nexusCacheFiles.sumOf { it.length() }
      if (nexusCacheFiles.isNotEmpty() && nexusCacheBytes > 0L) {
        candidates +=
          CleanCandidateItem(
            id = "nexus_internal_cache",
            name = "מטמון פנימי של NEXUS",
            subtitle = "${nexusCacheFiles.size} קבצי מטמון של האפליקציה עצמה",
            sizeBytes = nexusCacheBytes,
            type = CleanItemType.NEXUS_CACHE,
            isDirectDeletable = true,
            selectedByDefault = true,
            safetyTier = CleanerSafetyTier.SAFE
          )
      }

      // 2. Real SAF-authorized folders scan (Downloads / selected folders) via DocumentsContract
      var tempFilesBytes = 0L
      var largeFilesBytes = 0L
      var safeDuplicateBytes = 0L

      val allSafDocs = mutableListOf<SafDocEntry>()
      val oldThresholdMillis = System.currentTimeMillis() - (90L * 24L * 60L * 60L * 1000L)
      for (treeUriStr in safTreeUris) {
        val treeUri = runCatching { Uri.parse(treeUriStr) }.getOrNull() ?: continue
        val entries = scanSafTree(treeUri)
        if (entries.isNotEmpty()) {
          allSafDocs += entries
          val displayName =
            treeUri.lastPathSegment?.substringAfterLast(':')?.ifBlank { "תיקייה מאושרת" }
              ?: "תיקייה מאושרת"
          folderSummaries +=
            FolderScanSummary(
              treeUri = treeUriStr,
              displayName = displayName,
              fileCount = entries.size,
              totalBytes = entries.sumOf { it.sizeBytes }
            )
        }
      }

      // Identify temp/residual/APK/old backup/large/old files
      for (doc in allSafDocs) {
        val ext = doc.name.substringAfterLast('.', "").lowercase()
        val isTemp =
          ext in TEMP_EXTENSIONS ||
            doc.name.endsWith("~") ||
            doc.name.equals("thumbs.db", ignoreCase = true) ||
            doc.sizeBytes == 0L
        val isApk = ext == "apk"
        val isBackup = ext in setOf("bak", "backup") || (ext == "zip" && doc.name.lowercase().contains("backup"))
        val isOld = doc.lastModified > 0L && doc.lastModified < oldThresholdMillis

        when {
          isTemp -> {
            tempFilesBytes += doc.sizeBytes
            candidates +=
              CleanCandidateItem(
                id = "saf_temp_${doc.docUri}",
                name = doc.name,
                subtitle = "קובץ זמני / שיורי בתיקייה מאושרת",
                sizeBytes = doc.sizeBytes,
                type = CleanItemType.TEMP_RESIDUAL,
                uriString = doc.docUri.toString(),
                isDirectDeletable = true,
                selectedByDefault = true,
                safetyTier = CleanerSafetyTier.SAFE,
                treeUriString = doc.treeUri.toString()
              )
          }
          isApk -> {
            candidates +=
              CleanCandidateItem(
                id = "saf_apk_${doc.docUri}",
                name = doc.name,
                subtitle = "קובץ התקנה APK — בדוק אם נחוץ לפני מחיקה",
                sizeBytes = doc.sizeBytes,
                type = CleanItemType.OLD_APK,
                uriString = doc.docUri.toString(),
                isDirectDeletable = true,
                selectedByDefault = false,
                safetyTier = CleanerSafetyTier.REVIEW_NEEDED,
                treeUriString = doc.treeUri.toString()
              )
          }
          isBackup && isOld -> {
            candidates +=
              CleanCandidateItem(
                id = "saf_bak_${doc.docUri}",
                name = doc.name,
                subtitle = "קובץ גיבוי ישן (מעל 90 יום)",
                sizeBytes = doc.sizeBytes,
                type = CleanItemType.OLD_BACKUP,
                uriString = doc.docUri.toString(),
                isDirectDeletable = true,
                selectedByDefault = false,
                safetyTier = CleanerSafetyTier.REVIEW_NEEDED,
                treeUriString = doc.treeUri.toString()
              )
          }
          doc.sizeBytes >= LARGE_FILE_THRESHOLD_BYTES -> {
            largeFilesBytes += doc.sizeBytes
            candidates +=
              CleanCandidateItem(
                id = "saf_large_${doc.docUri}",
                name = doc.name,
                subtitle = "קובץ גדול — עלול להיות אישי, דורש סימון מפורש",
                sizeBytes = doc.sizeBytes,
                type = CleanItemType.LARGE_FILE,
                uriString = doc.docUri.toString(),
                isDirectDeletable = true,
                selectedByDefault = false,
                safetyTier = CleanerSafetyTier.POTENTIAL_DATA_LOSS,
                treeUriString = doc.treeUri.toString()
              )
          }
          isOld && doc.sizeBytes >= 512L * 1024L -> {
            candidates +=
              CleanCandidateItem(
                id = "saf_old_${doc.docUri}",
                name = doc.name,
                subtitle = "קובץ ישן שלא שונה מעל 90 יום",
                sizeBytes = doc.sizeBytes,
                type = CleanItemType.OLD_UNUSED_FILE,
                uriString = doc.docUri.toString(),
                isDirectDeletable = true,
                selectedByDefault = false,
                safetyTier = CleanerSafetyTier.REVIEW_NEEDED,
                treeUriString = doc.treeUri.toString()
              )
          }
        }
      }

      // Safe SHA-256 duplicate detection: group by exact size (> 4 KB, <= 80 MB) first, then hash
      val hashableGroups =
        allSafDocs
          .filter { it.sizeBytes in 4096L..(80L * 1024L * 1024L) }
          .groupBy { it.sizeBytes }
          .filterValues { it.size > 1 }

      for ((_, sameSizeDocs) in hashableGroups) {
        val byHash = mutableMapOf<String, MutableList<SafDocEntry>>()
        for (doc in sameSizeDocs) {
          val hash = computeSafSha256(doc.docUri) ?: continue
          byHash.getOrPut(hash) { mutableListOf() }.add(doc)
        }
        for ((hash, duplicates) in byHash) {
          if (duplicates.size > 1) {
            val sorted = duplicates.sortedBy { it.lastModified }
            sorted.drop(1).forEach { dup ->
              safeDuplicateBytes += dup.sizeBytes
              candidates +=
                CleanCandidateItem(
                  id = "saf_dup_${dup.docUri}",
                  name = "${dup.name} (עותק זהה)",
                  subtitle = "זוהה עותק זהה ב-SHA-256 — המקור נשמר",
                  sizeBytes = dup.sizeBytes,
                  type = CleanItemType.SAFE_DUPLICATE,
                  uriString = dup.docUri.toString(),
                  isDirectDeletable = true,
                  selectedByDefault = false,
                  sha256Prefix = hash.take(10),
                  safetyTier = CleanerSafetyTier.REVIEW_NEEDED,
                  treeUriString = dup.treeUri.toString()
                )
            }
          }
        }
      }

      // 3. Real StorageStatsManager query for other apps' cache (requires PACKAGE_USAGE_STATS)
      val hasUsageAccess = telemetryProvider.hasUsageStatsPermission()
      var externalCacheTotal: Long? = null
      if (hasUsageAccess && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        var cacheAccumulator = 0L
        val storageStatsManager =
          context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val pm = context.packageManager
        val launcherIntent =
          Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launchable = pm.queryIntentActivities(launcherIntent, 0)
        val seenPackages = HashSet<String>()
        val userHandle = Process.myUserHandle()

        val appCaches = mutableListOf<CleanCandidateItem>()
        for (resolveInfo in launchable) {
          val pkg = resolveInfo.activityInfo?.packageName ?: continue
          if (pkg == context.packageName || !seenPackages.add(pkg)) continue
          try {
            val stats =
              storageStatsManager.queryStatsForPackage(
                StorageManager.UUID_DEFAULT,
                pkg,
                userHandle
              )
            if (stats.cacheBytes > 512L * 1024L) {
              cacheAccumulator += stats.cacheBytes
              val label = resolveInfo.loadLabel(pm)?.toString() ?: pkg
              appCaches +=
                CleanCandidateItem(
                  id = "ext_cache_$pkg",
                  name = "$label — מטמון מערכת",
                  subtitle = "ב-Android 10 ניקוי מטמון של אפליקציה אחרת מתבצע דרך הגדרות Android",
                  sizeBytes = stats.cacheBytes,
                  type = CleanItemType.APP_CACHE_EXTERNAL,
                  packageName = pkg,
                  isDirectDeletable = false,
                  selectedByDefault = false,
                  safetyTier = CleanerSafetyTier.POTENTIAL_DATA_LOSS
                )
            }
          } catch (_: Exception) {
          }
        }
        externalCacheTotal = cacheAccumulator
        candidates += appCaches.sortedByDescending { it.sizeBytes }.take(15)
      }

      val statFs = StatFs(Environment.getDataDirectory().path)
      val freeBefore = statFs.availableBytes
      val totalStorage = statFs.totalBytes

      val directReclaimable =
        candidates.filter { it.isDirectDeletable }.sumOf { it.sizeBytes }
      val totalDetected = directReclaimable + (externalCacheTotal ?: 0L)

      DeepCleanScanResult(
        scannedAtMillis = System.currentTimeMillis(),
        nexusCacheBytes = nexusCacheBytes,
        tempFilesBytes = tempFilesBytes,
        safeDuplicateBytes = safeDuplicateBytes,
        largeFilesBytes = largeFilesBytes,
        externalAppCacheBytes = externalCacheTotal,
        directReclaimableBytes = directReclaimable,
        totalDetectedBytes = totalDetected,
        freeBeforeBytes = freeBefore,
        totalStorageBytes = totalStorage,
        candidates = candidates,
        folderSummaries = folderSummaries,
        hasUsageAccess = hasUsageAccess,
        hasSafFolders = safTreeUris.isNotEmpty()
      )
    }

  suspend fun executeClean(selectedItems: List<CleanCandidateItem>): DeepCleanExecutionResult =
    withContext(Dispatchers.IO) {
      val freeBefore = StatFs(Environment.getDataDirectory().path).availableBytes
      var deletedCount = 0
      var failedCount = 0
      var verifiedBytesFreed = 0L
      val logs = mutableListOf<String>()
      val failures = mutableListOf<String>()

      for (item in selectedItems) {
        if (!item.isDirectDeletable) {
          failedCount++
          val reason = "${item.name}: מערכת Android 10 אינה מאפשרת מחיקת מטמון חיצוני ללא מסך ההגדרות הרשמי."
          failures += reason
          logs += reason
          continue
        }

        when (item.type) {
          CleanItemType.NEXUS_CACHE -> {
            val freed = clearOwnCaches()
            verifiedBytesFreed += freed
            deletedCount++
            logs += "נוקה מטמון פנימי של NEXUS (${formatBytes(freed)})"
          }
          CleanItemType.TEMP_RESIDUAL,
          CleanItemType.SAFE_DUPLICATE,
          CleanItemType.LARGE_FILE,
          CleanItemType.EMPTY_FOLDER,
          CleanItemType.OLD_APK,
          CleanItemType.OLD_BACKUP,
          CleanItemType.OLD_UNUSED_FILE -> {
            val uriStr = item.uriString
            if (uriStr == null) {
              failedCount++
              failures += "${item.name}: כתובת קובץ חסרה"
              continue
            }
            val deleted =
              runCatching {
                DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uriStr))
              }.getOrDefault(false)
            if (deleted) {
              deletedCount++
              verifiedBytesFreed += item.sizeBytes
              logs += "נמחק: ${item.name} (${formatBytes(item.sizeBytes)})"
            } else {
              failedCount++
              val reason = "${item.name}: ההרשאה לתיקייה פגה או שהקובץ נעול"
              failures += reason
              logs += reason
            }
          }
          CleanItemType.APP_CACHE_EXTERNAL -> {
            failedCount++
            failures += "${item.name}: דורש פתיחת פרטי האפליקציה ב-Android"
          }
        }
      }

      val freeAfter = StatFs(Environment.getDataDirectory().path).availableBytes
      val delta = (freeAfter - freeBefore).coerceAtLeast(0L)

      DeepCleanExecutionResult(
        executedAtMillis = System.currentTimeMillis(),
        requestedItemsCount = selectedItems.size,
        deletedCount = deletedCount,
        failedCount = failedCount,
        verifiedBytesFreed = verifiedBytesFreed,
        freeBeforeBytes = freeBefore,
        freeAfterBytes = freeAfter,
        storageDeltaBytes = maxOf(delta, verifiedBytesFreed),
        actionLogs = logs,
        failureReasons = failures
      )
    }

  fun clearOwnCaches(): Long {
    var freed = 0L
    val cacheDirs = listOfNotNull(context.cacheDir, context.codeCacheDir, context.externalCacheDir)
    for (dir in cacheDirs) {
      if (dir.exists()) {
        dir.listFiles()?.forEach { child ->
          val size = measureRecursive(child)
          if (child.deleteRecursively()) {
            freed += size
          }
        }
      }
    }
    return freed
  }

  private fun collectNexusCacheFiles(): List<File> {
    val files = mutableListOf<File>()
    val dirs = listOfNotNull(context.cacheDir, context.codeCacheDir, context.externalCacheDir)
    for (dir in dirs) {
      if (dir.exists()) {
        dir.walkTopDown().filter { it.isFile }.forEach { files += it }
      }
    }
    return files
  }

  private fun measureRecursive(file: File): Long {
    if (!file.exists()) return 0L
    if (file.isFile) return file.length()
    return file.listFiles()?.sumOf { measureRecursive(it) } ?: 0L
  }

  private fun scanSafTree(treeUri: Uri): List<SafDocEntry> {
    val results = mutableListOf<SafDocEntry>()
    val rootDocId =
      try {
        DocumentsContract.getTreeDocumentId(treeUri)
      } catch (_: Exception) {
        return emptyList()
      }
    val queue = ArrayDeque<String>()
    queue.add(rootDocId)

    val projection =
      arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_SIZE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED
      )

    while (queue.isNotEmpty() && results.size < MAX_SAF_FILES_TO_SCAN) {
      val parentId = queue.removeFirst()
      val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
      try {
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
          val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
          val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
          val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
          val sizeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
          val modIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)

          while (cursor.moveToNext() && results.size < MAX_SAF_FILES_TO_SCAN) {
            val docId = if (idIdx >= 0) cursor.getString(idIdx) else continue
            val name = if (nameIdx >= 0) cursor.getString(nameIdx) ?: "קובץ" else "קובץ"
            val mime = if (mimeIdx >= 0) cursor.getString(mimeIdx) ?: "" else ""
            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
              queue.add(docId)
            } else {
              val size = if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) cursor.getLong(sizeIdx) else 0L
              val mod = if (modIdx >= 0 && !cursor.isNull(modIdx)) cursor.getLong(modIdx) else 0L
              val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
              results += SafDocEntry(treeUri, docUri, name, size, mod)
            }
          }
        }
      } catch (_: SecurityException) {
        break
      } catch (_: Exception) {
      }
    }
    return results
  }

  private fun computeSafSha256(docUri: Uri): String? {
    return try {
      val digest = MessageDigest.getInstance("SHA-256")
      val buffer = ByteArray(16 * 1024)
      context.contentResolver.openInputStream(docUri)?.use { input ->
        var read = input.read(buffer)
        while (read != -1) {
          digest.update(buffer, 0, read)
          read = input.read(buffer)
        }
      } ?: return null
      digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
      null
    }
  }
}
