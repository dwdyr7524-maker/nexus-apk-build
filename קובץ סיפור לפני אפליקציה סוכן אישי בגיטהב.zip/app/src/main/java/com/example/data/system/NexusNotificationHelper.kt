package com.example.data.system

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

object NexusNotificationHelper {

  const val CHANNEL_ALERTS = "nexus_alerts_channel"
  const val CHANNEL_AUTOMATION = "nexus_automation_channel"
  const val CHANNEL_REMINDERS = "nexus_reminders_channel"
  const val EXTRA_TARGET_ROUTE = "nexus_target_route"

  fun ensureChannels(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      val alertsChannel =
        NotificationChannel(
          CHANNEL_ALERTS,
          "התראות סוללה, חום ואחסון (NEXUS)",
          NotificationManager.IMPORTANCE_HIGH
        ).apply {
          description = "התראות רקע בזמן אמת על התחממות סוללה, סוללה חלשה או עומס אחסון קריטי."
        }
      val automationChannel =
        NotificationChannel(
          CHANNEL_AUTOMATION,
          "אוטומציות מתוזמנות (NEXUS)",
          NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
          description = "סיכומי הרצה של משימות תחזוקה מתוזמנות ברקע."
        }
      val remindersChannel =
        NotificationChannel(
          CHANNEL_REMINDERS,
          "תזכורות והשלמת משימות (NEXUS)",
          NotificationManager.IMPORTANCE_HIGH
        ).apply {
          description = "תזכורות משתמש, התראות תנאי והודעות סיום או כישלון של משימות."
        }
      nm.createNotificationChannel(alertsChannel)
      nm.createNotificationChannel(automationChannel)
      nm.createNotificationChannel(remindersChannel)
    }
  }

  fun canPostNotifications(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    } else {
      NotificationManagerCompat.from(context).areNotificationsEnabled()
    }
  }

  fun postSystemAlertNotification(
    context: Context,
    notificationId: Int,
    title: String,
    body: String,
    targetRoute: String
  ) {
    if (!canPostNotifications(context)) return
    ensureChannels(context)
    val intent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        putExtra(EXTRA_TARGET_ROUTE, targetRoute)
      }
    val pi =
      PendingIntent.getActivity(
        context,
        notificationId,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )

    val notification =
      NotificationCompat.Builder(context, CHANNEL_ALERTS)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .setContentIntent(pi)
        .build()

    runCatching {
      NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
  }

  fun postAutomationCompletedNotification(
    context: Context,
    notificationId: Int,
    title: String,
    body: String
  ) {
    if (!canPostNotifications(context)) return
    ensureChannels(context)
    val intent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        putExtra(EXTRA_TARGET_ROUTE, "automation")
      }
    val pi =
      PendingIntent.getActivity(
        context,
        notificationId,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )

    val notification =
      NotificationCompat.Builder(context, CHANNEL_AUTOMATION)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setAutoCancel(true)
        .setContentIntent(pi)
        .build()

    runCatching {
      NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
  }

  fun postReminderNotification(
    context: Context,
    notificationId: Int,
    title: String,
    body: String,
    targetRoute: String = "assistant"
  ) {
    if (!canPostNotifications(context)) return
    ensureChannels(context)
    val intent =
      Intent(context, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        putExtra(EXTRA_TARGET_ROUTE, targetRoute)
      }
    val pi =
      PendingIntent.getActivity(
        context,
        notificationId,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )

    val notification =
      NotificationCompat.Builder(context, CHANNEL_REMINDERS)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(body)
        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .setContentIntent(pi)
        .build()

    runCatching {
      NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
  }
}
