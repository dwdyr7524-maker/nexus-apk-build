package com.example.data.orchestrator

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.local.ToolUsageEntity
import com.example.data.model.SystemTelemetry
import com.example.data.system.NexusNotificationHelper

enum class NexusToolHealthState(val titleHe: String) {
  READY("תקין ומוכן"),
  PERMISSION_NEEDED("דורש הרשאה / גישת SAF"),
  OFFLINE_LIMITED("מוגבל במצב לא מקוון"),
  DEGRADED("אחוז שגיאות גבוה")
}

data class NexusToolDefinition(
  val id: String,
  val nameHe: String,
  val descriptionHe: String,
  val requiredPermissionLabelHe: String,
  val worksOffline: Boolean,
  val capabilityCategoryHe: String
)

data class NexusToolStatus(
  val definition: NexusToolDefinition,
  val healthState: NexusToolHealthState,
  val statusDetailHe: String,
  val totalRuns: Int,
  val successRatePercent: Int,
  val lastUsedMillis: Long?
)

/**
 * Modular registry documenting and health-checking ONLY real, implemented tools in NEXUS.
 */
object NexusToolRegistry {

  val catalog: List<NexusToolDefinition> =
    listOf(
      NexusToolDefinition(
        id = "device_telemetry",
        nameHe = "מנוע טלמטריה וחיישנים",
        descriptionHe = "מדידת סוללה, טמפרטורה, מתח, אחסון פנימי, RAM, רשת וזיהוי חומרה בזמן אמת.",
        requiredPermissionLabelHe = "ללא הרשאות מסוכנות (ACCESS_NETWORK_STATE בסיסי)",
        worksOffline = true,
        capabilityCategoryHe = "מערכת ואבחון"
      ),
      NexusToolDefinition(
        id = "smart_storage",
        nameHe = "מנהל אחסון חכם ו-SD",
        descriptionHe = "מיפוי אחסון פנימי וכרטיס SD, איתור כפילויות SHA-256, תיקיות ריקות וקובצי APK.",
        requiredPermissionLabelHe = "בחירת תיקייה מאובטחת (SAF OpenDocumentTree)",
        worksOffline = true,
        capabilityCategoryHe = "אחסון וקבצים"
      ),
      NexusToolDefinition(
        id = "document_pdf_reader",
        nameHe = "מנוע מסמכים ו-PDF (PdfRenderer)",
        descriptionHe = "קריאת PDF/TXT/MD/JSON/CSV, חיפוש בתוך מסמך, סיכום ותצוגת עמודי PDF.",
        requiredPermissionLabelHe = "גישת מסמכים נקודתית (SAF OpenDocument / CreateDocument)",
        worksOffline = true,
        capabilityCategoryHe = "מסמכים ותוכן"
      ),
      NexusToolDefinition(
        id = "app_inspector",
        nameHe = "מנתח אפליקציות והרשאות",
        descriptionHe = "סריקת אפליקציות מותקנות, הרשאות מצלמה/מיקרופון/מיקום, נפח ושימוש אחרון.",
        requiredPermissionLabelHe = "PACKAGE_USAGE_STATS אופציונלי לנפח מטמון ונתונים",
        worksOffline = true,
        capabilityCategoryHe = "אפליקציות ואבטחה"
      ),
      NexusToolDefinition(
        id = "task_orchestrator",
        nameHe = "מוח תזמור ו-5 סוכנים",
        descriptionHe = "פירוק משימות מורכבות, תזמור תכנון/מחקר/קוד/בדיקות, ניסוי חוזר ועצירה/המשך.",
        requiredPermissionLabelHe = "רצה מקומית; מועשר בענן Gemini AI כשיש אינטרנט",
        worksOffline = true,
        capabilityCategoryHe = "אורקסטרציה ו-AI"
      ),
      NexusToolDefinition(
        id = "reminder_scheduler",
        nameHe = "מתזמן תזכורות והתראות (WorkManager)",
        descriptionHe = "תזכורות לזמן מוגדר, התראות תנאי (חום/סוללה/אחסון) ומניעת הרצה כפולה.",
        requiredPermissionLabelHe =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) "POST_NOTIFICATIONS (Android 13+)"
          else "התראות מערכת מובנות (Android 10)",
        worksOffline = true,
        capabilityCategoryHe = "אוטומציה ותזמון"
      ),
      NexusToolDefinition(
        id = "voice_pipeline",
        nameHe = "מנוע קול, סינון רעשים ו-TTS",
        descriptionHe = "הקלטת WAV 16kHz עם NoiseSuppressor חומרתי, בחירת קול, קצב דיבור, Pause/Resume.",
        requiredPermissionLabelHe = "RECORD_AUDIO בעת הפעלת מיקרופון",
        worksOffline = true,
        capabilityCategoryHe = "קול ונגישות"
      ),
      NexusToolDefinition(
        id = "cloud_gemini_ai",
        nameHe = "ספק ענן Firebase AI Logic",
        descriptionHe = "מודלי חינם (Gemini 3.8 Flash / 3.5 Lite / 3.5 Transcribe / Live) עם App Check.",
        requiredPermissionLabelHe = "INTERNET + App Check (חסום ממעבר בתשלום)",
        worksOffline = false,
        capabilityCategoryHe = "בינה מלאכותית בענן"
      ),
      NexusToolDefinition(
        id = "system_settings_bridge",
        nameHe = "גשר הגדרות Android הרשמי",
        descriptionHe = "פתיחה בטוחה ומבוקרת של מסכי אחסון, סוללה, Wi-Fi, הרשאות ו-Samsung Device Care.",
        requiredPermissionLabelHe = "ללא הרשאות Root — פועל דרך Android System Intents",
        worksOffline = true,
        capabilityCategoryHe = "שליטת מערכת"
      )
    )

  fun inspectTools(
    context: Context,
    telemetry: SystemTelemetry,
    safFoldersCount: Int,
    cloudAiEnabled: Boolean,
    usageLogs: List<ToolUsageEntity>
  ): List<NexusToolStatus> {
    val micGranted =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    val notifGranted = NexusNotificationHelper.canPostNotifications(context)

    return catalog.map { def ->
      val runs = usageLogs.filter { it.toolId == def.id }
      val total = runs.size
      val ok = runs.count { it.succeeded }
      val rate = if (total > 0) ((ok * 100f) / total).toInt() else 100
      val lastTs = runs.maxOfOrNull { it.timestampMillis }
      val isDegraded = total >= 3 && rate < 50

      val (health, detail) =
        when (def.id) {
          "smart_storage" ->
            if (isDegraded) NexusToolHealthState.DEGRADED to "זוהתה ירידה באחוז ההצלחה ($rate%). בדוק הרשאות SAF."
            else if (safFoldersCount == 0) NexusToolHealthState.PERMISSION_NEEDED to "פעיל למטמון פנימי; הוסף תיקיות או SD ב-SAF לסריקת קבצים מלאה."
            else NexusToolHealthState.READY to "מחובר ל-$safFoldersCount תיקיות SAF מאושרות."

          "app_inspector" ->
            if (!telemetry.hasUsageAccessPermission) {
              NexusToolHealthState.PERMISSION_NEEDED to "פועל בסיסית; גישת Usage Access תאפשר מדידת מטמון וזמן שימוש."
            } else NexusToolHealthState.READY to "גישת Usage Stats פעילה ומדידת נפח מלאה זמינה."

          "voice_pipeline" ->
            if (!micGranted) NexusToolHealthState.PERMISSION_NEEDED to "TTS מוכן; נדרשת הרשאת RECORD_AUDIO להקלטה ותמלול."
            else NexusToolHealthState.READY to "מיקרופון מאושר וסינון רעשים חומרתי זמין לפי תמיכת המכשיר."

          "reminder_scheduler" ->
            if (!notifGranted) NexusToolHealthState.PERMISSION_NEEDED to "WorkManager פעיל, אך הרשאת התראות כבויה."
            else NexusToolHealthState.READY to "מתזמן WorkManager פעיל ומוגן ממניעת כפילויות."

          "cloud_gemini_ai" ->
            when {
              !cloudAiEnabled -> NexusToolHealthState.OFFLINE_LIMITED to "מושבת ע״י המשתמש — העוזר עובד במצב מקומי בטוח."
              !telemetry.network.isConnected -> NexusToolHealthState.OFFLINE_LIMITED to "אין אינטרנט כרגע — בקשות ענן ממתינות לתור סנכרון מבוקר."
              isDegraded -> NexusToolHealthState.DEGRADED to "זוהתה תקלה חוזרת בחיבור הענן ($rate% הצלחה)."
              else -> NexusToolHealthState.READY to "מחובר ברשת ${telemetry.network.transportLabel}; מודלים חינמיים זמינים."
            }

          else ->
            if (isDegraded) NexusToolHealthState.DEGRADED to "אחוז הצלחה נמוך מהרגיל ($rate%)."
            else NexusToolHealthState.READY to "מאומת ומוכן לפעולה (100% מקומי)."
        }

      NexusToolStatus(
        definition = def,
        healthState = health,
        statusDetailHe = detail,
        totalRuns = total,
        successRatePercent = rate,
        lastUsedMillis = lastTs
      )
    }
  }
}
