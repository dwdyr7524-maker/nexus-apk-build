package com.example.data.system

import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.DeviceIdentity
import com.example.data.model.HealthSeverity
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SecurityFinding

class SecurityAuditor {

  fun buildAuditReport(
    apps: List<AppDiagnosticInfo>,
    device: DeviceIdentity
  ): SecurityAuditReport {
    val cameraApps = apps.filter { it.hasCameraPermission }
    val micApps = apps.filter { it.hasMicPermission }
    val locationApps = apps.filter { it.hasLocationPermission }
    val specialApps =
      apps.filter { it.hasBackgroundLocation || it.canDrawOverlays || it.canRequestInstalls }

    val findings = mutableListOf<SecurityFinding>()

    if (!device.isDeviceSecureLock) {
      findings +=
        SecurityFinding(
          id = "device_no_lock",
          title = "נעילת מסך אינה מוגדרת",
          description = "לא זוהתה הגנת PIN, תבנית או ביומטריה במכשיר.",
          severity = HealthSeverity.CRITICAL
        )
    } else {
      findings +=
        SecurityFinding(
          id = "device_lock_ok",
          title = "נעילת מכשיר מאובטחת פעילה",
          description = "הטאבלט מוגן במסך נעילה מאובטח.",
          severity = HealthSeverity.OPTIMAL
        )
    }

    val bgLocationApps = apps.filter { it.hasBackgroundLocation && !it.isSystemApp }
    bgLocationApps.forEach { app ->
      findings +=
        SecurityFinding(
          id = "bg_loc_${app.packageName}",
          title = "גישה למיקום ברקע: ${app.appName}",
          description = "האפליקציה מחזיקה בהרשאת מיקום קבועה גם כשאינה פתוחה.",
          severity = HealthSeverity.WARNING,
          packageName = app.packageName,
          appName = app.appName
        )
    }

    val installSourceApps = apps.filter { it.canRequestInstalls && !it.isSystemApp }
    installSourceApps.forEach { app ->
      findings +=
        SecurityFinding(
          id = "install_pkg_${app.packageName}",
          title = "הרשאת התקנת אפליקציות: ${app.appName}",
          description = "האפליקציה מורשית לבקש התקנת קובצי APK ממקור חיצוני.",
          severity = HealthSeverity.WARNING,
          packageName = app.packageName,
          appName = app.appName
        )
    }

    val comboApps =
      apps.filter {
        !it.isSystemApp && it.hasCameraPermission && it.hasMicPermission && it.hasLocationPermission
      }
    comboApps.forEach { app ->
      findings +=
        SecurityFinding(
          id = "combo_${app.packageName}",
          title = "שילוב הרשאות מלא (מצלמה + מיקרופון + מיקום): ${app.appName}",
          description = "מומלץ לוודא שההרשאות הללו אכן נחוצות לאפליקציה.",
          severity = HealthSeverity.NOTICE,
          packageName = app.packageName,
          appName = app.appName
        )
    }

    val sensitiveApps =
      apps
        .filter {
          it.hasCameraPermission ||
            it.hasMicPermission ||
            it.hasLocationPermission ||
            it.hasBackgroundLocation ||
            it.canDrawOverlays ||
            it.canRequestInstalls
        }
        .sortedByDescending {
          (if (it.hasBackgroundLocation) 4 else 0) +
            (if (it.canRequestInstalls) 3 else 0) +
            (if (it.canDrawOverlays) 2 else 0) +
            it.grantedSensitivePermissions.size
        }

    return SecurityAuditReport(
      auditedAtMillis = System.currentTimeMillis(),
      totalAppsAudited = apps.size,
      cameraAppsCount = cameraApps.size,
      micAppsCount = micApps.size,
      locationAppsCount = locationApps.size,
      specialPermissionAppsCount = specialApps.size,
      isDeviceSecureLock = device.isDeviceSecureLock,
      securityPatch = device.securityPatch,
      findings = findings,
      sensitiveApps = sensitiveApps
    )
  }
}
