package com.example.data.ai

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Thread-safe 16kHz Mono PCM -> WAV microphone recorder for gemini-3.5-transcribe.
 * Uses VOICE_COMMUNICATION + hardware NoiseSuppressor / AcousticEchoCanceler when available.
 */
class NexusAudioRecorder(private val context: Context) {

  companion object {
    private const val SAMPLE_RATE_HZ = 16_000
    private const val CHANNELS = 1
    private const val BITS_PER_SAMPLE = 16
    // Max 120 seconds (~3.84 MB WAV, well below Firebase AI Logic 20 MB inline limit)
    private const val MAX_PCM_BYTES = SAMPLE_RATE_HZ * 2 * 120
    private const val NOISE_GATE_THRESHOLD = 160
  }

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var recordJob: Job? = null
  private var pcmBuffer = ByteArrayOutputStream()

  private val _isRecording = MutableStateFlow(false)
  val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

  private val _amplitude = MutableStateFlow(0f)
  val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

  private val _elapsedSeconds = MutableStateFlow(0)
  val elapsedSeconds: StateFlow<Int> = _elapsedSeconds.asStateFlow()

  private val _hardwareNoiseSuppressionActive = MutableStateFlow(false)
  val hardwareNoiseSuppressionActive: StateFlow<Boolean> =
    _hardwareNoiseSuppressionActive.asStateFlow()

  @SuppressLint("MissingPermission")
  fun startRecording(
    noiseSuppressionEnabled: Boolean = true,
    onAutoStopped: ((ByteArray) -> Unit)? = null
  ): Result<Unit> {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
      PackageManager.PERMISSION_GRANTED
    ) {
      return Result.failure(SecurityException("נדרשת הרשאת מיקרופון (RECORD_AUDIO) להקלטה."))
    }
    if (_isRecording.value) {
      return Result.failure(IllegalStateException("ההקלטה כבר פעילה."))
    }

    val minBuf =
      AudioRecord.getMinBufferSize(
        SAMPLE_RATE_HZ,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      )
    if (minBuf <= 0) {
      return Result.failure(IllegalStateException("חומרת המיקרופון אינה זמינה במכשיר זה."))
    }
    val bufferSize = maxOf(minBuf * 2, 4096)

    val audioSource =
      if (noiseSuppressionEnabled) MediaRecorder.AudioSource.VOICE_COMMUNICATION
      else MediaRecorder.AudioSource.MIC

    val audioRecord =
      runCatching {
        AudioRecord(
          audioSource,
          SAMPLE_RATE_HZ,
          AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
          bufferSize
        )
      }.getOrElse { err ->
        return Result.failure(IllegalStateException("אתחול המיקרופון נכשל: ${err.localizedMessage}"))
      }

    if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
      audioRecord.release()
      return Result.failure(IllegalStateException("לא ניתן לפתוח ערוץ הקלטה במיקרופון."))
    }

    var noiseSuppressor: NoiseSuppressor? = null
    var echoCanceler: AcousticEchoCanceler? = null
    if (noiseSuppressionEnabled) {
      runCatching {
        if (NoiseSuppressor.isAvailable()) {
          noiseSuppressor = NoiseSuppressor.create(audioRecord.audioSessionId)?.apply { enabled = true }
        }
      }
      runCatching {
        if (AcousticEchoCanceler.isAvailable()) {
          echoCanceler = AcousticEchoCanceler.create(audioRecord.audioSessionId)?.apply { enabled = true }
        }
      }
    }
    _hardwareNoiseSuppressionActive.value = noiseSuppressor?.enabled == true

    synchronized(this) {
      pcmBuffer = ByteArrayOutputStream()
    }
    _amplitude.value = 0f
    _elapsedSeconds.value = 0
    _isRecording.value = true

    recordJob =
      scope.launch {
        val readBuf = ByteArray(bufferSize)
        val startedAt = System.currentTimeMillis()
        var autoLimitReached = false
        try {
          audioRecord.startRecording()
          while (isActive && _isRecording.value) {
            val read = audioRecord.read(readBuf, 0, readBuf.size)
            if (read > 0) {
              if (noiseSuppressionEnabled) {
                applySoftwareNoiseGate(readBuf, read)
              }
              val currentTotal =
                synchronized(this@NexusAudioRecorder) {
                  pcmBuffer.write(readBuf, 0, read)
                  pcmBuffer.size()
                }
              _amplitude.value = computeNormalizedRms(readBuf, read)
              _elapsedSeconds.value = ((System.currentTimeMillis() - startedAt) / 1000L).toInt()
              if (currentTotal >= MAX_PCM_BYTES) {
                autoLimitReached = true
                _isRecording.value = false
                break
              }
            } else if (read < 0) {
              break
            }
          }
        } finally {
          _isRecording.value = false
          _amplitude.value = 0f
          _hardwareNoiseSuppressionActive.value = false
          runCatching {
            if (audioRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
              audioRecord.stop()
            }
          }
          runCatching { noiseSuppressor?.release() }
          runCatching { echoCanceler?.release() }
          runCatching { audioRecord.release() }
          if (autoLimitReached && onAutoStopped != null) {
            val wav = buildWavFromBuffer()
            if (wav.size > 44) {
              onAutoStopped(wav)
            }
          }
        }
      }

    return Result.success(Unit)
  }

  private fun applySoftwareNoiseGate(bytes: ByteArray, length: Int) {
    var i = 0
    while (i + 1 < length) {
      val sample = ((bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)).toShort()
      if (abs(sample.toInt()) < NOISE_GATE_THRESHOLD) {
        val attenuated = (sample.toInt() / 4).toShort()
        bytes[i] = (attenuated.toInt() and 0xFF).toByte()
        bytes[i + 1] = ((attenuated.toInt() shr 8) and 0xFF).toByte()
      }
      i += 2
    }
  }

  suspend fun stopAndBuildWav(): ByteArray =
    withContext(Dispatchers.IO) {
      _isRecording.value = false
      recordJob?.join()
      recordJob = null
      _amplitude.value = 0f
      buildWavFromBuffer()
    }

  suspend fun cancelRecording() {
    withContext(Dispatchers.IO) {
      _isRecording.value = false
      recordJob?.cancel()
      recordJob?.join()
      recordJob = null
      _amplitude.value = 0f
      _elapsedSeconds.value = 0
      synchronized(this@NexusAudioRecorder) {
        pcmBuffer.reset()
      }
    }
  }

  fun shutdown() {
    _isRecording.value = false
    recordJob?.cancel()
    recordJob = null
    scope.cancel()
  }

  private fun buildWavFromBuffer(): ByteArray {
    val pcmBytes = synchronized(this) { pcmBuffer.toByteArray() }
    if (pcmBytes.isEmpty()) return ByteArray(0)
    val wavHeader = createWavHeader(pcmBytes.size)
    return wavHeader + pcmBytes
  }

  private fun computeNormalizedRms(bytes: ByteArray, length: Int): Float {
    if (length < 2) return 0f
    var sumSquares = 0.0
    var sampleCount = 0
    var i = 0
    while (i + 1 < length) {
      val sample = ((bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)).toShort()
      val normalized = sample / 32768.0
      sumSquares += normalized * normalized
      sampleCount++
      i += 2
    }
    if (sampleCount == 0) return 0f
    val rms = sqrt(sumSquares / sampleCount).toFloat()
    return (rms * 3.5f).coerceIn(0f, 1f)
  }

  private fun createWavHeader(pcmDataSize: Int): ByteArray {
    val totalDataLen = pcmDataSize + 36
    val byteRate = SAMPLE_RATE_HZ * CHANNELS * (BITS_PER_SAMPLE / 8)
    val blockAlign = CHANNELS * (BITS_PER_SAMPLE / 8)

    return ByteBuffer.allocate(44)
      .order(ByteOrder.LITTLE_ENDIAN)
      .apply {
        put("RIFF".toByteArray(Charsets.US_ASCII))
        putInt(totalDataLen)
        put("WAVE".toByteArray(Charsets.US_ASCII))
        put("fmt ".toByteArray(Charsets.US_ASCII))
        putInt(16) // PCM chunk size
        putShort(1.toShort()) // AudioFormat 1 = PCM
        putShort(CHANNELS.toShort())
        putInt(SAMPLE_RATE_HZ)
        putInt(byteRate)
        putShort(blockAlign.toShort())
        putShort(BITS_PER_SAMPLE.toShort())
        put("data".toByteArray(Charsets.US_ASCII))
        putInt(pcmDataSize)
      }
      .array()
  }
}
