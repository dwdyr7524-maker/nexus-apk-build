package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clean_history")
data class CleanHistoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val itemsDeleted: Int,
  val itemsFailed: Int,
  val bytesFreed: Long,
  val freeBeforeBytes: Long,
  val freeAfterBytes: Long,
  val summary: String,
  val failureReason: String? = null
)

@Entity(tableName = "telemetry_snapshots")
data class TelemetrySnapshotEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val batteryPercent: Int,
  val batteryTempC: Float,
  val batteryVoltageMv: Int,
  val ramUsedPercent: Int,
  val storageUsedPercent: Int,
  val storageFreeBytes: Long,
  val healthScore: Int
)

@Entity(tableName = "assistant_messages")
data class AssistantMessageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val isUser: Boolean,
  val text: String,
  val actionTag: String? = null
)

@Entity(tableName = "automations")
data class AutomationEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val voicePhrase: String,
  val description: String,
  val stepsSerialized: String,
  val isBuiltIn: Boolean = false,
  val lastRunMillis: Long? = null,
  val scheduleIntervalHours: Int = 0
)

@Entity(tableName = "action_audit")
data class ActionAuditEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestampMillis: Long,
  val category: String,
  val actionTitle: String,
  val succeeded: Boolean,
  val details: String,
  val failureReason: String? = null
)

@Entity(tableName = "approval_proposals")
data class ApprovalProposalEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val createdAtMillis: Long,
  val title: String,
  val reasonHe: String,
  val targetName: String,
  val targetLocation: String,
  val operationType: String,
  val riskLevel: String,
  val isReversible: Boolean,
  val expectedOutcomeHe: String,
  val sourceUriString: String? = null,
  val treeUriString: String? = null,
  val destTreeUriString: String? = null,
  val destFolderName: String? = null,
  val proposedNewName: String? = null,
  val packageName: String? = null,
  val bytesAffected: Long = 0L,
  val status: String = "PENDING",
  val resultMessageHe: String? = null
)

@Entity(tableName = "undo_records")
data class UndoRecordEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val createdAtMillis: Long,
  val actionTitle: String,
  val undoType: String,
  val targetUriString: String? = null,
  val originalParentDocId: String? = null,
  val originalTreeUriString: String? = null,
  val previousName: String? = null,
  val backupManifestId: Long? = null,
  val isUndoable: Boolean,
  val undone: Boolean = false,
  val noteHe: String
)

@Entity(tableName = "backup_records")
data class BackupRecordEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val createdAtMillis: Long,
  val sourceLabel: String,
  val sourceTreeUri: String,
  val destTreeUri: String,
  val destFolderDocId: String,
  val destFolderName: String,
  val fileCount: Int,
  val totalBytes: Long,
  val verifiedOk: Boolean,
  val integritySummaryHe: String,
  val manifestJson: String
)

@Entity(tableName = "memory_entries")
data class MemoryEntryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val memoryType: String, // SHORT_TERM, LONG_TERM, PREFERENCE, PROJECT, DECISION, CONTEXT
  val title: String,
  val content: String,
  val categoryTag: String,
  val canPersist: Boolean = true,
  val importanceScore: Int = 50,
  val createdAtMillis: Long,
  val updatedAtMillis: Long,
  val lastAccessedMillis: Long
)

@Entity(tableName = "orchestrator_tasks")
data class OrchestratorTaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val goal: String,
  val status: String, // PENDING, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED
  val progressPercent: Int = 0,
  val currentAgent: String, // PLANNER, RESEARCHER, CODER, TESTER, TASK_MANAGER
  val currentStepLabel: String,
  val stepsJson: String,
  val resultSummary: String? = null,
  val errorMessage: String? = null,
  val requiresNetwork: Boolean = false,
  val createdAtMillis: Long,
  val updatedAtMillis: Long
)

@Entity(tableName = "learning_records")
data class LearningRecordEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val category: String, // TOOL_OUTCOME, ASSISTANT_FEEDBACK, PATTERN_SUGGESTION, PREFERENCE_ADAPTATION
  val targetKey: String,
  val summaryHe: String,
  val succeeded: Boolean,
  val userRating: Int = 0, // -1, 0, +1
  val reversiblePatchJson: String? = null,
  val undone: Boolean = false,
  val createdAtMillis: Long
)

@Entity(tableName = "tool_usage")
data class ToolUsageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val toolId: String,
  val toolNameHe: String,
  val succeeded: Boolean,
  val latencyMs: Long,
  val summaryHe: String,
  val errorHe: String? = null,
  val timestampMillis: Long
)

@Entity(tableName = "reminder_alerts")
data class ReminderAlertEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val message: String,
  val kind: String, // REMINDER, CONDITIONAL_ALERT, FAILURE, COMPLETION
  val triggerAtMillis: Long? = null,
  val repeatIntervalHours: Int = 0,
  val conditionKey: String = "NONE", // NONE, BATTERY_LOW, BATTERY_HOT, STORAGE_FULL, NETWORK_RECONNECTED
  val status: String = "ACTIVE", // ACTIVE, TRIGGERED, DISMISSED, CANCELLED
  val targetRoute: String = "dashboard",
  val createdAtMillis: Long,
  val lastTriggeredMillis: Long? = null
)

