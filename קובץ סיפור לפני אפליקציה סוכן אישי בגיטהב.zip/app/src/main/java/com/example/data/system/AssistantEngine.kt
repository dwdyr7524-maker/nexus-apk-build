package com.example.data.system

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.local.AutomationEntity
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AssistantActionType
import com.example.data.model.PendingAssistantAction
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SystemTelemetry
import java.util.Locale

data class AssistantReply(
  val replyText: String,
  val actionTag: String,
  val pendingAction: PendingAssistantAction? = null,
  val plannedSteps: List<String> = emptyList()
)

object AssistantCommandParser {

  private val hebrewLocale: Locale = Locale.forLanguageTag("he-IL")

  fun parseAndRespond(
    rawInput: String,
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>
  ): AssistantReply {
    val q = rawInput.trim().lowercase(hebrewLocale)

    // 1. Check user custom commands / automations first
    val matchedAutomation =
      customAutomations.firstOrNull { auto ->
        val phrase = auto.voicePhrase.trim().lowercase(hebrewLocale)
        val name = auto.name.trim().lowercase(hebrewLocale)
        (phrase.isNotBlank() && q.contains(phrase)) || (name.isNotBlank() && q.contains(name))
      }
    if (matchedAutomation != null) {
      return AssistantReply(
        replyText = "זיהיתי את האוטומציה \"${matchedAutomation.name}\". האם להריץ את רצף הפעולות כעת?",
        actionTag = "AUTOMATION_${matchedAutomation.id}",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.RUN_AUTOMATION,
            title = "אישור הפעלת אוטומציה: ${matchedAutomation.name}",
            description = matchedAutomation.description,
            requiresConfirmation = true,
            automationId = matchedAutomation.id
          ),
        plannedSteps = matchedAutomation.description.split("←").map { it.trim() }.filter { it.isNotEmpty() }
      )
    }

    // 1b. AI File Commander & SD / Duplicates / Downloads Organization / Device Doctor / Approval Center
    if ((q.contains("סרטונ") || q.contains("וידאו") || q.contains("קבצ")) && q.contains("כפול")) {
      return AssistantReply(
        replyText =
          "אסרוק את התיקיות המאושרות ואת כרטיס ה-SD עם אימות SHA-256 כדי לאתר קובצי וידאו זהים, ואכין הצעות מחיקה בטוחות במרכז האישורים — אף קובץ לא יימחק אוטומטית.",
        actionTag = "COMMANDER_DUP_VIDEOS",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.STAGE_DUPLICATE_VIDEOS_PROPOSALS,
            title = "סרוק והעבר כפילויות למרכז האישורים",
            description = "איתור סרטונים כפולים והוספתם לרשימת האישורים לבדיקתך.",
            requiresConfirmation = true
          ),
        plannedSteps =
          listOf(
            "סריקת תיקיות פנימיות ו-SD בחתימת SHA-256",
            "השוואת עותקים ובחירת עותק מקורי לשמירה",
            "יצירת הצעות מחיקה במרכז האישורים בלבד"
          )
      )
    }

    if (q.contains("ארגן") && (q.contains("הורד") || q.contains("תיקי") || q.contains("קבצ"))) {
      return AssistantReply(
        replyText =
          "מנוע ה-AI ינתח את תיקיית ההורדות והקבצים שבחרת, יזהה מסמכים, תמונות וקובצי התקנה, ויכין תוכנית ארגון מלאה במרכז האישורים לפני כל שינוי.",
        actionTag = "COMMANDER_ORG_DOWNLOADS",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.STAGE_DOWNLOADS_ORGANIZE_PROPOSALS,
            title = "הכן תוכנית ארגון להורדות במרכז האישורים",
            description = "יצירת הצעות מיון, תיקיות מומלצות ושינוי שמות לבדיקתך.",
            requiresConfirmation = true
          ),
        plannedSteps =
          listOf(
            "סריקת תיקיית ההורדות וסיווג לפי נושא וסוג",
            "זיהוי קבצים עם שמות לא ברורים",
            "הגשת הצעות מסודרות למרכז האישורים"
          )
      )
    }

    if (q.contains("כרטיס") || q.contains("sd") || q.contains("זיכרון חיצוני")) {
      return AssistantReply(
        replyText =
          "אפתח את מנהל כרטיס הזיכרון והאחסון החכם לבדיקת זיהוי הכרטיס, שטח פנוי, קבצים לא קריאים ודוח בריאות כרטיס SD.",
        actionTag = "COMMANDER_CHECK_SD",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.CHECK_SD_CARD,
            title = "בדוק כרטיס SD ב-Smart Storage",
            description = "בדיקת חיבור, דוח בריאות וניהול תיקיות SD.",
            requiresConfirmation = false
          ),
        plannedSteps = listOf("בדיקת StorageVolumes והרשאות SAF", "הפקת דוח בריאות כרטיס SD")
      )
    }

    if (q.contains("תוכנית") && (q.contains("ניקוי") || q.contains("פינוי") || q.contains("תחזוקה"))) {
      return AssistantReply(
        replyText =
          "הכנתי מסלול לאיתור קבצים זמניים, כפילויות SHA-256, APK ישנים ותיקיות ריקות. ניתן להעביר את כל ההמלצות למרכז האישורים לבדיקתך.",
        actionTag = "COMMANDER_CLEANUP_PLAN",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.STAGE_CLEANUP_PLAN_PROPOSALS,
            title = "בנה תוכנית ניקוי וארגון במרכז האישורים",
            description = "הוספת הצעות ניקוי מדורגות לאישור מפורש.",
            requiresConfirmation = true
          ),
        plannedSteps =
          listOf(
            "סריקה מלאה לפי 3 רמות סיכון",
            "הפרדה בין ניקוי בטוח לפריטים הדורשים בדיקה",
            "הגשת תוכנית מפורטת למרכז האישורים"
          )
      )
    }

    if (q.contains("רופא") || q.contains("ציון בריאות") || q.contains("התחממ")) {
      return AssistantReply(
        replyText =
          "ציון בריאות המכשיר הנוכחי הוא ${telemetry.healthScore}% (${telemetry.healthStatusLabel}). אעבור למסך רופא המכשיר לצפייה בנוסחת החישוב ובכל בדיקות האבחון.",
        actionTag = "COMMANDER_DOCTOR",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.NAVIGATE_DEVICE_DOCTOR,
            title = "פתח את רופא המכשיר (Device Doctor)",
            description = "פירוט ניקוד הבריאות ו-12 בדיקות מערכת.",
            requiresConfirmation = false
          )
      )
    }

    if (q.contains("אישור") || q.contains("ביטול") || q.contains("גיבוי")) {
      return AssistantReply(
        replyText =
          "אפתח את מרכז האישורים, הגיבויים וההיסטוריה כדי שתוכל לאשר, לדחות, לגבות ל-SD או לבטל פעולות הפיכות.",
        actionTag = "COMMANDER_APPROVALS",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.NAVIGATE_APPROVAL_CENTER,
            title = "מעבר למרכז האישורים והגיבוי",
            description = "ניהול הצעות ממתינות, גיבוי מאומת ו-Undo.",
            requiresConfirmation = false
          )
      )
    }

    // 2. Clean device request
    if (q.contains("נקה") ||
      q.contains("ניקוי") ||
      q.contains("לנקות") ||
      q.contains("מנקה") ||
      q.contains("מטמון") ||
      q.contains("clean")
    ) {
      return AssistantReply(
        replyText =
          "מוכן לביצוע סריקה וניקוי מערכת אמיתי. ב-Android 10 אנקה את מטמון NEXUS ואת הקבצים הזמניים בתיקיות שאישרת, וכן אפנה אותך למטמון אפליקציות אחרות. נא אשר פתיחת תהליך הניקוי.",
        actionTag = "CLEAN_REQUEST",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.REQUEST_START_CLEAN,
            title = "אישור הפעלת סריקה וניקוי",
            description = "סריקת אחסון בטוחה וזיהוי קבצים מיותרים ללא מחיקת מידע אישי.",
            requiresConfirmation = true
          ),
        plannedSteps =
          listOf(
            "סריקת מטמון פנימי של NEXUS ותיקיות SAF",
            "הצגת קבצים זמניים, כפולים וגדולים לאישור",
            "ניקוי מאושר ומדידת שטח שהתפנה בפועל"
          )
      )
    }

    // 3. Large apps / storage heavy apps
    if ((q.contains("אפליקצ") || q.contains("יישומ") || q.contains("תוכנ")) &&
      (q.contains("מקום") || q.contains("גדול") || q.contains("נפח") || q.contains("כבד"))
    ) {
      val topApps =
        apps
          .sortedByDescending { it.totalSizeBytes }
          .take(5)
          .joinToString("\n") { "• ${it.appName}: ${formatBytes(it.totalSizeBytes)}" }
      val note =
        if (!telemetry.hasUsageAccessPermission) {
          "\n\nהערה: גישה לנתוני שימוש כבויה, לכן מוצג נפח APK בלבד. ניתן להפעיל גישה זו למדידה מלאה של נתונים ומטמון."
        } else ""
      return AssistantReply(
        replyText =
          if (topApps.isNotBlank()) {
            "הנה 5 האפליקציות התופסות את הנפח הרב ביותר בטאבלט שלך:\n$topApps$note"
          } else {
            "רשימת האפליקציות עדיין נטענת. ניתן לעבור למסך האפליקציות למיון מלא לפי נפח."
          },
        actionTag = "APPS_TOP_STORAGE",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.NAVIGATE_APPS_BY_SIZE,
            title = "פתח את App Intelligence ממוין לפי נפח",
            description = "הצגת כל האפליקציות לפי סדר גודל.",
            requiresConfirmation = false
          ),
        plannedSteps = listOf("מיון חבילות מותקנות לפי נפח כולל", "מעבר למסך App Intelligence")
      )
    }

    // 4. Permissions & security check
    if (q.contains("הרשא") || q.contains("אבטח") || q.contains("מצלמ") || q.contains("מיקרופ") || q.contains("פרטיות")) {
      val reportSummary =
        if (securityReport != null) {
          "תוצאות ביקורת הרשאות אמיתית (${securityReport.totalAppsAudited} אפליקציות):\n" +
            "• גישה למצלמה: ${securityReport.cameraAppsCount} אפליקציות\n" +
            "• גישה למיקרופון: ${securityReport.micAppsCount} אפליקציות\n" +
            "• גישה למיקום: ${securityReport.locationAppsCount} אפליקציות\n" +
            "• הרשאות מיוחדות / רקע: ${securityReport.specialPermissionAppsCount} אפליקציות"
        } else {
          "מבצע בדיקת הרשאות across האפליקציות המותקנות בטאבלט."
        }
      return AssistantReply(
        replyText = reportSummary,
        actionTag = "SECURITY_AUDIT",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.NAVIGATE_SECURITY,
            title = "מעבר למרכז האבטחה המלא",
            description = "צפייה בפירוט האפליקציות וניהול ההרשאות בהגדרות Android.",
            requiresConfirmation = false
          ),
        plannedSteps = listOf("בדיקת הרשאות מצלמה, מיקרופון ומיקום", "הצגת ממצאים במרכז האבטחה")
      )
    }

    // 5. Battery status or settings
    if (q.contains("סולל") || q.contains("טמפרטור") || q.contains("טעינ") || q.contains("battery")) {
      val openSettings = q.contains("פתח") || q.contains("הגדר")
      val b = telemetry.battery
      val reply =
        "מצב הסוללה כעת: ${b.levelPercent}% (${b.chargeSource}), טמפרטורה ${String.format(Locale.US, "%.1f", b.temperatureC)}°C, בריאות: ${b.healthLabel}." +
          if (openSettings) "\nהאם לפתוח את הגדרות הסוללה הרשמיות של המערכת?" else ""
      return AssistantReply(
        replyText = reply,
        actionTag = if (openSettings) "OPEN_BATTERY_SETTINGS" else "BATTERY_STATUS",
        pendingAction =
          if (openSettings) {
            PendingAssistantAction(
              actionType = AssistantActionType.OPEN_BATTERY_SETTINGS,
              title = "אישור פתיחת הגדרות סוללה",
              description = "מעבר למסך ניהול צריכת החשמל של Android.",
              requiresConfirmation = true
            )
          } else {
            PendingAssistantAction(
              actionType = AssistantActionType.NAVIGATE_BATTERY,
              title = "פתח את מרכז הסוללה",
              description = "גרף טמפרטורה ואחוזים לאורך זמן.",
              requiresConfirmation = false
            )
          },
        plannedSteps =
          if (openSettings) listOf("אימות מצב סוללה נוכחי", "בקשת אישור לפתיחת הגדרות סוללה")
          else listOf("קריאת חיישן סוללה וטמפרטורה", "מעבר למרכז הסוללה")
      )
    }

    // 6. Internet / Wi-Fi settings
    if (q.contains("אינטרנט") || q.contains("wi-fi") || q.contains("wifi") || q.contains("רשת") || q.contains("ווייפיי")) {
      val net = telemetry.network
      val statusLine =
        if (net.isConnected) "המכשיר מחובר דרך ${net.transportLabel}."
        else "המכשיר אינו מחובר כרגע לרשת פעילה."
      return AssistantReply(
        replyText = "$statusLine\nמגבלות אבטחה של Android 10 מונעות הדלקה/כיבוי שקט של Wi-Fi, ולכן אפתח עבורך את פאנל האינטרנט הרשמי של המערכת.",
        actionTag = "OPEN_INTERNET_PANEL",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.OPEN_INTERNET_SETTINGS,
            title = "אישור פתיחת פאנל אינטרנט ו-Wi-Fi",
            description = "פתיחת פאנל הקישוריות הרשמי של Android 10.",
            requiresConfirmation = true
          ),
        plannedSteps = listOf("בדיקת חיבור רשת פעיל", "פתיחת פאנל הקישוריות הרשמי באישורך")
      )
    }

    // 7. Storage status
    if (q.contains("אחסון") || q.contains("זיכרון") || q.contains("מקום פנוי") || q.contains("storage")) {
      val s = telemetry.storage
      val r = telemetry.ram
      return AssistantReply(
        replyText =
          "מצב האחסון הפנימי:\n" +
            "• פנוי: ${formatBytes(s.freeBytes)} מתוך ${formatBytes(s.totalBytes)} (${100 - s.usedPercent}% פנוי)\n" +
            "• בשימוש: ${formatBytes(s.usedBytes)} (${s.usedPercent}%)\n" +
            "• זיכרון RAM זמין: ${formatBytes(r.availableBytes)} מתוך ${formatBytes(r.totalBytes)} (${r.usedPercent}% בשימוש)",
        actionTag = "STORAGE_REPORT",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.OPEN_STORAGE_SETTINGS,
            title = "פתיחת מסך האחסון של Android",
            description = "לצפייה ובחירת ניקוי במנהל האחסון המובנה.",
            requiresConfirmation = true
          ),
        plannedSteps = listOf("מדידת StatFs ואחסון זמין", "מדידת RAM פנוי", "קישור למסך האחסון הרשמי")
      )
    }

    // 8. Full tablet health / diagnostic check
    if (q.contains("מצב") || q.contains("בדוק") || q.contains("אבחון") || q.contains("טאבלט") || q.contains("בריאות") || q.contains("שלום")) {
      val s = telemetry.storage
      val r = telemetry.ram
      val b = telemetry.battery
      val d = telemetry.device
      val issuesText =
        if (telemetry.issues.isEmpty()) "לא זוהו חריגות מערכת."
        else "התראות פעילות (${telemetry.issues.size}): ${telemetry.issues.first().title}"
      return AssistantReply(
        replyText =
          "דוח מצב חי עבור ${d.manufacturer} ${d.model} (Android ${d.androidRelease}):\n" +
            "• ציון בריאות מערכת: ${telemetry.healthScore}% — ${telemetry.healthStatusLabel}\n" +
            "• סוללה: ${b.levelPercent}% (${b.chargeSource}, ${String.format(Locale.US, "%.1f", b.temperatureC)}°C)\n" +
            "• אחסון פנוי: ${formatBytes(s.freeBytes)} (${s.usedPercent}% בשימוש)\n" +
            "• זיכרון RAM: ${r.usedPercent}% בשימוש (${formatBytes(r.availableBytes)} פנוי)\n" +
            "• רשת: ${telemetry.network.transportLabel}\n" +
            "• $issuesText",
        actionTag = "FULL_DIAGNOSTIC",
        pendingAction =
          PendingAssistantAction(
            actionType = AssistantActionType.RUN_SYSTEM_CHECK,
            title = "רענן מדידות ורשום בדוח",
            description = "ביצוע מדידת טלמטריה עדכנית ושמירתה בהיסטוריה.",
            requiresConfirmation = false
          ),
        plannedSteps = listOf("איסוף מדדי סוללה, RAM, אחסון ורשת", "שמירת תמונת מצב בהיסטוריה")
      )
    }

    return AssistantReply(
      replyText =
        "הבנתי את ההודעה: \"$rawInput\".\nאני פועל באופן מקומי ומאובטח ללא תלות באינטרנט. נסה פקודות כמו:\n• \"בדוק את מצב הטאבלט שלי\"\n• \"תמצא לי את כל הסרטונים הכפולים\"\n• \"תארגן לי את תיקיית ההורדות\"\n• \"תבדוק את כרטיס הזיכרון\"\n• \"תכין לי תוכנית לניקוי המכשיר\"\n• \"רופא המכשיר\" או \"פתח את הגדרות הסוללה\"",
      actionTag = "HELP_HINT"
    )
  }
}

data class VoiceOptionInfo(
  val name: String,
  val localeTag: String,
  val isNetworkRequired: Boolean,
  val labelHe: String
)

class AssistantEngine(context: Context) {

  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var onSpeakingChanged: ((Boolean) -> Unit)? = null
  private var onPausedChanged: ((Boolean) -> Unit)? = null
  private var speechRate: Float = 1.0f
  private var speechPitch: Float = 1.0f
  private var selectedVoiceName: String? = null

  private val sentenceLock = Any()
  private var queuedSentences: List<String> = emptyList()
  private var nextSentenceIndex: Int = 0
  private var isPausedFlag: Boolean = false
  private var activeBatchId: Long = 0L

  init {
    tts =
      TextToSpeech(context.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          val hebrewLocale = Locale.forLanguageTag("he-IL")
          val result = tts?.setLanguage(hebrewLocale)
          if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED
          ) {
            tts?.language = Locale.getDefault()
          }
          ttsReady = true
          applySpeechConfigInternal()
        }
      }.apply {
        setOnUtteranceProgressListener(
          object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
              onSpeakingChanged?.invoke(true)
            }

            override fun onDone(utteranceId: String?) {
              handleUtteranceFinished(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
              synchronized(sentenceLock) {
                isPausedFlag = false
                queuedSentences = emptyList()
              }
              onPausedChanged?.invoke(false)
              onSpeakingChanged?.invoke(false)
            }
          }
        )
      }
  }

  private fun handleUtteranceFinished(utteranceId: String?) {
    if (utteranceId == null) {
      onSpeakingChanged?.invoke(false)
      return
    }
    var shouldPlayNext = false
    var nextText: String? = null
    var nextUid: String? = null

    synchronized(sentenceLock) {
      if (isPausedFlag) return
      val expectedPrefix = "nexus_tts_${activeBatchId}_"
      if (utteranceId.startsWith(expectedPrefix)) {
        nextSentenceIndex++
        if (nextSentenceIndex < queuedSentences.size) {
          shouldPlayNext = true
          nextText = queuedSentences[nextSentenceIndex]
          nextUid = "nexus_tts_${activeBatchId}_${nextSentenceIndex}"
        } else {
          queuedSentences = emptyList()
          nextSentenceIndex = 0
        }
      }
    }

    if (shouldPlayNext && nextText != null && nextUid != null) {
      tts?.speak(nextText, TextToSpeech.QUEUE_FLUSH, null, nextUid)
    } else {
      onSpeakingChanged?.invoke(false)
    }
  }

  fun setSpeakingListener(listener: (Boolean) -> Unit) {
    onSpeakingChanged = listener
  }

  fun setPausedListener(listener: (Boolean) -> Unit) {
    onPausedChanged = listener
  }

  fun getAvailableVoices(): List<VoiceOptionInfo> {
    val engine = tts ?: return emptyList()
    val rawVoices = runCatching { engine.voices }.getOrNull() ?: return emptyList()
    return rawVoices
      .filter { v ->
        val lang = v.locale?.language?.lowercase(Locale.US).orEmpty()
        lang == "he" || lang == "iw" || lang == "en"
      }
      .sortedWith(
        compareByDescending<android.speech.tts.Voice> {
          val l = it.locale?.language?.lowercase(Locale.US).orEmpty()
          l == "he" || l == "iw"
        }.thenBy { it.isNetworkConnectionRequired }
      )
      .take(16)
      .map { v ->
        val langTag = v.locale?.toLanguageTag().orEmpty()
        val langDisplay =
          when (v.locale?.language?.lowercase(Locale.US)) {
            "he", "iw" -> "עברית"
            else -> v.locale?.displayLanguage ?: langTag
          }
        val mode = if (v.isNetworkConnectionRequired) "מקוון" else "מקומי"
        VoiceOptionInfo(
          name = v.name,
          localeTag = langTag,
          isNetworkRequired = v.isNetworkConnectionRequired,
          labelHe = "$langDisplay ($mode) • ${v.name.takeLast(14)}"
        )
      }
  }

  fun setSpeechConfig(rate: Float, pitch: Float, voiceName: String?) {
    speechRate = rate.coerceIn(0.6f, 1.8f)
    speechPitch = pitch.coerceIn(0.7f, 1.5f)
    selectedVoiceName = voiceName
    applySpeechConfigInternal()
  }

  private fun applySpeechConfigInternal() {
    val engine = tts ?: return
    if (!ttsReady) return
    runCatching { engine.setSpeechRate(speechRate) }
    runCatching { engine.setPitch(speechPitch) }
    val targetName = selectedVoiceName
    if (!targetName.isNullOrBlank()) {
      runCatching {
        engine.voices?.firstOrNull { it.name == targetName }?.let { matched ->
          engine.voice = matched
        }
      }
    }
  }

  fun speak(text: String) {
    if (!ttsReady) return
    val sentences =
      text
        .split(Regex("(?<=[.!?\n])\\s+"))
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .ifEmpty { listOf(text.trim()) }
    if (sentences.isEmpty() || sentences.first().isBlank()) return

    val uid: String
    synchronized(sentenceLock) {
      activeBatchId++
      queuedSentences = sentences
      nextSentenceIndex = 0
      isPausedFlag = false
      uid = "nexus_tts_${activeBatchId}_0"
    }
    onPausedChanged?.invoke(false)
    applySpeechConfigInternal()
    tts?.speak(sentences.first(), TextToSpeech.QUEUE_FLUSH, null, uid)
  }

  fun pauseSpeaking(): Boolean {
    synchronized(sentenceLock) {
      if (queuedSentences.isEmpty() || nextSentenceIndex >= queuedSentences.size) {
        return false
      }
      isPausedFlag = true
    }
    tts?.stop()
    onSpeakingChanged?.invoke(false)
    onPausedChanged?.invoke(true)
    return true
  }

  fun resumeSpeaking(): Boolean {
    if (!ttsReady) return false
    val textToSpeak: String
    val uid: String
    synchronized(sentenceLock) {
      if (!isPausedFlag || nextSentenceIndex >= queuedSentences.size) {
        isPausedFlag = false
        onPausedChanged?.invoke(false)
        return false
      }
      isPausedFlag = false
      textToSpeak = queuedSentences[nextSentenceIndex]
      uid = "nexus_tts_${activeBatchId}_${nextSentenceIndex}"
    }
    onPausedChanged?.invoke(false)
    tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, uid)
    return true
  }

  fun stopSpeaking() {
    synchronized(sentenceLock) {
      queuedSentences = emptyList()
      nextSentenceIndex = 0
      isPausedFlag = false
      activeBatchId++
    }
    tts?.stop()
    onPausedChanged?.invoke(false)
    onSpeakingChanged?.invoke(false)
  }

  fun shutdown() {
    onSpeakingChanged = null
    onPausedChanged = null
    tts?.stop()
    tts?.shutdown()
    tts = null
    ttsReady = false
  }

  fun processCommand(
    rawInput: String,
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    customAutomations: List<AutomationEntity>
  ): AssistantReply =
    AssistantCommandParser.parseAndRespond(
      rawInput = rawInput,
      telemetry = telemetry,
      apps = apps,
      securityReport = securityReport,
      customAutomations = customAutomations
    )
}
