package com.example.data.worker

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.local.ActionAuditEntity
import com.example.data.local.AutomationEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.PreferencesManager
import com.example.data.model.AutomationStepType
import com.example.data.system.AppIntelligenceProvider
import com.example.data.system.DeepCleanEngine
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.SecurityAuditor
import com.example.data.system.SystemTelemetryProvider
import com.example.data.system.formatBytes
import com.example.ui.widget.NexusCommandWidget
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first

class NexusMonitorWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    return try {
      val prefs = PreferencesManager(applicationContext)
      val folders = prefs.safTreeUrisFlow.first()
      val telemetryProvider = SystemTelemetryProvider(applicationContext)
      val telemetry = telemetryProvider.captureTelemetry(folders.size)

      // Always keep the home-screen Glance widget synchronized during background cycles
      runCatching { NexusCommandWidget().updateAll(applicationContext) }

      val alertsEnabled = prefs.backgroundAlertsEnabledFlow.first()
      val isManualTest = inputData.getBoolean(KEY_MANUAL_TEST, false)
      if (!alertsEnabled && !isManualTest) {
        return Result.success()
      }

      val now = System.currentTimeMillis()
      val lastNotified = prefs.lastThermalAlertMillisFlow.first()
      val cooldownMs = TimeUnit.HOURS.toMillis(2)
      val canNotify = isManualTest || (now - lastNotified) >= cooldownMs

      val b = telemetry.battery
      val s = telemetry.storage

      if (canNotify) {
        when {
          b.isAbnormal || b.temperatureC >= 42.0f -> {
            NexusNotificationHelper.postSystemAlertNotification(
              context = applicationContext,
              notificationId = NOTIF_THERMAL_ID,
              title = "NEXUS: התראת חום סוללה (${String.format(Locale.US, "%.1f", b.temperatureC)}°C)",
              body = b.alertMessage ?: "הטאבלט מתחמם (${String.format(Locale.US, "%.1f", b.temperatureC)}°C). מומלץ להקל על העומס ולבדוק את מרכז הסוללה.",
              targetRoute = "battery"
            )
            prefs.updateLastThermalAlertMillis(now)
          }
          b.levelPercent <= 15 && !b.isCharging -> {
            NexusNotificationHelper.postSystemAlertNotification(
              context = applicationContext,
              notificationId = NOTIF_BATTERY_LOW_ID,
              title = "NEXUS: סוללה חלשה (${b.levelPercent}%)",
              body = "נותרו ${b.levelPercent}% סוללה. מומלץ לחבר למטען או להפעיל חיסכון בסוללה.",
              targetRoute = "battery"
            )
            prefs.updateLastThermalAlertMillis(now)
          }
          s.usedPercent >= 92 -> {
            NexusNotificationHelper.postSystemAlertNotification(
              context = applicationContext,
              notificationId = NOTIF_STORAGE_ID,
              title = "NEXUS: אחסון פנימי כמעט מלא (${s.usedPercent}%)",
              body = "נותרו ${formatBytes(s.freeBytes)} פנויים. מומלץ להריץ ניקוי עמוק.",
              targetRoute = "deep_clean"
            )
            prefs.updateLastThermalAlertMillis(now)
          }
          isManualTest -> {
            NexusNotificationHelper.postSystemAlertNotification(
              context = applicationContext,
              notificationId = NOTIF_TEST_ID,
              title = "NEXUS: בדיקת ניטור הרקע תקינה",
              body = "ציון בריאות ${telemetry.healthScore}% • סוללה ${b.levelPercent}% (${String.format(Locale.US, "%.1f", b.temperatureC)}°C) • פנוי ${formatBytes(s.freeBytes)}.",
              targetRoute = "battery"
            )
          }
        }
      }

      // Evaluate active user-defined conditional reminders (battery low, hot, storage full)
      val db = NexusDatabase.getInstance(applicationContext)
      val activeReminders = db.reminderAlertDao().getActiveOnce()
      for (rem in activeReminders) {
        val lastFired = rem.lastTriggeredMillis ?: 0L
        if ((now - lastFired) < TimeUnit.MINUTES.toMillis(45)) continue
        val matchesCondition =
          when (rem.conditionKey) {
            "BATTERY_LOW" -> b.levelPercent <= 20 && !b.isCharging
            "BATTERY_HOT" -> b.temperatureC >= 40.5f || b.isAbnormal
            "STORAGE_FULL" -> s.usedPercent >= 88
            else -> false
          }
        if (matchesCondition) {
          db.reminderAlertDao().update(
            rem.copy(status = "TRIGGERED", lastTriggeredMillis = now)
          )
          NexusNotificationHelper.postReminderNotification(
            context = applicationContext,
            notificationId = 7100 + (rem.id % 400).toInt(),
            title = "תזכורת מותנית: ${rem.title}",
            body = rem.message.ifBlank { "התנאי ${rem.conditionKey} התקיים במכשיר." },
            targetRoute = rem.targetRoute
          )
        }
      }

      Result.success()
    } catch (_: Exception) {
      Result.retry()
    }
  }

  companion object {
    const val KEY_MANUAL_TEST = "manual_test"
    private const val NOTIF_THERMAL_ID = 4101
    private const val NOTIF_BATTERY_LOW_ID = 4102
    private const val NOTIF_STORAGE_ID = 4103
    private const val NOTIF_TEST_ID = 4104
  }
}

class NexusReminderWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val reminderId = inputData.getLong(KEY_REMINDER_ID, -1L)
    if (reminderId <= 0L) return Result.failure()

    return try {
      val db = NexusDatabase.getInstance(applicationContext)
      val rem = db.reminderAlertDao().getById(reminderId) ?: return Result.success()
      if (rem.status == "CANCELLED" || rem.status == "DISMISSED") return Result.success()

      val now = System.currentTimeMillis()
      val newStatus = if (rem.repeatIntervalHours > 0) "ACTIVE" else "TRIGGERED"
      db.reminderAlertDao().update(rem.copy(status = newStatus, lastTriggeredMillis = now))
      NexusNotificationHelper.postReminderNotification(
        context = applicationContext,
        notificationId = 7500 + (reminderId % 400).toInt(),
        title = "תזכורת NEXUS: ${rem.title}",
        body = rem.message.ifBlank { rem.title },
        targetRoute = rem.targetRoute
      )
      Result.success()
    } catch (_: Exception) {
      Result.retry()
    }
  }

  companion object {
    const val KEY_REMINDER_ID = "reminder_id"
  }
}

class NexusAutomationWorker(
  appContext: Context,
  params: WorkerParameters
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val automationId = inputData.getLong(KEY_AUTOMATION_ID, -1L)
    if (automationId <= 0L) return Result.failure()

    return try {
      val db = NexusDatabase.getInstance(applicationContext)
      val prefs = PreferencesManager(applicationContext)
      val automation = db.automationDao().getById(automationId) ?: return Result.success()
      if (automation.scheduleIntervalHours <= 0) return Result.success()

      val telemetryProvider = SystemTelemetryProvider(applicationContext)
      val folders = prefs.safTreeUrisFlow.first()
      val telemetry = telemetryProvider.captureTelemetry(folders.size)
      val deepClean = DeepCleanEngine(applicationContext, telemetryProvider)
      val appIntel = AppIntelligenceProvider(applicationContext, telemetryProvider)
      val securityAuditor = SecurityAuditor()

      val steps =
        automation.stepsSerialized.split(",").mapNotNull { token ->
          AutomationStepType.entries.firstOrNull { it.name == token.trim() }
        }

      val summaries = mutableListOf<String>()
      for (step in steps) {
        when (step) {
          AutomationStepType.SYSTEM_SCAN -> {
            val scan = deepClean.scanSystem(folders)
            summaries += "סריקה: ${formatBytes(scan.directReclaimableBytes)} לניקוי"
          }
          AutomationStepType.MAINTENANCE_REPORT -> {
            summaries += "בריאות ${telemetry.healthScore}%"
          }
          AutomationStepType.BATTERY_CHECK -> {
            val b = telemetry.battery
            summaries += "סוללה ${b.levelPercent}% (${String.format(Locale.US, "%.1f", b.temperatureC)}°C)"
          }
          AutomationStepType.SECURITY_AUDIT -> {
            val apps = appIntel.loadApps()
            val report = securityAuditor.buildAuditReport(apps, telemetry.device)
            summaries += "אבטחה: ${report.findings.size} ממצאים"
          }
          AutomationStepType.CLEAR_NEXUS_CACHE -> {
            val freed = deepClean.clearOwnCaches()
            summaries += "נוקה מטמון פנימי (${formatBytes(freed)})"
          }
          AutomationStepType.OPEN_STORAGE_SETTINGS,
          AutomationStepType.OPEN_BATTERY_SETTINGS,
          AutomationStepType.OPEN_NETWORK_SETTINGS -> {
            summaries += "${step.titleHe} (דולג ברקע — דורש מסך פתוח)"
          }
        }
      }

      val summaryLine = summaries.joinToString(" • ").ifBlank { "בוצעו בדיקות רקע" }
      val now = System.currentTimeMillis()
      db.automationDao().update(automation.copy(lastRunMillis = now))
      db.actionAuditDao().insert(
        ActionAuditEntity(
          timestampMillis = now,
          category = "אוטומציה מתוזמנת",
          actionTitle = automation.name,
          succeeded = true,
          details = summaryLine
        )
      )

      runCatching { NexusCommandWidget().updateAll(applicationContext) }
      NexusNotificationHelper.postAutomationCompletedNotification(
        context = applicationContext,
        notificationId = 5000 + (automationId % 500).toInt(),
        title = "NEXUS: הושלמה אוטומציה מתוזמנת — ${automation.name}",
        body = summaryLine
      )

      Result.success()
    } catch (_: Exception) {
      Result.retry()
    }
  }

  companion object {
    const val KEY_AUTOMATION_ID = "automation_id"
  }
}

object NexusWorkScheduler {
  private const val MONITOR_WORK_NAME = "nexus_thermal_battery_monitor"
  private const val MONITOR_TEST_WORK_NAME = "nexus_thermal_battery_test"

  fun syncThermalMonitor(context: Context, enabled: Boolean, intervalMinutes: Long) {
    val wm = WorkManager.getInstance(context)
    if (!enabled) {
      wm.cancelUniqueWork(MONITOR_WORK_NAME)
      return
    }
    val safeInterval = intervalMinutes.coerceAtLeast(15L)
    val request =
      PeriodicWorkRequestBuilder<NexusMonitorWorker>(safeInterval, TimeUnit.MINUTES).build()
    wm.enqueueUniquePeriodicWork(
      MONITOR_WORK_NAME,
      ExistingPeriodicWorkPolicy.UPDATE,
      request
    )
  }

  fun runImmediateMonitorCheck(context: Context) {
    val data = Data.Builder().putBoolean(NexusMonitorWorker.KEY_MANUAL_TEST, true).build()
    val request = OneTimeWorkRequestBuilder<NexusMonitorWorker>().setInputData(data).build()
    WorkManager.getInstance(context)
      .enqueueUniqueWork(MONITOR_TEST_WORK_NAME, ExistingWorkPolicy.REPLACE, request)
  }

  fun syncScheduledAutomation(context: Context, automation: AutomationEntity) {
    val wm = WorkManager.getInstance(context)
    val workName = automationWorkName(automation.id)
    if (automation.scheduleIntervalHours <= 0) {
      wm.cancelUniqueWork(workName)
      return
    }
    val data = Data.Builder().putLong(NexusAutomationWorker.KEY_AUTOMATION_ID, automation.id).build()
    val request =
      PeriodicWorkRequestBuilder<NexusAutomationWorker>(
          automation.scheduleIntervalHours.toLong().coerceAtLeast(1L),
          TimeUnit.HOURS
        )
        .setInputData(data)
        .build()
    wm.enqueueUniquePeriodicWork(workName, ExistingPeriodicWorkPolicy.UPDATE, request)
  }

  fun cancelScheduledAutomation(context: Context, automationId: Long) {
    WorkManager.getInstance(context).cancelUniqueWork(automationWorkName(automationId))
  }

  fun scheduleReminder(
    context: Context,
    reminderId: Long,
    delayMinutes: Long,
    repeatIntervalHours: Int
  ) {
    val wm = WorkManager.getInstance(context)
    val workName = reminderWorkName(reminderId)
    val data = Data.Builder().putLong(NexusReminderWorker.KEY_REMINDER_ID, reminderId).build()
    if (repeatIntervalHours > 0) {
      val req =
        PeriodicWorkRequestBuilder<NexusReminderWorker>(
            repeatIntervalHours.toLong().coerceAtLeast(1L),
            TimeUnit.HOURS
          )
          .setInputData(data)
          .build()
      wm.enqueueUniquePeriodicWork(workName, ExistingPeriodicWorkPolicy.UPDATE, req)
    } else {
      val req =
        OneTimeWorkRequestBuilder<NexusReminderWorker>()
          .setInitialDelay(delayMinutes.coerceAtLeast(1L), TimeUnit.MINUTES)
          .setInputData(data)
          .build()
      wm.enqueueUniqueWork(workName, ExistingWorkPolicy.REPLACE, req)
    }
  }

  fun cancelReminder(context: Context, reminderId: Long) {
    WorkManager.getInstance(context).cancelUniqueWork(reminderWorkName(reminderId))
  }

  private fun automationWorkName(id: Long): String = "nexus_scheduled_auto_$id"
  private fun reminderWorkName(id: Long): String = "nexus_reminder_$id"
}
