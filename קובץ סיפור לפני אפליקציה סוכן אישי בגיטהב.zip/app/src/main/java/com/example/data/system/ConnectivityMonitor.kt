package com.example.data.system

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NetworkStatusSnapshot(
  val isOnline: Boolean = true,
  val transportLabelHe: String = "בודק...",
  val isMetered: Boolean = false,
  val changedAtMillis: Long = 0L
)

data class OfflineCapabilityItem(
  val titleHe: String,
  val worksOffline: Boolean,
  val detailHe: String
)

data class PendingSyncTask(
  val id: String,
  val labelHe: String,
  val queuedAtMillis: Long
)

object OfflineCapabilityMatrix {
  val items: List<OfflineCapabilityItem> =
    listOf(
      OfflineCapabilityItem(
        titleHe = "סריקת אחסון, כרטיס SD וזיהוי כפילויות SHA-256",
        worksOffline = true,
        detailHe = "פועל 100% מקומית על הטאבלט."
      ),
      OfflineCapabilityItem(
        titleHe = "זיכרון חכם, למידה, משימות מקומיות, אוטומציות וגישה למסמכים/PDF",
        worksOffline = true,
        detailHe = "נשמר ב-Room ועובד גם ללא חיבור."
      ),
      OfflineCapabilityItem(
        titleHe = "תגובות מקומיות וסינון פקודות בעוזר האישי + TTS",
        worksOffline = true,
        detailHe = "מנוע הפקודות בעברית זמין בכל עת."
      ),
      OfflineCapabilityItem(
        titleHe = "שיחה קולית חיה, תמלול WAV ומודל Gemini ענן",
        worksOffline = false,
        detailHe = "דורש אינטרנט — כשמנותק, בקשות נכנסות לתור סנכרון מבוקר או עוברות למנוע המקומי."
      )
    )
}

class ConnectivityMonitor(context: Context) {
  private val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

  private val _status = MutableStateFlow(readCurrentStatus())
  val status: StateFlow<NetworkStatusSnapshot> = _status.asStateFlow()

  private val _pendingSyncQueue = MutableStateFlow<List<PendingSyncTask>>(emptyList())
  val pendingSyncQueue: StateFlow<List<PendingSyncTask>> = _pendingSyncQueue.asStateFlow()

  private var onReconnectedCallback: (() -> Unit)? = null

  private val networkCallback =
    object : ConnectivityManager.NetworkCallback() {
      override fun onAvailable(network: Network) {
        val wasOffline = !_status.value.isOnline
        _status.value = readCurrentStatus()
        if (wasOffline && _status.value.isOnline) {
          onReconnectedCallback?.invoke()
        }
      }

      override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
        val wasOffline = !_status.value.isOnline
        _status.value = readCurrentStatus()
        if (wasOffline && _status.value.isOnline) {
          onReconnectedCallback?.invoke()
        }
      }

      override fun onLost(network: Network) {
        _status.value = readCurrentStatus()
      }
    }

  init {
    runCatching {
      val req =
        NetworkRequest.Builder()
          .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
          .build()
      cm.registerNetworkCallback(req, networkCallback)
    }
  }

  fun setOnReconnectedListener(listener: () -> Unit) {
    onReconnectedCallback = listener
  }

  fun queueForControlledSync(id: String, labelHe: String) {
    val current = _pendingSyncQueue.value
    if (current.any { it.id == id }) return
    _pendingSyncQueue.value = current + PendingSyncTask(id, labelHe, System.currentTimeMillis())
  }

  fun clearSyncQueue() {
    _pendingSyncQueue.value = emptyList()
  }

  fun refreshNow(): NetworkStatusSnapshot {
    val snap = readCurrentStatus()
    _status.value = snap
    return snap
  }

  fun shutdown() {
    runCatching { cm.unregisterNetworkCallback(networkCallback) }
  }

  private fun readCurrentStatus(): NetworkStatusSnapshot {
    val active = runCatching { cm.activeNetwork }.getOrNull()
    val caps = active?.let { runCatching { cm.getNetworkCapabilities(it) }.getOrNull() }
    val online =
      caps != null &&
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    val label =
      when {
        !online -> "לא מחובר (Offline)"
        caps!!.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "סלולר"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "רשת קווית"
        else -> "מקוון"
      }
    val metered =
      caps != null && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    return NetworkStatusSnapshot(
      isOnline = online,
      transportLabelHe = label,
      isMetered = metered,
      changedAtMillis = System.currentTimeMillis()
    )
  }
}
