package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities =
    [
      CleanHistoryEntity::class,
      TelemetrySnapshotEntity::class,
      AssistantMessageEntity::class,
      AutomationEntity::class,
      ActionAuditEntity::class,
      ApprovalProposalEntity::class,
      UndoRecordEntity::class,
      BackupRecordEntity::class,
      MemoryEntryEntity::class,
      OrchestratorTaskEntity::class,
      LearningRecordEntity::class,
      ToolUsageEntity::class,
      ReminderAlertEntity::class
    ],
  version = 4,
  exportSchema = false
)
abstract class NexusDatabase : RoomDatabase() {
  abstract fun cleanHistoryDao(): CleanHistoryDao
  abstract fun telemetrySnapshotDao(): TelemetrySnapshotDao
  abstract fun assistantMessageDao(): AssistantMessageDao
  abstract fun automationDao(): AutomationDao
  abstract fun actionAuditDao(): ActionAuditDao
  abstract fun approvalProposalDao(): ApprovalProposalDao
  abstract fun undoRecordDao(): UndoRecordDao
  abstract fun backupRecordDao(): BackupRecordDao
  abstract fun memoryEntryDao(): MemoryEntryDao
  abstract fun orchestratorTaskDao(): OrchestratorTaskDao
  abstract fun learningRecordDao(): LearningRecordDao
  abstract fun toolUsageDao(): ToolUsageDao
  abstract fun reminderAlertDao(): ReminderAlertDao

  companion object {
    @Volatile private var INSTANCE: NexusDatabase? = null

    val MIGRATION_1_2 =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            "ALTER TABLE automations ADD COLUMN scheduleIntervalHours INTEGER NOT NULL DEFAULT 0"
          )
        }
      }

    val MIGRATION_2_3 =
      object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS approval_proposals (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              title TEXT NOT NULL,
              reasonHe TEXT NOT NULL,
              targetName TEXT NOT NULL,
              targetLocation TEXT NOT NULL,
              operationType TEXT NOT NULL,
              riskLevel TEXT NOT NULL,
              isReversible INTEGER NOT NULL,
              expectedOutcomeHe TEXT NOT NULL,
              sourceUriString TEXT,
              treeUriString TEXT,
              destTreeUriString TEXT,
              destFolderName TEXT,
              proposedNewName TEXT,
              packageName TEXT,
              bytesAffected INTEGER NOT NULL,
              status TEXT NOT NULL,
              resultMessageHe TEXT
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS undo_records (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              actionTitle TEXT NOT NULL,
              undoType TEXT NOT NULL,
              targetUriString TEXT,
              originalParentDocId TEXT,
              originalTreeUriString TEXT,
              previousName TEXT,
              backupManifestId INTEGER,
              isUndoable INTEGER NOT NULL,
              undone INTEGER NOT NULL,
              noteHe TEXT NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS backup_records (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              sourceLabel TEXT NOT NULL,
              sourceTreeUri TEXT NOT NULL,
              destTreeUri TEXT NOT NULL,
              destFolderDocId TEXT NOT NULL,
              destFolderName TEXT NOT NULL,
              fileCount INTEGER NOT NULL,
              totalBytes INTEGER NOT NULL,
              verifiedOk INTEGER NOT NULL,
              integritySummaryHe TEXT NOT NULL,
              manifestJson TEXT NOT NULL
            )
            """.trimIndent()
          )
        }
      }

    val MIGRATION_3_4 =
      object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS memory_entries (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              memoryType TEXT NOT NULL,
              title TEXT NOT NULL,
              content TEXT NOT NULL,
              categoryTag TEXT NOT NULL,
              canPersist INTEGER NOT NULL,
              importanceScore INTEGER NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              updatedAtMillis INTEGER NOT NULL,
              lastAccessedMillis INTEGER NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS orchestrator_tasks (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              goal TEXT NOT NULL,
              status TEXT NOT NULL,
              progressPercent INTEGER NOT NULL,
              currentAgent TEXT NOT NULL,
              currentStepLabel TEXT NOT NULL,
              stepsJson TEXT NOT NULL,
              resultSummary TEXT,
              errorMessage TEXT,
              requiresNetwork INTEGER NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              updatedAtMillis INTEGER NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS learning_records (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              category TEXT NOT NULL,
              targetKey TEXT NOT NULL,
              summaryHe TEXT NOT NULL,
              succeeded INTEGER NOT NULL,
              userRating INTEGER NOT NULL,
              reversiblePatchJson TEXT,
              undone INTEGER NOT NULL,
              createdAtMillis INTEGER NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS tool_usage (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              toolId TEXT NOT NULL,
              toolNameHe TEXT NOT NULL,
              succeeded INTEGER NOT NULL,
              latencyMs INTEGER NOT NULL,
              summaryHe TEXT NOT NULL,
              errorHe TEXT,
              timestampMillis INTEGER NOT NULL
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS reminder_alerts (
              id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              title TEXT NOT NULL,
              message TEXT NOT NULL,
              kind TEXT NOT NULL,
              triggerAtMillis INTEGER,
              repeatIntervalHours INTEGER NOT NULL,
              conditionKey TEXT NOT NULL,
              status TEXT NOT NULL,
              targetRoute TEXT NOT NULL,
              createdAtMillis INTEGER NOT NULL,
              lastTriggeredMillis INTEGER
            )
            """.trimIndent()
          )
        }
      }

    fun getInstance(context: Context): NexusDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                NexusDatabase::class.java,
                "nexus_command_db"
              )
              .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
