package com.example.data.system

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import com.example.data.model.ApkInspectionReport
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.DeviceDoctorReport
import com.example.data.model.DiagnosticCheckResult
import com.example.data.model.HealthScoreBreakdownItem
import com.example.data.model.HealthSeverity
import com.example.data.model.MaintenanceTaskItem
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SimilarAppGroup
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.SystemTelemetry
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DeviceDoctorCalculator {
  fun buildDoctorReport(
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    storageReport: SmartStorageScanReport?,
    hasNotificationPermission: Boolean
  ): DeviceDoctorReport {
    val breakdown = mutableListOf<HealthScoreBreakdownItem>()
    val checks = mutableListOf<DiagnosticCheckResult>()
    val recs = mutableListOf<String>()
    val maintenance = mutableListOf<MaintenanceTaskItem>()
    val smartRecs = mutableListOf<String>()

    var score = 100

    // 1. Internal Storage check
    val stPct = telemetry.storage.usedPercent
    when {
      stPct >= 92 -> {
        score -= 28
        breakdown +=
          HealthScoreBreakdownItem(
            "storage_crit",
            "אחסון פנימי קריטי ($stPct%)",
            -28,
            "פחות מ-8% פנוי עלול להאט מאוד את המערכת.",
            HealthSeverity.CRITICAL,
            "smart_storage"
          )
        recs += "פנה מיידית קבצים גדולים וכפולים במנהל האחסון החכם."
      }
      stPct >= 82 -> {
        score -= 15
        breakdown +=
          HealthScoreBreakdownItem(
            "storage_warn",
            "ניצולת אחסון גבוהה ($stPct%)",
            -15,
            "מומלץ לשמור לפחות 18% פנוי ליציבות מערכת.",
            HealthSeverity.WARNING,
            "smart_storage"
          )
        recs += "העבר סרטונים או תיקיות גדולות לכרטיס SD או בצע ניקוי חכם."
      }
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_storage",
        categoryTitleHe = "אחסון פנימי",
        statusTitleHe = if (stPct >= 82) "דורש פינוי ($stPct%)" else "תקין ($stPct% בשימוש)",
        detailHe =
          "פנוי ${formatBytes(telemetry.storage.freeBytes)} מתוך ${formatBytes(telemetry.storage.totalBytes)}.",
        recommendationHe =
          if (stPct >= 82) "פתח את מרכז הניקוי החכם או העבר קבצים לכרטיס SD."
          else "שטח האחסון תקין ומאפשר פעולה חלקה.",
        severity =
          when {
            stPct >= 92 -> HealthSeverity.CRITICAL
            stPct >= 82 -> HealthSeverity.WARNING
            else -> HealthSeverity.OPTIMAL
          },
        targetRoute = "smart_storage"
      )

    // 2. RAM & Performance check
    val ramPct = telemetry.ram.usedPercent
    when {
      telemetry.ram.isLowMemory || ramPct >= 88 -> {
        score -= 18
        breakdown +=
          HealthScoreBreakdownItem(
            "ram_crit",
            "עומס RAM כבד ($ramPct%)",
            -18,
            "המכשיר במצב זיכרון נמוך שעלול לגרום להאטות.",
            HealthSeverity.CRITICAL,
            "apps"
          )
        recs += "סגור אפליקציות רקע כבדות ובדוק אפליקציות עם צריכת זיכרון גבוהה."
      }
      ramPct >= 78 -> {
        score -= 8
        breakdown +=
          HealthScoreBreakdownItem(
            "ram_warn",
            "ניצולת RAM בינונית-גבוהה ($ramPct%)",
            -8,
            "פחות מ-22% זיכרון פנוי זמין כרגע.",
            HealthSeverity.WARNING,
            "apps"
          )
      }
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_ram",
        categoryTitleHe = "ביצועים וזיכרון RAM",
        statusTitleHe = if (ramPct >= 78) "עמוס ($ramPct%)" else "מאוזן ($ramPct%)",
        detailHe =
          "זמין: ${formatBytes(telemetry.ram.availableBytes)} מתוך ${formatBytes(telemetry.ram.totalBytes)}.",
        recommendationHe =
          if (ramPct >= 78) "צמצם אפליקציות פעילות ברקע." else "זיכרון העבודה במצב בריא.",
        severity = if (ramPct >= 88) HealthSeverity.CRITICAL else if (ramPct >= 78) HealthSeverity.WARNING else HealthSeverity.OPTIMAL,
        targetRoute = "apps"
      )

    // 3. Battery & Thermal check
    val tempC = telemetry.battery.temperatureC
    if (telemetry.battery.isAbnormal || tempC >= 43f) {
      score -= 18
      breakdown +=
        HealthScoreBreakdownItem(
          "battery_thermal",
          "התראת סוללה / התחממות (${String.format("%.1f", tempC)}°C)",
          -18,
          telemetry.battery.alertMessage ?: "טמפרטורת סוללה גבוהה או מצב סוללה חריג.",
          HealthSeverity.CRITICAL,
          "battery"
        )
      recs += "הפחת בהירות/עומס והימנע מטעינה רציפה בזמן עבודה כבדה."
    } else if (tempC >= 38f || (telemetry.battery.levelPercent <= 15 && !telemetry.battery.isCharging)) {
      score -= 8
      breakdown +=
        HealthScoreBreakdownItem(
          "battery_notice",
          "סוללה חלשה או חמימה (${telemetry.battery.levelPercent}%, ${String.format("%.1f", tempC)}°C)",
          -8,
          "מומלץ להפעיל חיסכון בחשמל או לחבר למטען.",
          HealthSeverity.NOTICE,
          "battery"
        )
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_battery_thermal",
        categoryTitleHe = "סוללה והתחממות",
        statusTitleHe = "${telemetry.battery.levelPercent}% • ${String.format("%.1f", tempC)}°C (${telemetry.battery.healthLabel})",
        detailHe =
          "מקור מתח: ${telemetry.battery.chargeSource}, מתח: ${telemetry.battery.voltageMv} mV.",
        recommendationHe = telemetry.battery.alertMessage ?: "טמפרטורה ומצב הסוללה בטווח התקין.",
        severity =
          if (telemetry.battery.isAbnormal) HealthSeverity.CRITICAL
          else if (tempC >= 38f) HealthSeverity.WARNING
          else HealthSeverity.OPTIMAL,
        targetRoute = "battery"
      )

    // 4. Security lock & sensitive apps
    if (!telemetry.device.isDeviceSecureLock) {
      score -= 10
      breakdown +=
        HealthScoreBreakdownItem(
          "lock_missing",
          "נעילת מסך לא מוגדרת",
          -10,
          "הטאבלט אינו מוגן ב-PIN, תבנית או ביומטריה.",
          HealthSeverity.WARNING,
          "security"
        )
      recs += "הגדר קוד PIN או טביעת אצבע בהגדרות האבטחה."
    }
    val highRiskPermsCount = securityReport?.specialPermissionAppsCount ?: 0
    if (highRiskPermsCount >= 3) {
      score -= 5
      breakdown +=
        HealthScoreBreakdownItem(
          "sec_special",
          "אפליקציות עם הרשאות מיוחדות ($highRiskPermsCount)",
          -5,
          "קיימות מספר אפליקציות עם מיקום ברקע, שכבת-על או התקנת חבילות.",
          HealthSeverity.NOTICE,
          "security"
        )
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_security",
        categoryTitleHe = "אבטחת מכשיר והרשאות אפליקציות",
        statusTitleHe = if (!telemetry.device.isDeviceSecureLock) "נדרש שיפור" else "מגובה ומאובטח",
        detailHe =
          "אפליקציות שנבדקו: ${securityReport?.totalAppsAudited ?: apps.size}, הרשאות מיוחדות: $highRiskPermsCount.",
        recommendationHe =
          "עבור על הרשאות מצלמה, מיקרופון והתקנה מוגבלת במרכז האבטחה.",
        severity = if (!telemetry.device.isDeviceSecureLock) HealthSeverity.WARNING else HealthSeverity.OPTIMAL,
        targetRoute = "security"
      )

    // 5. Dormant & heavy apps
    val dormantCount = apps.count { it.isDormant }
    val heavyAppsCount = apps.count { !it.isSystemApp && it.totalSizeBytes >= 300L * 1024L * 1024L }
    if (dormantCount >= 4) {
      score -= 5
      breakdown +=
        HealthScoreBreakdownItem(
          "dormant_apps",
          "אפליקציות רדומות ($dormantCount)",
          -5,
          "אפליקציות שלא נפתחו מעל 30 יום ותופסות אחסון.",
          HealthSeverity.NOTICE,
          "apps"
        )
      maintenance +=
        MaintenanceTaskItem(
          id = "maint_dormant",
          titleHe = "סקירת $dormantCount אפליקציות ללא שימוש",
          reasonHe = "שחרור מקום והקטנת עומס רקע",
          priorityHe = "בינונית",
          actionLabelHe = "פתח מנהל אפליקציות",
          targetRoute = "apps"
        )
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_apps",
        categoryTitleHe = "אפליקציות כבדות וללא שימוש",
        statusTitleHe = "$heavyAppsCount כבדות • $dormantCount רדומות",
        detailHe =
          if (telemetry.hasUsageAccessPermission) "מדידת שימוש פעילה ומאומתת."
          else "גישת נתוני שימוש כבויה — חלק מזיהוי הרדומות והמטמון מוגבל.",
        recommendationHe = "בדוק אפליקציות כבדות או כפולות בתפקידן במנהל האפליקציות.",
        severity = if (dormantCount >= 4) HealthSeverity.NOTICE else HealthSeverity.OPTIMAL,
        targetRoute = "apps"
      )

    // 6. Duplicates, SD Card & Unreadable files
    val dupCount = storageReport?.duplicateGroups?.size ?: 0
    val mediaIssuesCount = storageReport?.mediaIssues?.size ?: 0
    val unreadable = storageReport?.unreadableCount ?: 0
    val sdMounted = storageReport?.hasSdCard == true
    val sdAuthorized = storageReport?.volumes?.firstOrNull { it.kind == com.example.data.model.StorageVolumeKind.SD_CARD }?.authorizedTreeUris?.isNotEmpty() == true

    if (dupCount > 0) {
      score -= 4
      breakdown +=
        HealthScoreBreakdownItem(
          "dup_waste",
          "קבצים כפולים (${formatBytes(storageReport?.totalDuplicateWasteBytes ?: 0L)})",
          -4,
          "זוהו $dupCount קבוצות של עותקים זהים ב-SHA-256.",
          HealthSeverity.NOTICE,
          "ai_file_manager"
        )
      smartRecs += "נמצאו $dupCount קבוצות כפילויות — מומלץ לאשר מחיקת עותקים מיותרים."
    }
    if (mediaIssuesCount > 0 || unreadable > 0) {
      score -= 6
      breakdown +=
        HealthScoreBreakdownItem(
          "unreadable_media",
          "קבצים לא קריאים או פגומים (${mediaIssuesCount + unreadable})",
          -6,
          "זוהו שגיאות קריאה או קבצי מדיה לא תקינים בסריקה.",
          HealthSeverity.WARNING,
          "smart_storage"
        )
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_sd_saf",
        categoryTitleHe = "כרטיס SD והרשאות SAF",
        statusTitleHe =
          when {
            sdMounted && sdAuthorized -> "כרטיס SD מחובר ומאושר לסריקה"
            sdMounted -> "כרטיס SD זוהה — נדרשת הרשאת תיקייה"
            else -> "כרטיס SD לא מחובר"
          },
        detailHe =
          "תיקיות מאושרות: ${telemetry.authorizedFolderCount}, שגיאות קריאה: $unreadable, מדיה חריגה: $mediaIssuesCount.",
        recommendationHe =
          if (sdMounted && !sdAuthorized) "בחר את כרטיס ה-SD במסך האחסון החכם כדי לנהל קבצים בו."
          else "סטטוס גישת SAF ו-SD מעודכן.",
        severity = if (unreadable > 0 || (sdMounted && !sdAuthorized)) HealthSeverity.NOTICE else HealthSeverity.OPTIMAL,
        targetRoute = "smart_storage"
      )

    // 7. Android Version & Samsung SM-T545 Compatibility + Missing Permissions
    val missingPerms = mutableListOf<String>()
    if (!telemetry.hasUsageAccessPermission) missingPerms += "נתוני שימוש"
    if (telemetry.authorizedFolderCount == 0) missingPerms += "תיקיית SAF"
    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      missingPerms += "התראות"
    }
    if (missingPerms.isNotEmpty()) {
      score -= 4
      breakdown +=
        HealthScoreBreakdownItem(
          "missing_perms",
          "הרשאות אבחון חסרות (${missingPerms.joinToString(", ")})",
          -4,
          "מאפשרות סריקה מלאה של קבצים, מטמון אפליקציות והתראות רקע.",
          HealthSeverity.NOTICE,
          "system_control"
        )
    }
    checks +=
      DiagnosticCheckResult(
        id = "chk_compat",
        categoryTitleHe = "גרסת Android ותאימות טאבלט",
        statusTitleHe = "Android ${telemetry.device.androidRelease} (API ${telemetry.device.sdkInt})",
        detailHe =
          "דגם: ${telemetry.device.manufacturer} ${telemetry.device.model}, תלאי אבטחה: ${telemetry.device.securityPatch}.",
        recommendationHe =
          if (telemetry.device.sdkInt >= 29)
            "תאימות מלאה ל-Scoped Storage ול-SAF ב-Android 10 ומעלה."
          else "גרסת Android ותיקה — חלק מתכונות הבידוד מוגבלות.",
        severity = HealthSeverity.OPTIMAL,
        targetRoute = "system_control"
      )

    // Maintenance Planner & Smart Recommendations
    if (storageReport == null || telemetry.authorizedFolderCount == 0) {
      maintenance +=
        MaintenanceTaskItem(
          id = "maint_saf",
          titleHe = "אישור תיקיית הורדות / SD לסריקה",
          reasonHe = "מאפשר למנוע AI לזהות כפילויות, APK ישנים ולסדר הורדות",
          priorityHe = "גבוהה",
          actionLabelHe = "הענק גישת תיקייה",
          targetRoute = "smart_storage"
        )
    }
    if (dupCount > 0) {
      maintenance +=
        MaintenanceTaskItem(
          id = "maint_dups",
          titleHe = "טיפול ב-$dupCount קבוצות קבצים כפולים",
          reasonHe = "חיסכון פוטנציאלי של ${formatBytes(storageReport?.totalDuplicateWasteBytes ?: 0L)}",
          priorityHe = "גבוהה",
          actionLabelHe = "בדוק כפילויות",
          targetRoute = "ai_file_manager"
        )
    }
    if (!telemetry.device.isDeviceSecureLock) {
      maintenance +=
        MaintenanceTaskItem(
          id = "maint_lock",
          titleHe = "הגדרת נעילת מסך מאובטחת",
          reasonHe = "שמירה על פרטיות הקבצים והגיבויים בטאבלט",
          priorityHe = "גבוהה",
          actionLabelHe = "פתח מרכז אבטחה",
          targetRoute = "security"
        )
    }
    if (smartRecs.isEmpty()) {
      smartRecs += "מצב הטאבלט יציב. מומלץ לבצע סריקה שבועית ולשמור גיבוי תקופתי לכרטיס SD."
    }
    if (recs.isEmpty()) {
      recs += "לא זוהו תקלות קריטיות — המכשיר פועל בצורה תקינה."
    }

    val boundedScore = score.coerceIn(15, 100)
    val totalDeducted = breakdown.sumOf { -it.pointsDelta }
    val formulaHe =
      "ציון הבסיס הוא 100 נקודות. הופחתו סך הכל $totalDeducted נקודות לפי ${breakdown.size} ממצאים אמיתיים מהמכשיר (אחסון, RAM, סוללה, אבטחה, אפליקציות רדומות וכפילויות)."

    return DeviceDoctorReport(
      diagnosedAtMillis = System.currentTimeMillis(),
      totalScore = boundedScore,
      scoreFormulaSummaryHe = formulaHe,
      scoreBreakdown = breakdown,
      checks = checks,
      recommendations = recs,
      maintenancePlan = maintenance,
      smartRecommendations = smartRecs
    )
  }

  fun groupSimilarRoleApps(apps: List<AppDiagnosticInfo>): List<SimilarAppGroup> {
    val userApps = apps.filter { !it.isSystemApp }
    val buckets =
      listOf(
        "דפדפני אינטרנט" to listOf("chrome", "firefox", "opera", "edge", "brave", "browser", "duckduckgo", "samsung.android.app.sbrowser"),
        "מנהלי קבצים וניקוי" to listOf("files", "filemanager", "explorer", "solid", "cxfile", "myfiles", "cleaner"),
        "קוראי PDF ומסמכים" to listOf("pdf", "acrobat", "adobe", "office", "word", "docs", "wps", "xodo"),
        "נגני מדיה ווידאו" to listOf("vlc", "mxplayer", "player", "video", "music", "spotify", "aimp"),
        "אפליקציות הערות ותזכורות" to listOf("notes", "keep", "evernote", "notion", "todo", "onenote")
      )

    return buckets.mapNotNull { (roleTitle, keywords) ->
      val matched =
        userApps.filter { app ->
          val haystack = "${app.packageName.lowercase()} ${app.appName.lowercase()}"
          keywords.any { kw -> haystack.contains(kw) }
        }
      if (matched.size >= 2) {
        SimilarAppGroup(
          roleTitleHe = roleTitle,
          apps = matched.sortedByDescending { it.totalSizeBytes },
          adviceHe =
            "זוהו ${matched.size} אפליקציות בתפקיד דומה. שקול להשאיר את המועדפת ולשקול הסרת כפולות לחיסכון במקום."
        )
      } else null
    }
  }
}

class DeviceDoctorEngine(private val context: Context) {

  suspend fun inspectApkUri(uri: Uri, displayNameFallback: String = "קובץ APK"): ApkInspectionReport =
    withContext(Dispatchers.IO) {
      val tempFile = File(context.cacheDir, "apk_inspect_${System.currentTimeMillis()}.apk")
      try {
        var displayName = displayNameFallback
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
          if (c.moveToFirst()) {
            displayName = c.getString(0) ?: displayName
          }
        }

        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(16 * 1024)
        var size = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
          tempFile.outputStream().use { out ->
            var read = input.read(buffer)
            while (read != -1) {
              out.write(buffer, 0, read)
              digest.update(buffer, 0, read)
              size += read
              read = input.read(buffer)
            }
          }
        } ?: error("לא ניתן לקרוא את קובץ ה-APK שנבחר.")

        val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
        val pm = context.packageManager
        val pkgInfo =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(
              tempFile.absolutePath,
              PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
          } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.GET_PERMISSIONS)
          }

        val requested = pkgInfo?.requestedPermissions?.toList().orEmpty()
        val highRisk =
          requested.filter { perm ->
            perm.contains("SMS") ||
              perm.contains("CALL_LOG") ||
              perm.contains("CONTACTS") ||
              perm.contains("RECORD_AUDIO") ||
              perm.contains("CAMERA") ||
              perm.contains("ACCESS_BACKGROUND_LOCATION") ||
              perm.contains("REQUEST_INSTALL_PACKAGES") ||
              perm.contains("SYSTEM_ALERT_WINDOW")
          }

        val warnings = mutableListOf<String>()
        if (pkgInfo == null) {
          warnings += "לא ניתן לפענח מניפסט APK — ייתכן שהקובץ פגום או אינו חבילת Android תקינה."
        }
        if (highRisk.isNotEmpty()) {
          warnings += "חבילה זו מבקשת ${highRisk.size} הרשאות רגישות. בדוק מקור מהימן לפני התקנה."
        }
        warnings += "הצהרת בטיחות כנה: סריקת הרשאות ו-SHA-256 אינה מנוע אנטי-וירוס מלא ואינה מבטיחה שהקובץ בטוח ב-100%."

        val appLabel =
          pkgInfo?.applicationInfo?.let { appInfo ->
            appInfo.sourceDir = tempFile.absolutePath
            appInfo.publicSourceDir = tempFile.absolutePath
            runCatching { pm.getApplicationLabel(appInfo).toString() }.getOrNull()
          }

        ApkInspectionReport(
          fileName = displayName,
          packageName = pkgInfo?.packageName,
          appLabel = appLabel,
          versionName = pkgInfo?.versionName,
          sizeBytes = size,
          sha256 = sha256,
          requestedPermissions = requested,
          highRiskPermissions = highRisk,
          warningNotesHe = warnings,
          parsedSuccessfully = pkgInfo != null
        )
      } catch (e: Exception) {
        ApkInspectionReport(
          fileName = displayNameFallback,
          packageName = null,
          appLabel = null,
          versionName = null,
          sizeBytes = 0L,
          sha256 = "",
          requestedPermissions = emptyList(),
          highRiskPermissions = emptyList(),
          warningNotesHe = listOf("שגיאה בקריאת הקובץ: ${e.localizedMessage ?: "קובץ לא נגיש"}"),
          parsedSuccessfully = false
        )
      } finally {
        tempFile.delete()
      }
    }
}
