package com.example.data.orchestrator

import com.example.NexusApp
import com.example.data.local.ActionAuditEntity
import com.example.data.local.OrchestratorTaskEntity
import com.example.data.local.ReminderAlertEntity
import com.example.data.memory.NexusLearningEngine
import com.example.data.memory.NexusMemoryManager
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.formatBytes
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

enum class NexusAgentRole(val titleHe: String, val roleDescHe: String) {
  PLANNER("סוכן תכנון", "מפרק משימה מורכבת לשלבים מסודרים ומונע כפילויות."),
  RESEARCHER("סוכן מחקר", "אוסף מדדי מערכת, אבטחה, אחסון ומידע מהקשר ומסמכים."),
  CODER("סוכן תכנות", "מפיק תבניות טכניות, תסריטי JSON/Kotlin ובקשות אוטומציה נקיות."),
  TESTER("סוכן בדיקות", "בודק זמינות כלים, מאמת תוצאות ומבצע בדיקת שלמות סופית."),
  TASK_MANAGER("סוכן ניהול משימות", "מסכם ממצאים, מתעד תוצאה ודואג לעמידה באישורי משתמש.")
}

enum class OrchestratorTaskStatus(val titleHe: String) {
  PENDING("ממתין"),
  RUNNING("בתהליך"),
  PAUSED("מושהה"),
  COMPLETED("הושלם"),
  FAILED("נכשל"),
  CANCELLED("בוטל")
}

enum class OrchestratorStepStatus(val titleHe: String) {
  PENDING("ממתין"),
  RUNNING("בביצוע"),
  SUCCEEDED("הצליח"),
  RETRIED_LOCAL("הושלם בחלופה מקומית"),
  FAILED("נכשל"),
  CANCELLED("בוטל")
}

data class OrchestratorStep(
  val index: Int,
  val agent: NexusAgentRole,
  val titleHe: String,
  val toolId: String,
  val dedupKey: String,
  val status: OrchestratorStepStatus = OrchestratorStepStatus.PENDING,
  val outputHe: String = ""
)

object OrchestratorSerialization {
  fun encodeSteps(steps: List<OrchestratorStep>): String {
    val arr = JSONArray()
    steps.forEach { s ->
      arr.put(
        JSONObject().apply {
          put("index", s.index)
          put("agent", s.agent.name)
          put("titleHe", s.titleHe)
          put("toolId", s.toolId)
          put("dedupKey", s.dedupKey)
          put("status", s.status.name)
          put("outputHe", s.outputHe)
        }
      )
    }
    return arr.toString()
  }

  fun decodeSteps(rawJson: String): List<OrchestratorStep> {
    return runCatching {
      val arr = JSONArray(rawJson)
      (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val role =
          NexusAgentRole.entries.firstOrNull { it.name == o.optString("agent") }
            ?: NexusAgentRole.TASK_MANAGER
        val status =
          OrchestratorStepStatus.entries.firstOrNull { it.name == o.optString("status") }
            ?: OrchestratorStepStatus.PENDING
        OrchestratorStep(
          index = o.optInt("index", i),
          agent = role,
          titleHe = o.optString("titleHe"),
          toolId = o.optString("toolId"),
          dedupKey = o.optString("dedupKey"),
          status = status,
          outputHe = o.optString("outputHe")
        )
      }
    }.getOrDefault(emptyList())
  }
}

/**
 * Pure-Kotlin multi-agent decomposer with explicit duplicate-step prevention.
 */
object OrchestratorPlanner {

  fun decomposeGoal(
    rawGoal: String,
    isOnline: Boolean,
    cloudAiEnabled: Boolean
  ): List<OrchestratorStep> {
    val q = rawGoal.trim().lowercase()
    val candidateSteps = mutableListOf<OrchestratorStep>()

    fun addStep(agent: NexusAgentRole, titleHe: String, toolId: String, dedupKey: String) {
      if (candidateSteps.any { it.dedupKey == dedupKey }) return
      candidateSteps +=
        OrchestratorStep(
          index = candidateSteps.size,
          agent = agent,
          titleHe = titleHe,
          toolId = toolId,
          dedupKey = dedupKey
        )
    }

    // 1. Always start with Planning Agent
    addStep(
      agent = NexusAgentRole.PLANNER,
      titleHe = "פירוק הבקשה, בחירת כלים ואימות הרשאות",
      toolId = "task_orchestrator",
      dedupKey = "plan_core"
    )

    val wantsStorage =
      q.contains("אחסון") || q.contains("קבצ") || q.contains("ניקוי") || q.contains("כפול") || q.contains("sd") || q.contains("תמונ") || q.contains("הורד")
    val wantsSecurity =
      q.contains("אבטח") || q.contains("הרשא") || q.contains("פרטיות") || q.contains("בדיקת") || q.contains("בריאות") || q.contains("סולל") || q.contains("טאבלט")
    val wantsApps =
      q.contains("אפליקצ") || q.contains("יישומ") || q.contains("רדומ") || q.contains("נפח")
    val wantsCoding =
      q.contains("קוד") || q.contains("תכנות") || q.contains("סקריפט") || q.contains("json") || q.contains("kotlin") || q.contains("תכנן")
    val wantsDocs =
      q.contains("מסמך") || q.contains("pdf") || q.contains("סיכום") || q.contains("דוח")

    // 2. Research Agent picks only relevant sensors/scanners (avoids wasted work)
    if (wantsSecurity || (!wantsStorage && !wantsApps && !wantsCoding && !wantsDocs)) {
      addStep(
        agent = NexusAgentRole.RESEARCHER,
        titleHe = "מחקר מצב חומרה, סוללה, רשת ואבטחת הרשאות",
        toolId = "device_telemetry",
        dedupKey = "research_telemetry_security"
      )
    }
    if (wantsStorage) {
      addStep(
        agent = NexusAgentRole.RESEARCHER,
        titleHe = "בדיקת נפח אחסון, כרטיס SD ומועמדים לניקוי בטוח",
        toolId = "smart_storage",
        dedupKey = "research_storage"
      )
    }
    if (wantsApps) {
      addStep(
        agent = NexusAgentRole.RESEARCHER,
        titleHe = "מיפוי אפליקציות מותקנות, נפח ושימוש אחרון",
        toolId = "app_inspector",
        dedupKey = "research_apps"
      )
    }
    if (wantsDocs) {
      addStep(
        agent = NexusAgentRole.RESEARCHER,
        titleHe = "סיווג מידע והכנת תקציר מובנה",
        toolId = "document_pdf_reader",
        dedupKey = "research_docs"
      )
    }

    // 3. Coding Agent when technical output/config/AI synthesis is needed
    if (wantsCoding || (isOnline && cloudAiEnabled)) {
      addStep(
        agent = NexusAgentRole.CODER,
        titleHe =
          if (wantsCoding) "בניית מפרט טכני / מבנה אוטומציה בטוח"
          else "גיבוש תוכנית ביצוע חכמה מועשרת ב-AI",
        toolId = if (isOnline && cloudAiEnabled) "cloud_gemini_ai" else "task_orchestrator",
        dedupKey = "coder_or_ai_synthesis"
      )
    }

    // 4. Testing Agent verifies tools & post-conditions
    addStep(
      agent = NexusAgentRole.TESTER,
      titleHe = "אימות תקינות כלים, בדיקת סיום ותנאי בטיחות",
      toolId = "device_telemetry",
      dedupKey = "tester_verify"
    )

    // 5. Task Manager finalizes, logs audit, notifies cleanly
    addStep(
      agent = NexusAgentRole.TASK_MANAGER,
      titleHe = "סיכום משימה ועדכון תור משימות וזיכרון",
      toolId = "task_orchestrator",
      dedupKey = "task_manager_finalize"
    )

    return candidateSteps.mapIndexed { idx, s -> s.copy(index = idx) }
  }
}

class NexusOrchestratorEngine(
  private val app: NexusApp,
  private val memoryManager: NexusMemoryManager,
  private val learningEngine: NexusLearningEngine
) {
  private val db = app.database
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val runningJobs = ConcurrentHashMap<Long, Job>()

  private val _currentlyDoingHe = MutableStateFlow<String?>(null)
  val currentlyDoingHe: StateFlow<String?> = _currentlyDoingHe.asStateFlow()

  fun observeTasks(): Flow<List<OrchestratorTaskEntity>> = db.orchestratorTaskDao().observeTasks()

  suspend fun recoverInterruptedTasks() {
    val stuck = db.orchestratorTaskDao().getActiveOnce()
    val now = System.currentTimeMillis()
    stuck.forEach { task ->
      db.orchestratorTaskDao().update(
        task.copy(
          status = OrchestratorTaskStatus.PAUSED.name,
          currentStepLabel = "המשימה הופסקה בסגירה קודמת — ניתן לחדש או לבטל.",
          updatedAtMillis = now
        )
      )
    }
  }

  suspend fun startNewTask(
    goal: String,
    isOnline: Boolean,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean
  ): Result<Long> {
    val cleanGoal = goal.trim()
    if (cleanGoal.isBlank()) {
      return Result.failure(IllegalArgumentException("נא להזין תיאור משימה לתזמור."))
    }

    // Prevent duplicate concurrent API/orchestrator runs for identical goals
    val alreadyActive =
      db.orchestratorTaskDao().getActiveOnce().firstOrNull {
        it.goal.equals(cleanGoal, ignoreCase = true)
      }
    if (alreadyActive != null) {
      return Result.failure(IllegalStateException("משימה זהה כבר פעילה בתור (#${alreadyActive.id})."))
    }

    val steps = OrchestratorPlanner.decomposeGoal(cleanGoal, isOnline, cloudAiEnabled)
    val now = System.currentTimeMillis()
    val entity =
      OrchestratorTaskEntity(
        goal = cleanGoal,
        status = OrchestratorTaskStatus.RUNNING.name,
        progressPercent = 5,
        currentAgent = steps.first().agent.name,
        currentStepLabel = steps.first().titleHe,
        stepsJson = OrchestratorSerialization.encodeSteps(steps),
        requiresNetwork = false,
        createdAtMillis = now,
        updatedAtMillis = now
      )
    val taskId = db.orchestratorTaskDao().insert(entity)
    learningEngine.trackTaskGoalPattern(cleanGoal)
    launchExecutionLoop(taskId, cloudAiEnabled, shareTelemetryWithAi)
    return Result.success(taskId)
  }

  suspend fun pauseTask(taskId: Long) {
    runningJobs.remove(taskId)?.cancel()
    db.orchestratorTaskDao().updateStatus(
      id = taskId,
      status = OrchestratorTaskStatus.PAUSED.name,
      errorMessage = "הושהה לבקשת המשתמש",
      updatedAt = System.currentTimeMillis()
    )
    _currentlyDoingHe.value = null
  }

  suspend fun resumeTask(taskId: Long, cloudAiEnabled: Boolean, shareTelemetryWithAi: Boolean) {
    val task = db.orchestratorTaskDao().getById(taskId) ?: return
    if (task.status == OrchestratorTaskStatus.COMPLETED.name || task.status == OrchestratorTaskStatus.CANCELLED.name) return
    db.orchestratorTaskDao().updateStatus(
      id = taskId,
      status = OrchestratorTaskStatus.RUNNING.name,
      errorMessage = null,
      updatedAt = System.currentTimeMillis()
    )
    launchExecutionLoop(taskId, cloudAiEnabled, shareTelemetryWithAi)
  }

  suspend fun cancelTask(taskId: Long) {
    runningJobs.remove(taskId)?.cancel()
    val existing = db.orchestratorTaskDao().getById(taskId) ?: return
    val updatedSteps =
      OrchestratorSerialization.decodeSteps(existing.stepsJson).map { step ->
        if (step.status == OrchestratorStepStatus.PENDING || step.status == OrchestratorStepStatus.RUNNING) {
          step.copy(status = OrchestratorStepStatus.CANCELLED, outputHe = "בוטל ע״י המשתמש")
        } else step
      }
    db.orchestratorTaskDao().update(
      existing.copy(
        status = OrchestratorTaskStatus.CANCELLED.name,
        currentStepLabel = "בוטל לבקשת המשתמש",
        stepsJson = OrchestratorSerialization.encodeSteps(updatedSteps),
        updatedAtMillis = System.currentTimeMillis()
      )
    )
    _currentlyDoingHe.value = null
  }

  private fun launchExecutionLoop(
    taskId: Long,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean
  ) {
    runningJobs.remove(taskId)?.cancel()
    val job =
      scope.launch {
        try {
          val initial = db.orchestratorTaskDao().getById(taskId) ?: return@launch
          var steps = OrchestratorSerialization.decodeSteps(initial.stepsJson).toMutableList()
          val executedDedupKeys = mutableSetOf<String>()
          val outputs = mutableListOf<String>()

          for (idx in steps.indices) {
            if (!isActive) return@launch
            val currentDbTask = db.orchestratorTaskDao().getById(taskId) ?: return@launch
            if (currentDbTask.status != OrchestratorTaskStatus.RUNNING.name) {
              _currentlyDoingHe.value = null
              return@launch
            }

            val step = steps[idx]
            if (step.status == OrchestratorStepStatus.SUCCEEDED || step.status == OrchestratorStepStatus.RETRIED_LOCAL) {
              executedDedupKeys += step.dedupKey
              if (step.outputHe.isNotBlank()) outputs += "${step.agent.titleHe}: ${step.outputHe}"
              continue
            }

            if (step.dedupKey in executedDedupKeys) {
              steps[idx] = step.copy(status = OrchestratorStepStatus.SUCCEEDED, outputHe = "דולג למניעת כפילות")
              continue
            }

            steps[idx] = step.copy(status = OrchestratorStepStatus.RUNNING)
            val progress = (((idx) * 100f) / steps.size.coerceAtLeast(1)).toInt().coerceIn(8, 92)
            _currentlyDoingHe.value = "${step.agent.titleHe}: ${step.titleHe}"
            db.orchestratorTaskDao().update(
              currentDbTask.copy(
                currentAgent = step.agent.name,
                currentStepLabel = step.titleHe,
                progressPercent = progress,
                stepsJson = OrchestratorSerialization.encodeSteps(steps),
                updatedAtMillis = System.currentTimeMillis()
              )
            )

            val t0 = System.currentTimeMillis()
            val (stepOk, usedFallback, outText) =
              executeStepWithRetry(
                goal = currentDbTask.goal,
                step = step,
                cloudAiEnabled = cloudAiEnabled,
                shareTelemetryWithAi = shareTelemetryWithAi,
                accumulatedFindings = outputs
              )
            val latency = (System.currentTimeMillis() - t0).coerceAtLeast(1L)

            executedDedupKeys += step.dedupKey
            val newStatus =
              when {
                stepOk && !usedFallback -> OrchestratorStepStatus.SUCCEEDED
                stepOk && usedFallback -> OrchestratorStepStatus.RETRIED_LOCAL
                else -> OrchestratorStepStatus.FAILED
              }
            steps[idx] = step.copy(status = newStatus, outputHe = outText)
            outputs += "• [${step.agent.titleHe}] $outText"

            learningEngine.recordToolRun(
              toolId = step.toolId,
              toolNameHe = NexusToolRegistry.catalog.firstOrNull { it.id == step.toolId }?.nameHe ?: step.toolId,
              succeeded = stepOk,
              latencyMs = latency,
              summaryHe = outText,
              errorHe = if (stepOk) null else outText
            )

            if (!stepOk && step.agent == NexusAgentRole.TESTER) {
              val failedTask = db.orchestratorTaskDao().getById(taskId) ?: return@launch
              db.orchestratorTaskDao().update(
                failedTask.copy(
                  status = OrchestratorTaskStatus.FAILED.name,
                  currentStepLabel = "נכשל באימות הבדיקה",
                  stepsJson = OrchestratorSerialization.encodeSteps(steps),
                  errorMessage = outText,
                  updatedAtMillis = System.currentTimeMillis()
                )
              )
              recordCompletionOrFailureAlert(
                title = "כישלון במשימת AI: ${failedTask.goal.take(40)}",
                message = outText,
                isFailure = true
              )
              _currentlyDoingHe.value = null
              return@launch
            }

            delay(180)
          }

          val finalSummary = outputs.joinToString("\n")
          val doneTask = db.orchestratorTaskDao().getById(taskId) ?: return@launch
          db.orchestratorTaskDao().update(
            doneTask.copy(
              status = OrchestratorTaskStatus.COMPLETED.name,
              progressPercent = 100,
              currentAgent = NexusAgentRole.TASK_MANAGER.name,
              currentStepLabel = "המשימה הושלמה ואומתה בהצלחה",
              stepsJson = OrchestratorSerialization.encodeSteps(steps),
              resultSummary = finalSummary,
              errorMessage = null,
              updatedAtMillis = System.currentTimeMillis()
            )
          )
          db.actionAuditDao().insert(
            ActionAuditEntity(
              timestampMillis = System.currentTimeMillis(),
              category = "מוח תזמור ו-5 סוכנים",
              actionTitle = doneTask.goal.take(70),
              succeeded = true,
              details = "${steps.size} שלבים הושלמו"
            )
          )
          recordCompletionOrFailureAlert(
            title = "הושלמה משימה: ${doneTask.goal.take(42)}",
            message = "כל ${steps.size} שלבי הסוכנים הושלמו בהצלחה.",
            isFailure = false
          )
          _currentlyDoingHe.value = null
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          val cur = db.orchestratorTaskDao().getById(taskId)
          if (cur != null && cur.status == OrchestratorTaskStatus.RUNNING.name) {
            val msg = e.localizedMessage ?: "שגיאה לא צפויה"
            db.orchestratorTaskDao().update(
              cur.copy(
                status = OrchestratorTaskStatus.FAILED.name,
                errorMessage = msg,
                updatedAtMillis = System.currentTimeMillis()
              )
            )
            recordCompletionOrFailureAlert(
              title = "כישלון בביצוע משימה",
              message = msg,
              isFailure = true
            )
          }
          _currentlyDoingHe.value = null
        } finally {
          runningJobs.remove(taskId)
        }
      }
    runningJobs[taskId] = job
  }

  private suspend fun executeStepWithRetry(
    goal: String,
    step: OrchestratorStep,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean,
    accumulatedFindings: List<String>
  ): Triple<Boolean, Boolean, String> {
    val safFolders = app.preferencesManager.safTreeUrisFlow.first()
    return when (step.agent) {
      NexusAgentRole.PLANNER -> {
        val memCtx = memoryManager.buildContextForPrompt(maxEntries = 4)
        val memHint = if (memCtx.isNotBlank()) "ושולבו פריטי זיכרון רלוונטיים" else "ללא פריטי זיכרון תלויים"
        Triple(true, false, "תוכנית נבנתה ליעד \"${goal.take(45)}\" ($memHint).")
      }

      NexusAgentRole.RESEARCHER -> {
        val telemetry = app.telemetryProvider.captureTelemetry(safFolders.size)
        when (step.toolId) {
          "smart_storage" -> {
            val cleanScan = app.deepCleanEngine.scanSystem(safFolders)
            Triple(
              true,
              false,
              "אחסון פנוי: ${formatBytes(telemetry.storage.freeBytes)} (${100 - telemetry.storage.usedPercent}%). זוהו ${formatBytes(cleanScan.directReclaimableBytes)} לניקוי ישיר."
            )
          }
          "app_inspector" -> {
            val apps = app.appIntelligenceProvider.loadApps()
            val top = apps.sortedByDescending { it.totalSizeBytes }.take(3).joinToString(", ") { it.appName }
            Triple(true, false, "נסרקו ${apps.size} אפליקציות. מובילות בנפח: $top.")
          }
          else -> {
            val b = telemetry.battery
            Triple(
              true,
              false,
              "ציון בריאות ${telemetry.healthScore}% • סוללה ${b.levelPercent}% (${b.temperatureC}°C) • RAM ${telemetry.ram.usedPercent}% • רשת: ${telemetry.network.transportLabel}."
            )
          }
        }
      }

      NexusAgentRole.CODER -> {
        val telemetry = app.telemetryProvider.captureTelemetry(safFolders.size)
        if (cloudAiEnabled && telemetry.network.isConnected && step.toolId == "cloud_gemini_ai") {
          val prompt =
            "בהתבסס על היעד: \"$goal\"\nוהממצאים:\n${accumulatedFindings.joinToString("\n")}\nספק סיכום פעולה תמציתי או תבנית טכנית ב-4 שורות בעברית (אל תבצע מחיקה בעצמך)."
          val aiRes =
            app.aiProvider.generateAssistantResponse(
              userInput = prompt,
              recentHistory = emptyList(),
              telemetry = telemetry,
              apps = emptyList(),
              securityReport = null,
              customAutomations = emptyList(),
              allowDeviceContextSharing = shareTelemetryWithAi
            )
          aiRes.fold(
            onSuccess = { reply -> Triple(true, false, reply.replyText.take(260)) },
            onFailure = {
              // Alternative deterministic local fallback without repeating wasted API calls
              Triple(
                true,
                true,
                "ענן AI לא זמין כעת — סוכן התכנות הפיק תבנית אוטומציה ומסלול אבחון מקומי בהתאם לממצאים."
              )
            }
          )
        } else {
          val template =
            """{"goal":"${goal.take(40)}","mode":"offline_safe","stepsCount":${accumulatedFindings.size + 2},"requiresApproval":true}"""
          Triple(true, false, "הופקה תבנית מפרט מקומית מאובטחת: $template")
        }
      }

      NexusAgentRole.TESTER -> {
        val telemetry = app.telemetryProvider.captureTelemetry(safFolders.size)
        val ok = telemetry.storage.totalBytes > 0L && telemetry.ram.totalBytes > 0L
        Triple(
          ok,
          false,
          if (ok) "אומתו חיישני מערכת, זמינות כלים וגבולות אבטחה — המשימה תקינה."
          else "אימות בסיסי נכשל — קריאת חיישנים לא הושלמה."
        )
      }

      NexusAgentRole.TASK_MANAGER -> {
        Triple(true, false, "כל תוצרי הסוכנים תועדו ביומן ובמרכז המשימות; לא בוצע אף שינוי הרסני ללא אישורך.")
      }
    }
  }

  private suspend fun recordCompletionOrFailureAlert(
    title: String,
    message: String,
    isFailure: Boolean
  ) {
    val now = System.currentTimeMillis()
    db.reminderAlertDao().insert(
      ReminderAlertEntity(
        title = title,
        message = message.take(260),
        kind = if (isFailure) "FAILURE" else "COMPLETION",
        triggerAtMillis = now,
        status = "TRIGGERED",
        targetRoute = "assistant",
        createdAtMillis = now,
        lastTriggeredMillis = now
      )
    )
    NexusNotificationHelper.postSystemAlertNotification(
      context = app,
      notificationId = 6200 + (now % 300).toInt(),
      title = "NEXUS: $title",
      body = message.take(160),
      targetRoute = "assistant"
    )
  }
}
