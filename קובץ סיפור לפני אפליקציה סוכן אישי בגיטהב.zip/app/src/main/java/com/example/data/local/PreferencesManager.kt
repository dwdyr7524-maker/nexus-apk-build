package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.nexusDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "nexus_preferences")

class PreferencesManager(private val context: Context) {

  private object Keys {
    val PERFORMANCE_MODE = booleanPreferencesKey("performance_mode")
    val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
    val TTS_SPEECH_RATE = floatPreferencesKey("tts_speech_rate")
    val TTS_PITCH = floatPreferencesKey("tts_pitch")
    val TTS_VOICE_NAME = stringPreferencesKey("tts_voice_name")
    val NOISE_SUPPRESSION_ENABLED = booleanPreferencesKey("noise_suppression_enabled")
    val CLOUD_AI_ENABLED = booleanPreferencesKey("cloud_ai_enabled")
    val SHARE_TELEMETRY_WITH_AI = booleanPreferencesKey("share_telemetry_with_ai")
    val MEMORY_AUTO_SAVE_ENABLED = booleanPreferencesKey("memory_auto_save_enabled")
    val FLOATING_ASSISTANT_ENABLED = booleanPreferencesKey("floating_assistant_enabled")
    val FLOATING_OFFSET_X = floatPreferencesKey("floating_offset_x")
    val FLOATING_OFFSET_Y = floatPreferencesKey("floating_offset_y")
    val BACKGROUND_ALERTS_ENABLED = booleanPreferencesKey("background_alerts_enabled")
    val ALERT_INTERVAL_MINUTES = longPreferencesKey("alert_interval_minutes")
    val LAST_THERMAL_ALERT_MILLIS = longPreferencesKey("last_thermal_alert_millis")
    val SAF_TREE_URIS = stringSetPreferencesKey("saf_tree_uris")
    val LAST_MAINTENANCE_MILLIS = longPreferencesKey("last_maintenance_millis")
    val DARK_THEME_ENABLED = booleanPreferencesKey("dark_theme_enabled")
    val LAST_FULL_SCAN_MILLIS = longPreferencesKey("last_full_scan_millis")
    val KNOWN_LARGE_FILE_IDS = stringSetPreferencesKey("known_large_file_ids")
  }

  val performanceModeFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.PERFORMANCE_MODE] ?: false }

  val ttsEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.TTS_ENABLED] ?: true }

  val ttsSpeechRateFlow: Flow<Float> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.TTS_SPEECH_RATE] ?: 1.0f }

  val ttsPitchFlow: Flow<Float> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.TTS_PITCH] ?: 1.0f }

  val ttsVoiceNameFlow: Flow<String?> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.TTS_VOICE_NAME] }

  val noiseSuppressionEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.NOISE_SUPPRESSION_ENABLED] ?: true }

  val cloudAiEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.CLOUD_AI_ENABLED] ?: true }

  val shareTelemetryWithAiFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.SHARE_TELEMETRY_WITH_AI] ?: true }

  val memoryAutoSaveEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.MEMORY_AUTO_SAVE_ENABLED] ?: true }

  val floatingAssistantEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.FLOATING_ASSISTANT_ENABLED] ?: true }

  val floatingOffsetXFlow: Flow<Float> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.FLOATING_OFFSET_X] ?: -16f }

  val floatingOffsetYFlow: Flow<Float> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.FLOATING_OFFSET_Y] ?: -96f }

  val backgroundAlertsEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.BACKGROUND_ALERTS_ENABLED] ?: true }

  val alertIntervalMinutesFlow: Flow<Long> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.ALERT_INTERVAL_MINUTES] ?: 30L }

  val lastThermalAlertMillisFlow: Flow<Long> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.LAST_THERMAL_ALERT_MILLIS] ?: 0L }

  val safTreeUrisFlow: Flow<Set<String>> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.SAF_TREE_URIS] ?: emptySet() }

  val lastMaintenanceMillisFlow: Flow<Long?> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.LAST_MAINTENANCE_MILLIS] }

  val darkThemeEnabledFlow: Flow<Boolean> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.DARK_THEME_ENABLED] ?: true }

  val lastFullScanMillisFlow: Flow<Long?> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.LAST_FULL_SCAN_MILLIS] }

  val knownLargeFileIdsFlow: Flow<Set<String>> =
    context.nexusDataStore.data.map { prefs -> prefs[Keys.KNOWN_LARGE_FILE_IDS] ?: emptySet() }

  suspend fun setPerformanceMode(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.PERFORMANCE_MODE] = enabled }
  }

  suspend fun setTtsEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.TTS_ENABLED] = enabled }
  }

  suspend fun setTtsSpeechRate(rate: Float) {
    context.nexusDataStore.edit { it[Keys.TTS_SPEECH_RATE] = rate.coerceIn(0.6f, 1.8f) }
  }

  suspend fun setTtsPitch(pitch: Float) {
    context.nexusDataStore.edit { it[Keys.TTS_PITCH] = pitch.coerceIn(0.7f, 1.5f) }
  }

  suspend fun setTtsVoiceName(name: String?) {
    context.nexusDataStore.edit { prefs ->
      if (name.isNullOrBlank()) prefs.remove(Keys.TTS_VOICE_NAME)
      else prefs[Keys.TTS_VOICE_NAME] = name
    }
  }

  suspend fun setNoiseSuppressionEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.NOISE_SUPPRESSION_ENABLED] = enabled }
  }

  suspend fun setCloudAiEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.CLOUD_AI_ENABLED] = enabled }
  }

  suspend fun setShareTelemetryWithAi(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.SHARE_TELEMETRY_WITH_AI] = enabled }
  }

  suspend fun setMemoryAutoSaveEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.MEMORY_AUTO_SAVE_ENABLED] = enabled }
  }

  suspend fun setFloatingAssistantEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.FLOATING_ASSISTANT_ENABLED] = enabled }
  }

  suspend fun updateFloatingOffset(offsetX: Float, offsetY: Float) {
    context.nexusDataStore.edit {
      it[Keys.FLOATING_OFFSET_X] = offsetX
      it[Keys.FLOATING_OFFSET_Y] = offsetY
    }
  }

  suspend fun setBackgroundAlertsEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.BACKGROUND_ALERTS_ENABLED] = enabled }
  }

  suspend fun setAlertIntervalMinutes(minutes: Long) {
    context.nexusDataStore.edit { it[Keys.ALERT_INTERVAL_MINUTES] = minutes.coerceAtLeast(15L) }
  }

  suspend fun updateLastThermalAlertMillis(millis: Long) {
    context.nexusDataStore.edit { it[Keys.LAST_THERMAL_ALERT_MILLIS] = millis }
  }

  suspend fun addSafTreeUri(uriString: String) {
    context.nexusDataStore.edit { prefs ->
      val current = prefs[Keys.SAF_TREE_URIS] ?: emptySet()
      prefs[Keys.SAF_TREE_URIS] = current + uriString
    }
  }

  suspend fun removeSafTreeUri(uriString: String) {
    context.nexusDataStore.edit { prefs ->
      val current = prefs[Keys.SAF_TREE_URIS] ?: emptySet()
      prefs[Keys.SAF_TREE_URIS] = current - uriString
    }
  }

  suspend fun updateLastMaintenanceMillis(millis: Long) {
    context.nexusDataStore.edit { it[Keys.LAST_MAINTENANCE_MILLIS] = millis }
  }

  suspend fun setDarkThemeEnabled(enabled: Boolean) {
    context.nexusDataStore.edit { it[Keys.DARK_THEME_ENABLED] = enabled }
  }

  suspend fun updateLastFullScanMillis(millis: Long) {
    context.nexusDataStore.edit { it[Keys.LAST_FULL_SCAN_MILLIS] = millis }
  }

  suspend fun updateKnownLargeFileIds(ids: Set<String>) {
    context.nexusDataStore.edit { it[Keys.KNOWN_LARGE_FILE_IDS] = ids.take(250).toSet() }
  }

  suspend fun restorePreferences(
    performanceMode: Boolean,
    ttsEnabled: Boolean,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean,
    backgroundAlertsEnabled: Boolean = true,
    alertIntervalMinutes: Long = 30L,
    darkThemeEnabled: Boolean = true,
    ttsSpeechRate: Float = 1.0f,
    noiseSuppressionEnabled: Boolean = true,
    memoryAutoSaveEnabled: Boolean = true,
    floatingAssistantEnabled: Boolean = true
  ) {
    context.nexusDataStore.edit { prefs ->
      prefs[Keys.PERFORMANCE_MODE] = performanceMode
      prefs[Keys.TTS_ENABLED] = ttsEnabled
      prefs[Keys.CLOUD_AI_ENABLED] = cloudAiEnabled
      prefs[Keys.SHARE_TELEMETRY_WITH_AI] = shareTelemetryWithAi
      prefs[Keys.BACKGROUND_ALERTS_ENABLED] = backgroundAlertsEnabled
      prefs[Keys.ALERT_INTERVAL_MINUTES] = alertIntervalMinutes.coerceAtLeast(15L)
      prefs[Keys.DARK_THEME_ENABLED] = darkThemeEnabled
      prefs[Keys.TTS_SPEECH_RATE] = ttsSpeechRate.coerceIn(0.6f, 1.8f)
      prefs[Keys.NOISE_SUPPRESSION_ENABLED] = noiseSuppressionEnabled
      prefs[Keys.MEMORY_AUTO_SAVE_ENABLED] = memoryAutoSaveEnabled
      prefs[Keys.FLOATING_ASSISTANT_ENABLED] = floatingAssistantEnabled
    }
  }

  suspend fun clearAll() {
    context.nexusDataStore.edit { it.clear() }
  }
}
