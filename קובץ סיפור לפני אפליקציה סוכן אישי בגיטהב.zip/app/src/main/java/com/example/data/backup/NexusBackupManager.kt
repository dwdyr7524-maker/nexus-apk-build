package com.example.data.backup

import com.example.data.local.AutomationEntity
import com.example.data.local.MemoryEntryEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.PreferencesManager
import com.example.data.local.ReminderAlertEntity
import com.example.data.memory.NexusMemorySecretFilter
import com.example.data.memory.NexusMemoryType
import com.example.data.model.AutomationStepType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackupRestoreSummary(
  val restoredAutomationsCount: Int,
  val restoredPreferences: Boolean,
  val restoredMemoriesCount: Int = 0,
  val restoredRemindersCount: Int = 0
)

class NexusBackupManager(
  private val db: NexusDatabase,
  private val prefs: PreferencesManager
) {

  suspend fun exportJsonBackup(): String =
    withContext(Dispatchers.IO) {
      val root = JSONObject()
      root.put("format", "nexus_command_backup")
      root.put("version", 2)
      root.put("exportedAtMillis", System.currentTimeMillis())

      val prefObj = JSONObject()
      prefObj.put("performanceMode", prefs.performanceModeFlow.first())
      prefObj.put("ttsEnabled", prefs.ttsEnabledFlow.first())
      prefObj.put("ttsSpeechRate", prefs.ttsSpeechRateFlow.first().toDouble())
      prefObj.put("noiseSuppressionEnabled", prefs.noiseSuppressionEnabledFlow.first())
      prefObj.put("cloudAiEnabled", prefs.cloudAiEnabledFlow.first())
      prefObj.put("shareTelemetryWithAi", prefs.shareTelemetryWithAiFlow.first())
      prefObj.put("memoryAutoSaveEnabled", prefs.memoryAutoSaveEnabledFlow.first())
      prefObj.put("floatingAssistantEnabled", prefs.floatingAssistantEnabledFlow.first())
      prefObj.put("backgroundAlertsEnabled", prefs.backgroundAlertsEnabledFlow.first())
      prefObj.put("alertIntervalMinutes", prefs.alertIntervalMinutesFlow.first())
      prefObj.put("darkThemeEnabled", prefs.darkThemeEnabledFlow.first())
      root.put("preferences", prefObj)

      val customAutos = db.automationDao().getCustomOnce()
      val autosArray = JSONArray()
      customAutos.forEach { auto ->
        val obj = JSONObject()
        obj.put("name", auto.name)
        obj.put("voicePhrase", auto.voicePhrase)
        obj.put("description", auto.description)
        obj.put("stepsSerialized", auto.stepsSerialized)
        obj.put("scheduleIntervalHours", auto.scheduleIntervalHours)
        autosArray.put(obj)
      }
      root.put("customAutomations", autosArray)

      val memArray = JSONArray()
      db.memoryEntryDao().getActivePersistableOnce(limit = 80).forEach { mem ->
        if (mem.memoryType != NexusMemoryType.SHORT_TERM.name &&
          !NexusMemorySecretFilter.inspect(mem.title, mem.content).containsSensitiveData
        ) {
          val obj = JSONObject()
          obj.put("memoryType", mem.memoryType)
          obj.put("title", mem.title)
          obj.put("content", mem.content)
          obj.put("categoryTag", mem.categoryTag)
          obj.put("importanceScore", mem.importanceScore)
          memArray.put(obj)
        }
      }
      root.put("longTermMemories", memArray)

      val remindersArray = JSONArray()
      db.reminderAlertDao().getActiveOnce().forEach { rem ->
        val obj = JSONObject()
        obj.put("title", rem.title)
        obj.put("message", rem.message)
        obj.put("kind", rem.kind)
        obj.put("triggerAtMillis", rem.triggerAtMillis ?: 0L)
        obj.put("repeatIntervalHours", rem.repeatIntervalHours)
        obj.put("conditionKey", rem.conditionKey)
        obj.put("targetRoute", rem.targetRoute)
        remindersArray.put(obj)
      }
      root.put("activeReminders", remindersArray)

      val history = db.cleanHistoryDao().getHistoryOnce()
      val histArray = JSONArray()
      history.take(20).forEach { h ->
        val obj = JSONObject()
        obj.put("timestampMillis", h.timestampMillis)
        obj.put("itemsDeleted", h.itemsDeleted)
        obj.put("bytesFreed", h.bytesFreed)
        obj.put("summary", h.summary)
        histArray.put(obj)
      }
      root.put("cleanHistorySummary", histArray)

      root.toString(2)
    }

  suspend fun restoreFromJson(rawJson: String): Result<BackupRestoreSummary> =
    withContext(Dispatchers.IO) {
      runCatching {
        val root = JSONObject(rawJson)
        require(root.optString("format") == "nexus_command_backup") {
          "פורמט קובץ הגיבוי אינו תואם ל-NEXUS."
        }
        val version = root.optInt("version", 0)
        require(version >= 1) { "גרסת גיבוי לא נתמכת." }

        var restoredPrefs = false
        root.optJSONObject("preferences")?.let { p ->
          prefs.restorePreferences(
            performanceMode = p.optBoolean("performanceMode", false),
            ttsEnabled = p.optBoolean("ttsEnabled", true),
            cloudAiEnabled = p.optBoolean("cloudAiEnabled", true),
            shareTelemetryWithAi = p.optBoolean("shareTelemetryWithAi", true),
            backgroundAlertsEnabled = p.optBoolean("backgroundAlertsEnabled", true),
            alertIntervalMinutes = p.optLong("alertIntervalMinutes", 30L),
            darkThemeEnabled = p.optBoolean("darkThemeEnabled", true),
            ttsSpeechRate = p.optDouble("ttsSpeechRate", 1.0).toFloat(),
            noiseSuppressionEnabled = p.optBoolean("noiseSuppressionEnabled", true),
            memoryAutoSaveEnabled = p.optBoolean("memoryAutoSaveEnabled", true),
            floatingAssistantEnabled = p.optBoolean("floatingAssistantEnabled", true)
          )
          restoredPrefs = true
        }

        val validStepNames = AutomationStepType.entries.map { it.name }.toSet()
        val existingNames = db.automationDao().getCustomOnce().map { it.name }.toHashSet()
        var restoredCount = 0

        val autosArray = root.optJSONArray("customAutomations") ?: JSONArray()
        for (i in 0 until autosArray.length()) {
          val obj = autosArray.optJSONObject(i) ?: continue
          val name = obj.optString("name").trim()
          val phrase = obj.optString("voicePhrase").trim()
          val rawSteps = obj.optString("stepsSerialized")
          val intervalHours = obj.optInt("scheduleIntervalHours", 0).coerceAtLeast(0)
          val filteredSteps =
            rawSteps.split(",").map { it.trim() }.filter { it in validStepNames }
          if (name.isNotBlank() && filteredSteps.isNotEmpty() && name !in existingNames) {
            val desc =
              filteredSteps.mapNotNull { token ->
                AutomationStepType.entries.firstOrNull { it.name == token }?.titleHe
              }.joinToString(" ← ")
            db.automationDao().insert(
              AutomationEntity(
                name = name,
                voicePhrase = phrase.ifBlank { name },
                description = desc,
                stepsSerialized = filteredSteps.joinToString(","),
                isBuiltIn = false,
                scheduleIntervalHours = intervalHours
              )
            )
            existingNames += name
            restoredCount++
          }
        }

        val existingMemKeys =
          db.memoryEntryDao().getAllOnce().map { "${it.title}::${it.content}" }.toHashSet()
        var restoredMemories = 0
        val memArray = root.optJSONArray("longTermMemories") ?: JSONArray()
        val now = System.currentTimeMillis()
        for (i in 0 until memArray.length()) {
          val obj = memArray.optJSONObject(i) ?: continue
          val title = obj.optString("title").trim().take(80)
          val content = obj.optString("content").trim().take(800)
          val rawType = obj.optString("memoryType", NexusMemoryType.LONG_TERM.name)
          val safeType =
            NexusMemoryType.entries.firstOrNull { it.name == rawType && it != NexusMemoryType.SHORT_TERM }
              ?: NexusMemoryType.LONG_TERM
          if (title.isNotBlank() &&
            content.isNotBlank() &&
            !NexusMemorySecretFilter.inspect(title, content).containsSensitiveData &&
            "${title}::${content}" !in existingMemKeys
          ) {
            db.memoryEntryDao().insert(
              MemoryEntryEntity(
                memoryType = safeType.name,
                title = title,
                content = content,
                categoryTag = obj.optString("categoryTag", "שוחזר").take(32),
                canPersist = true,
                importanceScore = obj.optInt("importanceScore", 60).coerceIn(1, 100),
                createdAtMillis = now,
                updatedAtMillis = now,
                lastAccessedMillis = now
              )
            )
            existingMemKeys += "${title}::${content}"
            restoredMemories++
          }
        }

        val existingReminderTitles = db.reminderAlertDao().getActiveOnce().map { it.title }.toHashSet()
        var restoredReminders = 0
        val remArray = root.optJSONArray("activeReminders") ?: JSONArray()
        for (i in 0 until remArray.length()) {
          val obj = remArray.optJSONObject(i) ?: continue
          val title = obj.optString("title").trim().take(90)
          val message = obj.optString("message").trim().take(260)
          if (title.isNotBlank() && title !in existingReminderTitles) {
            val trig = obj.optLong("triggerAtMillis", 0L).takeIf { it > now }
            db.reminderAlertDao().insert(
              ReminderAlertEntity(
                title = title,
                message = message,
                kind = obj.optString("kind", "REMINDER"),
                triggerAtMillis = trig,
                repeatIntervalHours = obj.optInt("repeatIntervalHours", 0).coerceAtLeast(0),
                conditionKey = obj.optString("conditionKey", "NONE"),
                status = "ACTIVE",
                targetRoute = obj.optString("targetRoute", "dashboard"),
                createdAtMillis = now
              )
            )
            existingReminderTitles += title
            restoredReminders++
          }
        }

        BackupRestoreSummary(
          restoredAutomationsCount = restoredCount,
          restoredPreferences = restoredPrefs,
          restoredMemoriesCount = restoredMemories,
          restoredRemindersCount = restoredReminders
        )
      }
    }

  suspend fun clearAllUserData() =
    withContext(Dispatchers.IO) {
      db.assistantMessageDao().clearAll()
      db.actionAuditDao().clearAll()
      db.cleanHistoryDao().clearAll()
      db.telemetrySnapshotDao().clearAll()
      db.automationDao().deleteAllCustom()
      db.approvalProposalDao().clearAll()
      db.undoRecordDao().clearAll()
      db.backupRecordDao().clearAll()
      db.memoryEntryDao().clearAll()
      db.orchestratorTaskDao().clearAll()
      db.learningRecordDao().clearAll()
      db.toolUsageDao().clearAll()
      db.reminderAlertDao().clearAll()
      prefs.clearAll()
    }
}
