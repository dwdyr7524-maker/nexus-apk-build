package com.example

import android.app.Application
import com.example.data.ai.FirebaseNexusAiProvider
import com.example.data.ai.NexusAudioRecorder
import com.example.data.backup.NexusBackupManager
import com.example.data.local.AutomationEntity
import com.example.data.local.NexusDatabase
import com.example.data.local.PreferencesManager
import com.example.data.model.AutomationStepType
import com.example.data.system.AppIntelligenceProvider
import com.example.data.system.AssistantEngine
import com.example.data.system.DeepCleanEngine
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.SecurityAuditor
import com.example.data.system.SystemControlHelper
import com.example.data.system.SystemTelemetryProvider
import com.example.data.worker.NexusWorkScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class NexusApp : Application() {

  lateinit var database: NexusDatabase
    private set

  lateinit var preferencesManager: PreferencesManager
    private set

  lateinit var telemetryProvider: SystemTelemetryProvider
    private set

  lateinit var deepCleanEngine: DeepCleanEngine
    private set

  lateinit var appIntelligenceProvider: AppIntelligenceProvider
    private set

  lateinit var securityAuditor: SecurityAuditor
    private set

  lateinit var systemControlHelper: SystemControlHelper
    private set

  lateinit var assistantEngine: AssistantEngine
    private set

  lateinit var aiProvider: FirebaseNexusAiProvider
    private set

  lateinit var audioRecorder: NexusAudioRecorder
    private set

  lateinit var backupManager: NexusBackupManager
    private set

  lateinit var smartStorageEngine: com.example.data.system.SmartStorageEngine
    private set

  lateinit var deviceDoctorEngine: com.example.data.system.DeviceDoctorEngine
    private set

  lateinit var storageBackupEngine: com.example.data.backup.StorageBackupEngine
    private set

  lateinit var memoryManager: com.example.data.memory.NexusMemoryManager
    private set

  lateinit var learningEngine: com.example.data.memory.NexusLearningEngine
    private set

  lateinit var orchestratorEngine: com.example.data.orchestrator.NexusOrchestratorEngine
    private set

  lateinit var documentEngine: com.example.data.documents.DocumentCommanderEngine
    private set

  lateinit var connectivityMonitor: com.example.data.system.ConnectivityMonitor
    private set

  private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override fun onCreate() {
    super.onCreate()
    database = NexusDatabase.getInstance(this)
    preferencesManager = PreferencesManager(this)
    telemetryProvider = SystemTelemetryProvider(this)
    deepCleanEngine = DeepCleanEngine(this, telemetryProvider)
    appIntelligenceProvider = AppIntelligenceProvider(this, telemetryProvider)
    securityAuditor = SecurityAuditor()
    systemControlHelper = SystemControlHelper(this)
    assistantEngine = AssistantEngine(this)
    aiProvider = FirebaseNexusAiProvider(this)
    audioRecorder = NexusAudioRecorder(this)
    backupManager = NexusBackupManager(database, preferencesManager)
    smartStorageEngine = com.example.data.system.SmartStorageEngine(this)
    deviceDoctorEngine = com.example.data.system.DeviceDoctorEngine(this)
    storageBackupEngine = com.example.data.backup.StorageBackupEngine(this, smartStorageEngine)
    memoryManager = com.example.data.memory.NexusMemoryManager(database.memoryEntryDao())
    learningEngine = com.example.data.memory.NexusLearningEngine(database.learningRecordDao(), database.toolUsageDao())
    orchestratorEngine = com.example.data.orchestrator.NexusOrchestratorEngine(this, memoryManager, learningEngine)
    documentEngine = com.example.data.documents.DocumentCommanderEngine(this)
    connectivityMonitor = com.example.data.system.ConnectivityMonitor(this)

    NexusNotificationHelper.ensureChannels(this)
    seedInitialAutomationsIfNeeded()
    syncBackgroundWorkers()
    recoverOrchestratorAndSyncVoice()
  }

  private fun recoverOrchestratorAndSyncVoice() {
    appScope.launch {
      runCatching { orchestratorEngine.recoverInterruptedTasks() }
      runCatching {
        val rate = preferencesManager.ttsSpeechRateFlow.first()
        val pitch = preferencesManager.ttsPitchFlow.first()
        val voice = preferencesManager.ttsVoiceNameFlow.first()
        assistantEngine.setSpeechConfig(rate, pitch, voice)
      }
    }
  }

  private fun syncBackgroundWorkers() {
    appScope.launch {
      val alertsEnabled = preferencesManager.backgroundAlertsEnabledFlow.first()
      val intervalMin = preferencesManager.alertIntervalMinutesFlow.first()
      NexusWorkScheduler.syncThermalMonitor(this@NexusApp, alertsEnabled, intervalMin)
      database.automationDao().getScheduledOnce().forEach { auto ->
        NexusWorkScheduler.syncScheduledAutomation(this@NexusApp, auto)
      }
    }
  }

  fun reseedDefaultAutomations() {
    seedInitialAutomationsIfNeeded()
  }

  private fun seedInitialAutomationsIfNeeded() {
    appScope.launch {
      val existing = database.automationDao().getAllOnce()
      if (existing.isEmpty()) {
        val defaults =
          listOf(
            AutomationEntity(
              name = "בדיקת בוקר מערכתית",
              voicePhrase = "בדיקת בוקר",
              description = "מבצע סריקת אחסון, בדיקת סוללה וביקורת הרשאות רגישות.",
              stepsSerialized =
                listOf(
                    AutomationStepType.SYSTEM_SCAN.name,
                    AutomationStepType.BATTERY_CHECK.name,
                    AutomationStepType.SECURITY_AUDIT.name,
                    AutomationStepType.MAINTENANCE_REPORT.name
                  )
                  .joinToString(","),
              isBuiltIn = true
            ),
            AutomationEntity(
              name = "רענון תחזוקה וניקוי בטוח",
              voicePhrase = "תחזוקה מהירה",
              description = "מנקה את מטמון NEXUS ומפיק דוח תחזוקה עדכני (דורש אישור).",
              stepsSerialized =
                listOf(
                    AutomationStepType.SYSTEM_SCAN.name,
                    AutomationStepType.CLEAR_NEXUS_CACHE.name,
                    AutomationStepType.MAINTENANCE_REPORT.name
                  )
                  .joinToString(","),
              isBuiltIn = true
            ),
            AutomationEntity(
              name = "מעבר מהיר למסך האחסון",
              voicePhrase = "פתח אחסון",
              description = "מציג מצב אחסון ופותח את מנהל האחסון הרשמי של Android.",
              stepsSerialized =
                listOf(
                    AutomationStepType.SYSTEM_SCAN.name,
                    AutomationStepType.OPEN_STORAGE_SETTINGS.name
                  )
                  .joinToString(","),
              isBuiltIn = true
            )
          )
        defaults.forEach { database.automationDao().insert(it) }
      }
    }
  }
}
