package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ai.AiSystemDiagnosticsReport
import com.example.data.ai.CloudHealthCheckState
import com.example.data.ai.ModelDiagnosticStatus
import com.example.data.model.ApkInspectionReport
import com.example.data.model.HealthSeverity
import com.example.data.model.SecurityAuditReport
import com.example.data.system.formatBytes
import com.example.ui.components.NexusConfirmationDialog
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusShimmerBox
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusGlowSky

@Composable
fun SecurityScreen(
  report: SecurityAuditReport?,
  cloudAiEnabled: Boolean,
  shareTelemetryWithAi: Boolean,
  cloudHealthCheckState: CloudHealthCheckState,
  onToggleCloudAi: () -> Unit,
  onToggleShareTelemetryWithAi: () -> Unit,
  onRunCloudHealthCheck: () -> Unit,
  onDeleteAllUserData: () -> Unit,
  onRefreshAudit: () -> Unit,
  onOpenPrivacySettings: () -> Unit,
  onOpenAppPermissions: (String, String) -> Unit,
  onBack: () -> Unit,
  apkInspectionReport: ApkInspectionReport? = null,
  isInspectingApk: Boolean = false,
  aiDiagnosticsReport: AiSystemDiagnosticsReport? = null,
  onInspectApkUri: (Uri) -> Unit = {},
  onRunComprehensiveAiDiagnostics: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  var showDeleteDataDialog by remember { mutableStateOf(false) }

  val apkPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) {
        onInspectApkUri(uri)
      }
    }

  if (showDeleteDataDialog) {
    NexusConfirmationDialog(
      title = "מחיקת כל הנתונים האישיים",
      message =
        "פעולה זו תמחק לצמיתות את היסטוריית הצ'אט, האוטומציות שיצרת, יומני הניקוי והגדרות המשתמש מתוך NEXUS. האם להמשיך?",
      confirmText = "מחק הכל",
      isDestructive = true,
      onConfirm = {
        showDeleteDataDialog = false
        onDeleteAllUserData()
      },
      onDismiss = { showDeleteDataDialog = false }
    )
  }

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isWide = maxWidth >= 740.dp

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("SECURITY, APK & AI AUDIT", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
              Text(
                text = "ביקורת הרשאות אמיתית, בדיקת קבצי APK ואימות מערך הבינה המלאכותית — ללא סריקת וירוסים מדומה.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Icon(Icons.Rounded.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
          Spacer(modifier = Modifier.height(12.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
              onClick = onOpenPrivacySettings,
              modifier = Modifier.weight(1f).testTag("security_open_privacy"),
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
              shape = RoundedCornerShape(14.dp)
            ) {
              Text("נהל הרשאות במערכת")
            }
            OutlinedButton(
              onClick = onRefreshAudit,
              modifier = Modifier.weight(1f).testTag("security_refresh_audit"),
              border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Text("בצע ביקורת חוזרת", color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }

      // APK File Inspector Card
      item {
        NexusHudCard(accentColor = NexusAmber) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(Icons.Rounded.Android, contentDescription = null, tint = NexusAmber)
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text("בודק קבצי התקנה (APK Inspector)", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
                Text("בחר קובץ APK מהמכשיר לבדיקת SHA-256 והרשאות לפני התקנה.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
            OutlinedButton(
              onClick = { apkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*")) },
              enabled = !isInspectingApk,
              modifier = Modifier.testTag("inspect_apk_button")
            ) {
              if (isInspectingApk) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
              } else {
                Text("בחר APK")
              }
            }
          }

          if (apkInspectionReport != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLow,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, (if (apkInspectionReport.highRiskPermissions.isNotEmpty()) NexusAmber else NexusEmerald).copy(alpha = 0.5f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("קובץ: ${apkInspectionReport.fileName} (${formatBytes(apkInspectionReport.sizeBytes)})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text("חבילה: ${apkInspectionReport.packageName ?: "לא מזוהה"} • גרסה: ${apkInspectionReport.versionName ?: "—"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("SHA-256: ${apkInspectionReport.sha256.take(24)}...", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                if (apkInspectionReport.highRiskPermissions.isNotEmpty()) {
                  Text(
                    "הרשאות רגישות: ${apkInspectionReport.highRiskPermissions.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = NexusAmber
                  )
                }
                apkInspectionReport.warningNotesHe.forEach { w ->
                  Text("• $w", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }
            }
          }
        }
      }

      // Privacy & AI Deep Audit Card
      item {
        NexusHudCard(accentColor = NexusGlowSky) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.PrivacyTip, contentDescription = null, tint = NexusGlowSky)
            Spacer(modifier = Modifier.width(8.dp))
            Text("בקרת פרטיות, AI ואבחון חיבורים", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
          }
          Spacer(modifier = Modifier.height(10.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("שירותי בינה מלאכותית בענן (Firebase AI)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              Text("מאפשר עיבוד שפה טבעית, תמלול ושיחה קולית חיה. כיבוי יפעיל מנוע מקומי בלבד.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
              checked = cloudAiEnabled,
              onCheckedChange = { onToggleCloudAi() },
              colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary, checkedTrackColor = NexusElectricBlue.copy(alpha = 0.5f))
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("שיתוף מדדי מכשיר בהקשר העוזר", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
              Text("מצרף אחוז סוללה, אחסון ו-RAM לתשובות מדויקות; ללא שיתוף מידע אישי.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
              checked = shareTelemetryWithAi,
              onCheckedChange = { onToggleShareTelemetryWithAi() },
              colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary, checkedTrackColor = NexusElectricBlue.copy(alpha = 0.5f))
            )
          }
          Spacer(modifier = Modifier.height(10.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
              onClick = onRunCloudHealthCheck,
              enabled = cloudHealthCheckState !is CloudHealthCheckState.Checking,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.weight(1f).testTag("security_cloud_health_check")
            ) {
              if (cloudHealthCheckState is CloudHealthCheckState.Checking) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(6.dp))
                Text("בודק...", color = MaterialTheme.colorScheme.primary)
              } else {
                Icon(Icons.Rounded.CloudDone, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("בדיקת תקינות ענן", color = MaterialTheme.colorScheme.primary)
              }
            }

            Button(
              onClick = onRunComprehensiveAiDiagnostics,
              enabled = aiDiagnosticsReport?.isChecking != true,
              colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.weight(1f).testTag("security_deep_ai_audit_button")
            ) {
              if (aiDiagnosticsReport?.isChecking == true) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text("מאבחן...")
              } else {
                Icon(Icons.Rounded.Psychology, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("בדיקת עומק למודלים")
              }
            }
          }

          when (cloudHealthCheckState) {
            CloudHealthCheckState.Idle -> Unit
            CloudHealthCheckState.Checking -> Unit
            is CloudHealthCheckState.Healthy -> {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = NexusEmerald.copy(alpha = 0.14f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NexusEmerald.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = NexusEmerald)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "תקין (${cloudHealthCheckState.modelChecked} • ${cloudHealthCheckState.latencyMs} מ״ש)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusEmerald
                    )
                    Text(cloudHealthCheckState.summaryHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                  }
                }
              }
            }
            is CloudHealthCheckState.Unhealthy -> {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = NexusCrimson.copy(alpha = 0.14f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = NexusCrimson)
                  Spacer(modifier = Modifier.width(8.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "בדיקת ענן נכשלה (${cloudHealthCheckState.latencyMs} מ״ש)",
                      style = MaterialTheme.typography.titleSmall,
                      color = NexusCrimson
                    )
                    Text(cloudHealthCheckState.error.messageHe, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                  }
                }
              }
            }
          }

          // Deep AI & API Diagnostics Results Panel
          if (aiDiagnosticsReport != null && !aiDiagnosticsReport.isChecking) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              color = MaterialTheme.colorScheme.surfaceContainerLow,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("דוח אבחון מודלים, API ואבטחת AI", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("• ${aiDiagnosticsReport.appCheckStatusHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                Text("• ${aiDiagnosticsReport.keySecuritySummaryHe}", style = MaterialTheme.typography.bodySmall, color = NexusEmerald)
                Text("• ${aiDiagnosticsReport.privacyGuardSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.injectionProtectionSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.fallbackPolicySummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("• ${aiDiagnosticsReport.rateLimiterUsageSummaryHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                aiDiagnosticsReport.models.forEach { m ->
                  val color =
                    when (m.status) {
                      ModelDiagnosticStatus.ACTIVE_HEALTHY -> NexusEmerald
                      ModelDiagnosticStatus.CONFIGURED_READY -> NexusGlowSky
                      ModelDiagnosticStatus.FALLBACK_ONLY -> MaterialTheme.colorScheme.primary
                      ModelDiagnosticStatus.BLOCKED_PAID_TIER -> NexusAmber
                      ModelDiagnosticStatus.UNAVAILABLE -> NexusCrimson
                    }
                  Surface(
                    color = color.copy(alpha = 0.10f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth().padding(8.dp),
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Column(modifier = Modifier.weight(1f)) {
                        Text("${m.modelName} — ${m.status.titleHe}", style = MaterialTheme.typography.labelLarge, color = color)
                        Text("${m.roleHe}: ${m.detailHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                      }
                      if (m.isPaidModel) {
                        Icon(Icons.Rounded.Block, contentDescription = "חסום", tint = NexusAmber, modifier = Modifier.size(18.dp))
                      } else if (m.latencyMs != null) {
                        Text("${m.latencyMs}ms", style = MaterialTheme.typography.labelSmall, color = color)
                      }
                    }
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          OutlinedButton(
            onClick = { showDeleteDataDialog = true },
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.65f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().testTag("security_delete_all_data")
          ) {
            Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = NexusCrimson)
            Spacer(modifier = Modifier.width(6.dp))
            Text("מחק את כל הנתונים האישיים של NEXUS", color = NexusCrimson)
          }
        }
      }

      if (report == null) {
        items(4) { NexusShimmerBox(height = 76.dp) }
      } else {
        item {
          if (isWide) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              PermSummaryTile("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
              PermSummaryTile("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusGlowSky, Modifier.weight(1f))
              PermSummaryTile("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
              PermSummaryTile("הרשאות מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
            }
          } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PermSummaryTile("מצלמה", report.cameraAppsCount, Icons.Rounded.CameraAlt, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                PermSummaryTile("מיקרופון", report.micAppsCount, Icons.Rounded.Mic, NexusGlowSky, Modifier.weight(1f))
              }
              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PermSummaryTile("מיקום", report.locationAppsCount, Icons.Rounded.LocationOn, NexusAmber, Modifier.weight(1f))
                PermSummaryTile("הרשאות מיוחדות", report.specialPermissionAppsCount, Icons.Rounded.Shield, NexusCrimson, Modifier.weight(1f))
              }
            }
          }
        }

        item {
          Text("ממצאים והתראות אבטחה (${report.findings.size})", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
        }

        items(report.findings, key = { it.id }) { finding ->
          val color =
            when (finding.severity) {
              HealthSeverity.CRITICAL -> NexusCrimson
              HealthSeverity.WARNING -> NexusAmber
              HealthSeverity.NOTICE -> NexusGlowSky
              HealthSeverity.OPTIMAL -> NexusEmerald
            }
          NexusHudCard(
            isAlert = finding.severity == HealthSeverity.CRITICAL || finding.severity == HealthSeverity.WARNING,
            accentColor = color,
            contentPadding = 12.dp
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = color)
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(finding.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text(finding.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              if (finding.packageName != null) {
                OutlinedButton(
                  onClick = { onOpenAppPermissions(finding.packageName, finding.appName ?: finding.packageName) },
                  border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
                ) {
                  Text("ניהול", color = color)
                }
              }
            }
          }
        }

        item {
          Text("אפליקציות עם הרשאות רגישות (${report.sensitiveApps.size})", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurface)
        }

        items(report.sensitiveApps.take(25), key = { it.packageName }) { app ->
          Surface(
            color = NexusElectricBlue.copy(alpha = 0.07f),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.25f))
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(app.appName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                val tags =
                  buildList {
                    if (app.hasCameraPermission) add("מצלמה")
                    if (app.hasMicPermission) add("מיקרופון")
                    if (app.hasLocationPermission) add("מיקום")
                    if (app.hasBackgroundLocation) add("מיקום ברקע")
                    if (app.canDrawOverlays) add("שכבת על")
                    if (app.canRequestInstalls) add("התקנת חבילות")
                  }
                Text(tags.joinToString(" • "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              OutlinedButton(
                onClick = { onOpenAppPermissions(app.packageName, app.appName) },
                border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
              ) {
                Text("הרשאות", color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PermSummaryTile(
  label: String,
  count: Int,
  icon: ImageVector,
  accent: Color,
  modifier: Modifier = Modifier
) {
  NexusHudCard(modifier = modifier, accentColor = accent, contentPadding = 12.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = label, tint = accent)
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(text = "$count", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  }
}
