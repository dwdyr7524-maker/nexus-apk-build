package com.example.ui.viewmodel

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import androidx.core.content.ContextCompat
import com.example.NexusApp
import com.example.data.backup.BackedUpFileEntry
import com.example.data.local.ActionAuditEntity
import com.example.data.local.ApprovalProposalEntity
import com.example.data.local.BackupRecordEntity
import com.example.data.local.TelemetrySnapshotEntity
import com.example.data.local.UndoRecordEntity
import com.example.data.model.AiOrganizationPlanReport
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApkInspectionReport
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.DeviceDoctorReport
import com.example.data.model.FileCategory
import com.example.data.model.GlobalSearchResultItem
import com.example.data.model.SecurityAuditReport
import com.example.data.model.SimilarAppGroup
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.SystemTelemetry
import com.example.data.system.AiFileCommanderEngine
import com.example.data.system.DeviceDoctorCalculator
import com.example.data.system.formatBytes
import com.example.ui.navigation.NexusDestination
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Modular delegate handling Smart Storage, SD Card Manager, Duplicate Detector,
 * Device Doctor, Approval Center, Smart Backup/Restore, Undo Center, and Global Search.
 */
class CommanderDelegate(private val app: NexusApp) {
  private val db = app.database
  private val prefs = app.preferencesManager

  private val _smartStorageReport = MutableStateFlow<SmartStorageScanReport?>(null)
  val smartStorageReport: StateFlow<SmartStorageScanReport?> = _smartStorageReport.asStateFlow()

  private val _isScanningFullDevice = MutableStateFlow(false)
  val isScanningFullDevice: StateFlow<Boolean> = _isScanningFullDevice.asStateFlow()

  private val _deviceDoctorReport = MutableStateFlow<DeviceDoctorReport?>(null)
  val deviceDoctorReport: StateFlow<DeviceDoctorReport?> = _deviceDoctorReport.asStateFlow()

  private val _aiOrgPlan = MutableStateFlow<AiOrganizationPlanReport?>(null)
  val aiOrgPlan: StateFlow<AiOrganizationPlanReport?> = _aiOrgPlan.asStateFlow()

  private val _aiOrgInsights = MutableStateFlow<String?>(null)
  val aiOrgInsights: StateFlow<String?> = _aiOrgInsights.asStateFlow()

  private val _similarAppGroups = MutableStateFlow<List<SimilarAppGroup>>(emptyList())
  val similarAppGroups: StateFlow<List<SimilarAppGroup>> = _similarAppGroups.asStateFlow()

  private val _apkInspectionReport = MutableStateFlow<ApkInspectionReport?>(null)
  val apkInspectionReport: StateFlow<ApkInspectionReport?> = _apkInspectionReport.asStateFlow()

  private val _isInspectingApk = MutableStateFlow(false)
  val isInspectingApk: StateFlow<Boolean> = _isInspectingApk.asStateFlow()

  private var lastInsightsSignature: String? = null

  private val _isBackingUp = MutableStateFlow(false)
  val isBackingUp: StateFlow<Boolean> = _isBackingUp.asStateFlow()

  fun hasNotificationPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    } else true
  }

  fun updateDoctorAndSimilarApps(
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?
  ) {
    _similarAppGroups.value = DeviceDoctorCalculator.groupSimilarRoleApps(apps)
    _deviceDoctorReport.value =
      DeviceDoctorCalculator.buildDoctorReport(
        telemetry = telemetry,
        apps = apps,
        securityReport = securityReport,
        storageReport = _smartStorageReport.value,
        hasNotificationPermission = hasNotificationPermission()
      )
  }

  suspend fun runFullDeviceScan(
    telemetry: SystemTelemetry,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    snapshots: List<TelemetrySnapshotEntity>,
    cloudAiEnabled: Boolean,
    shareTelemetryWithAi: Boolean,
    includeAiInsights: Boolean = true
  ): SmartStorageScanReport {
    _isScanningFullDevice.value = true
    try {
      val uris = prefs.safTreeUrisFlow.first()
      val knownLarge = prefs.knownLargeFileIdsFlow.first()
      val report = app.smartStorageEngine.scanSmartStorage(uris, snapshots, knownLarge)
      _smartStorageReport.value = report

      val currentLargeIds = report.files.filter { it.isLargeFile }.map { it.uriString }.toSet()
      prefs.updateKnownLargeFileIds(currentLargeIds)
      prefs.updateLastFullScanMillis(report.scannedAtMillis)

      _similarAppGroups.value = DeviceDoctorCalculator.groupSimilarRoleApps(apps)
      _deviceDoctorReport.value =
        DeviceDoctorCalculator.buildDoctorReport(
          telemetry = telemetry,
          apps = apps,
          securityReport = securityReport,
          storageReport = report,
          hasNotificationPermission = hasNotificationPermission()
        )

      val orgPlan = AiFileCommanderEngine.buildOrganizationPlan(report)
      _aiOrgPlan.value = orgPlan

      val insightsSignature =
        "${report.files.size}|${report.duplicateGroups.size}|${report.folders.size}|${report.hasSdCard}|${report.totalScannedFilesBytes}"
      if (includeAiInsights &&
        cloudAiEnabled &&
        shareTelemetryWithAi &&
        telemetry.network.isConnected &&
        report.files.isNotEmpty() &&
        (insightsSignature != lastInsightsSignature || _aiOrgInsights.value == null)
      ) {
        val catSummary =
          report.categories.joinToString(", ") { "${it.category.titleHe}: ${it.fileCount} (${formatBytes(it.totalBytes)})" }
        val res =
          app.aiProvider.generateFileOrganizationInsights(
            folderNames = report.folders.map { it.folderName }.distinct(),
            categorySummary = catSummary,
            duplicateCount = report.duplicateGroups.size,
            sdMounted = report.hasSdCard,
            allowDeviceContextSharing = true
          )
        res.onSuccess { insight ->
          lastInsightsSignature = insightsSignature
          _aiOrgInsights.value = insight
        }
      } else if (!shareTelemetryWithAi || !cloudAiEnabled) {
        lastInsightsSignature = null
        _aiOrgInsights.value = null
      }

      insertAudit(
        category = "סריקת מכשיר מלאה",
        title = "Smart Storage + Device Doctor",
        succeeded = true,
        details =
          "נסרקו ${report.files.size} קבצים, ${report.duplicateGroups.size} כפילויות, ציון בריאות ${_deviceDoctorReport.value?.totalScore ?: telemetry.healthScore}%"
      )
      return report
    } finally {
      _isScanningFullDevice.value = false
    }
  }

  suspend fun stageDrafts(drafts: List<AiOrganizationProposalDraft>): Int {
    if (drafts.isEmpty()) return 0
    val existingPending = db.approvalProposalDao().getPendingOnce()
    val existingKeys =
      existingPending.map { "${it.operationType}|${it.sourceUriString}|${it.title}" }.toHashSet()
    val now = System.currentTimeMillis()
    val entities =
      drafts
        .filter { "${it.operationType.name}|${it.sourceUriString}|${it.title}" !in existingKeys }
        .map { AiFileCommanderEngine.toPendingEntity(it, now) }
    if (entities.isNotEmpty()) {
      db.approvalProposalDao().insertAll(entities)
    }
    return entities.size
  }

  suspend fun approveAndExecuteProposal(proposal: ApprovalProposalEntity): Pair<Boolean, String> =
    withContext(Dispatchers.IO) {
      val opType =
        ApprovalOperationType.entries.firstOrNull { it.name == proposal.operationType }
          ?: return@withContext false to "סוג פעולה לא מוכר."

      when (opType) {
        ApprovalOperationType.DELETE_NEXUS_CACHE -> {
          val freed = app.deepCleanEngine.clearOwnCaches()
          val msg = "נוקה מטמון פנימי של NEXUS (${formatBytes(freed)})."
          markApproved(proposal, msg)
          recordUndo(
            title = proposal.title,
            undoType = "NONE",
            isUndoable = false,
            noteHe = "מטמון אפליקציה שנוקה נוצר מחדש אוטומטית לפי צורך."
          )
          true to msg
        }

        ApprovalOperationType.DELETE_SAF_DOCUMENT -> {
          val uri = proposal.sourceUriString?.let { Uri.parse(it) }
          if (uri == null) {
            markFailed(proposal, "כתובת קובץ חסרה.")
            return@withContext false to "כתובת קובץ חסרה."
          }
          val ok = app.smartStorageEngine.deleteSafDocument(uri)
          if (ok) {
            val msg = "נמחק באישור: ${proposal.targetName} (${formatBytes(proposal.bytesAffected)})."
            markApproved(proposal, msg)
            recordUndo(
              title = proposal.title,
              undoType = "NONE",
              isUndoable = false,
              noteHe = "מחיקת קובץ ב-SAF אינה הפיכה ללא גיבוי מוקדם (בדוק את מרכז הגיבויים)."
            )
            true to msg
          } else {
            val err = "המחיקה נכשלה — ייתכן שהקובץ נמחק קודם או שהרשאת SAF פגה."
            markFailed(proposal, err)
            false to err
          }
        }

        ApprovalOperationType.RENAME_SAF_DOCUMENT -> {
          val uri = proposal.sourceUriString?.let { Uri.parse(it) }
          val newName = proposal.proposedNewName
          if (uri == null || newName.isNullOrBlank()) {
            markFailed(proposal, "חסרים נתונים לשינוי שם.")
            return@withContext false to "חסרים נתונים לשינוי שם."
          }
          val renamedUri = app.smartStorageEngine.renameSafDocument(uri, newName)
          if (renamedUri != null) {
            val msg = "השם שונה מ-${proposal.targetName} ל-$newName."
            markApproved(proposal, msg)
            recordUndo(
              title = proposal.title,
              undoType = "RENAME_BACK",
              targetUriString = renamedUri.toString(),
              previousName = proposal.targetName,
              isUndoable = true,
              noteHe = "ניתן להחזיר לשם הקודם (${proposal.targetName})."
            )
            true to msg
          } else {
            val err = "שינוי השם נכשל ב-SAF."
            markFailed(proposal, err)
            false to err
          }
        }

        ApprovalOperationType.CREATE_SAF_FOLDER -> {
          val treeUri = proposal.treeUriString?.let { Uri.parse(it) }
          val folderName = proposal.destFolderName ?: proposal.targetName
          if (treeUri == null || folderName.isBlank()) {
            markFailed(proposal, "תיקיית יעד חסרה.")
            return@withContext false to "תיקיית יעד חסרה."
          }
          val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
          val created = rootId?.let { app.smartStorageEngine.ensureSubfolder(treeUri, it, folderName) }
          if (created != null) {
            val msg = "נוצרה התיקייה '$folderName'."
            markApproved(proposal, msg)
            recordUndo(
              title = proposal.title,
              undoType = "DELETE_CREATED_EMPTY_FOLDER",
              targetUriString = created.second.toString(),
              isUndoable = true,
              noteHe = "ניתן למחוק את התיקייה שנוצרה אם נותרה ריקה."
            )
            true to msg
          } else {
            markFailed(proposal, "יצירת התיקייה נכשלה.")
            false to "יצירת התיקייה נכשלה."
          }
        }

        ApprovalOperationType.MOVE_SAF_DOCUMENT,
        ApprovalOperationType.ORGANIZE_DOWNLOAD_FILE -> {
          val srcUri = proposal.sourceUriString?.let { Uri.parse(it) }
          val srcTree = proposal.treeUriString?.let { Uri.parse(it) }
          val dstTree = (proposal.destTreeUriString ?: proposal.treeUriString)?.let { Uri.parse(it) }
          val folderName = proposal.destFolderName ?: "מאורגן"
          if (srcUri == null || srcTree == null || dstTree == null) {
            markFailed(proposal, "נתיב מקור או יעד חסר.")
            return@withContext false to "נתיב מקור או יעד חסר."
          }
          val dstRootId = runCatching { DocumentsContract.getTreeDocumentId(dstTree) }.getOrNull()
          val dstFolder = dstRootId?.let { app.smartStorageEngine.ensureSubfolder(dstTree, it, folderName) }
          if (dstFolder == null) {
            markFailed(proposal, "לא ניתן ליצור או לפתוח את תיקיית היעד '$folderName'.")
            return@withContext false to "לא ניתן לפתוח תיקיית יעד."
          }
          val srcParentDocId = runCatching { DocumentsContract.getTreeDocumentId(srcTree) }.getOrNull()
          val movedUri =
            app.smartStorageEngine.moveSafDocumentToFolder(
              sourceDocUri = srcUri,
              sourceParentDocId = srcParentDocId,
              sourceTreeUri = srcTree,
              destTreeUri = dstTree,
              destParentDocId = dstFolder.first,
              targetName = proposal.targetName,
              mimeType = "application/octet-stream"
            )
          if (movedUri != null) {
            val msg = "הקובץ ${proposal.targetName} הועבר אל '$folderName'."
            markApproved(proposal, msg)
            recordUndo(
              title = proposal.title,
              undoType = "MOVE_BACK",
              targetUriString = movedUri.toString(),
              originalParentDocId = dstFolder.first,
              originalTreeUriString = proposal.treeUriString,
              previousName = proposal.targetName,
              backupManifestId = null,
              isUndoable = true,
              noteHe = "ניתן להחזיר את ${proposal.targetName} חזרה לשורש התיקייה המקורית."
            )
            true to msg
          } else {
            val err = "ההעברה נכשלה — המקור נשמר ללא שינוי."
            markFailed(proposal, err)
            false to err
          }
        }

        ApprovalOperationType.COPY_SAF_DOCUMENT -> {
          val srcUri = proposal.sourceUriString?.let { Uri.parse(it) }
          val dstTree = (proposal.destTreeUriString ?: proposal.treeUriString)?.let { Uri.parse(it) }
          val folderName = proposal.destFolderName ?: "NEXUS_Copy"
          if (srcUri == null || dstTree == null) {
            markFailed(proposal, "נתיב העתקה חסר.")
            return@withContext false to "נתיב העתקה חסר."
          }
          val dstRootId = runCatching { DocumentsContract.getTreeDocumentId(dstTree) }.getOrNull()
          val dstFolder = dstRootId?.let { app.smartStorageEngine.ensureSubfolder(dstTree, it, folderName) }
          val copied =
            dstFolder?.let {
              app.smartStorageEngine.copySafDocumentToFolder(
                sourceDocUri = srcUri,
                destTreeUri = dstTree,
                destParentDocId = it.first,
                targetName = proposal.targetName,
                mimeType = "application/octet-stream"
              )
            }
          if (copied != null) {
            val msg = "הקובץ ${proposal.targetName} הועתק בהצלחה אל '$folderName'."
            markApproved(proposal, msg)
            recordUndo(
              title = proposal.title,
              undoType = "DELETE_CREATED_EMPTY_FOLDER",
              targetUriString = copied.toString(),
              isUndoable = true,
              noteHe = "ניתן למחוק את העותק שנוצר."
            )
            true to msg
          } else {
            markFailed(proposal, "העתקת הקובץ נכשלה.")
            false to "העתקת הקובץ נכשלה."
          }
        }

        ApprovalOperationType.BACKUP_FOLDER_SNAPSHOT -> {
          val srcTree = proposal.treeUriString
          val dstTree = proposal.destTreeUriString
          if (srcTree == null || dstTree == null) {
            markFailed(proposal, "יש לבחור תיקיית מקור ויעד לגיבוי.")
            return@withContext false to "חסר מקור/יעד לגיבוי."
          }
          val res = createSafBackup(srcTree, dstTree)
          res.fold(
            onSuccess = { rec ->
              markApproved(proposal, rec.integritySummaryHe)
              true to rec.integritySummaryHe
            },
            onFailure = { e ->
              val err = e.localizedMessage ?: "הגיבוי נכשל."
              markFailed(proposal, err)
              false to err
            }
          )
        }

        ApprovalOperationType.RESTORE_BACKUP_FILE -> {
          val id = proposal.packageName?.toLongOrNull()
          val backup = id?.let { db.backupRecordDao().getById(it) }
          if (backup == null) {
            markFailed(proposal, "רשומת הגיבוי לא נמצאה.")
            return@withContext false to "רשומת הגיבוי לא נמצאה."
          }
          val entries = app.storageBackupEngine.parseManifest(backup)
          val res = app.storageBackupEngine.restoreBackupEntries(entries)
          res.fold(
            onSuccess = { summary ->
              markApproved(proposal, summary)
              true to summary
            },
            onFailure = { e ->
              val err = e.localizedMessage ?: "השחזור נכשל."
              markFailed(proposal, err)
              false to err
            }
          )
        }

        ApprovalOperationType.OPEN_UNINSTALL_APP -> {
          val pkg = proposal.packageName
          if (pkg.isNullOrBlank()) {
            markFailed(proposal, "שם חבילה חסר.")
            return@withContext false to "שם חבילה חסר."
          }
          val intent =
            Intent(Intent.ACTION_DELETE).apply {
              data = Uri.fromParts("package", pkg, null)
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
          val launched =
            runCatching {
              app.startActivity(intent)
              true
            }.getOrDefault(false)
          if (launched) {
            val msg = "נפתח מסך ההסרה הרשמי של Android עבור ${proposal.targetName}."
            markApproved(proposal, msg)
            true to msg
          } else {
            markFailed(proposal, "לא ניתן לפתוח את מסך ההסרה של Android.")
            false to "פתיחת מסך ההסרה נכשלה."
          }
        }

        ApprovalOperationType.OPEN_SYSTEM_SETTINGS -> {
          val pkg = proposal.packageName
          val ok =
            if (!pkg.isNullOrBlank()) app.appIntelligenceProvider.openAppSettings(pkg)
            else false
          if (ok) {
            val msg = "נפתחו הגדרות Android עבור ${proposal.targetName}."
            markApproved(proposal, msg)
            true to msg
          } else {
            markFailed(proposal, "פתיחת הגדרות המערכת נכשלה.")
            false to "פתיחת הגדרות נכשלה."
          }
        }
      }
    }

  suspend fun rejectProposal(proposal: ApprovalProposalEntity) {
    db.approvalProposalDao().updateStatus(proposal.id, "REJECTED", "נדחה על ידי המשתמש — לא בוצע שינוי.")
    insertAudit("מרכז אישורים", "דחיית פעולה: ${proposal.title}", true, "נדחה לפי בקשת המשתמש")
  }

  suspend fun rejectAllPending() {
    db.approvalProposalDao().clearPending()
    insertAudit("מרכז אישורים", "דחיית כל ההצעות הממתינות", true, "נוקתה רשימת האישורים")
  }

  suspend fun executeUndo(record: UndoRecordEntity): Pair<Boolean, String> =
    withContext(Dispatchers.IO) {
      if (!record.isUndoable || record.undone) {
        return@withContext false to "פעולה זו אינה זמינה לביטול."
      }
      when (record.undoType) {
        "RENAME_BACK" -> {
          val uri = record.targetUriString?.let { Uri.parse(it) }
          val prev = record.previousName
          if (uri == null || prev.isNullOrBlank()) return@withContext false to "פרטי הקובץ חסרים."
          val reverted = app.smartStorageEngine.renameSafDocument(uri, prev) != null
          if (reverted) {
            val msg = "השם הוחזר בהצלחה ל-$prev."
            db.undoRecordDao().markUndone(record.id, msg)
            insertAudit("מרכז ביטול (Undo)", record.actionTitle, true, msg)
            true to msg
          } else false to "לא ניתן לשחזר את השם — בדוק אם הקובץ עדיין קיים."
        }
        "DELETE_CREATED_EMPTY_FOLDER" -> {
          val uri = record.targetUriString?.let { Uri.parse(it) }
            ?: return@withContext false to "כתובת חסרה."
          val deleted = app.smartStorageEngine.deleteSafDocument(uri)
          if (deleted) {
            val msg = "הפריט שנוצר הוסר בהצלחה."
            db.undoRecordDao().markUndone(record.id, msg)
            insertAudit("מרכז ביטול (Undo)", record.actionTitle, true, msg)
            true to msg
          } else false to "הביטול נכשל — ייתכן שהתיקייה אינה ריקה או שכבר נמחקה."
        }
        "MOVE_BACK" -> {
          val curUri = record.targetUriString?.let { Uri.parse(it) }
          val origTree = record.originalTreeUriString?.let { Uri.parse(it) }
          val origParentDocId = origTree?.let { runCatching { DocumentsContract.getTreeDocumentId(it) }.getOrNull() }
          val name = record.previousName ?: "restored_file"
          if (curUri == null || origTree == null || origParentDocId == null) {
            return@withContext false to "נתיב החזרה חסר."
          }
          val movedBack =
            app.smartStorageEngine.moveSafDocumentToFolder(
              sourceDocUri = curUri,
              sourceParentDocId = record.originalParentDocId,
              sourceTreeUri = origTree,
              destTreeUri = origTree,
              destParentDocId = origParentDocId,
              targetName = name,
              mimeType = "application/octet-stream"
            )
          if (movedBack != null) {
            val msg = "הקובץ '$name' הוחזר לתיקיית המקור."
            db.undoRecordDao().markUndone(record.id, msg)
            insertAudit("מרכז ביטול (Undo)", record.actionTitle, true, msg)
            true to msg
          } else false to "ההחזרה נכשלה."
        }
        else -> false to "לא נתמך ביטול עבור פעולה זו."
      }
    }

  suspend fun createSafBackup(sourceTreeUri: String, destTreeUri: String): Result<BackupRecordEntity> {
    _isBackingUp.value = true
    return try {
      val res = app.storageBackupEngine.createFolderBackup(sourceTreeUri, destTreeUri)
      res.onSuccess { rec ->
        db.backupRecordDao().insert(rec)
        insertAudit("גיבוי חכם", "גיבוי ${rec.sourceLabel}", rec.verifiedOk, rec.integritySummaryHe)
      }.onFailure { e ->
        if (e is CancellationException) throw e
        insertAudit("גיבוי חכם", "גיבוי תיקייה", false, "נכשל", e.localizedMessage)
      }
      res
    } finally {
      _isBackingUp.value = false
    }
  }

  suspend fun restoreBackup(record: BackupRecordEntity, singleFile: BackedUpFileEntry? = null): Result<String> {
    val entries =
      if (singleFile != null) listOf(singleFile)
      else app.storageBackupEngine.parseManifest(record)
    val res = app.storageBackupEngine.restoreBackupEntries(entries)
    res.onSuccess { msg ->
      insertAudit("גיבוי חכם", "שחזור ${record.sourceLabel}", true, msg)
    }.onFailure { e ->
      if (e is CancellationException) throw e
      insertAudit("גיבוי חכם", "שחזור ${record.sourceLabel}", false, "נכשל", e.localizedMessage)
    }
    return res
  }

  suspend fun inspectApk(uri: Uri): ApkInspectionReport {
    _isInspectingApk.value = true
    return try {
      val report = app.deviceDoctorEngine.inspectApkUri(uri)
      _apkInspectionReport.value = report
      insertAudit(
        category = "מרכז אבטחה ו-APK",
        title = "בדיקת חבילה: ${report.fileName}",
        succeeded = report.parsedSuccessfully,
        details = report.packageName ?: "לא מזוהה"
      )
      report
    } finally {
      _isInspectingApk.value = false
    }
  }

  fun searchGlobal(
    query: String,
    apps: List<AppDiagnosticInfo>,
    securityReport: SecurityAuditReport?,
    pendingApprovals: List<ApprovalProposalEntity>
  ): List<GlobalSearchResultItem> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return emptyList()
    val results = mutableListOf<GlobalSearchResultItem>()

    // 1. Screens & Modules
    NexusDestination.entries
      .filter { it.labelHe.lowercase().contains(q) || it.shortLabelHe.lowercase().contains(q) }
      .forEach { dest ->
        results +=
          GlobalSearchResultItem(
            id = "nav_${dest.route}",
            title = dest.labelHe,
            subtitle = "מסך במערכת",
            categoryLabel = "ניווט",
            targetRoute = dest.route
          )
      }

    // 2. Scanned Files & Duplicates
    _smartStorageReport.value?.files
      ?.filter { it.name.lowercase().contains(q) || it.relativePath.lowercase().contains(q) || it.category.titleHe.contains(q) }
      ?.take(12)
      ?.forEach { f ->
        results +=
          GlobalSearchResultItem(
            id = "file_${f.uriString}",
            title = f.name,
            subtitle = "${f.relativePath} • ${formatBytes(f.sizeBytes)}",
            categoryLabel = f.category.titleHe,
            targetRoute = NexusDestination.SMART_STORAGE.route
          )
      }

    // 3. Installed Apps
    apps
      .filter { it.appName.lowercase().contains(q) || it.packageName.lowercase().contains(q) }
      .take(8)
      .forEach { appInfo ->
        results +=
          GlobalSearchResultItem(
            id = "app_${appInfo.packageName}",
            title = appInfo.appName,
            subtitle = "${appInfo.packageName} • ${formatBytes(appInfo.totalSizeBytes)}",
            categoryLabel = "אפליקציה",
            targetRoute = NexusDestination.APPS.route
          )
      }

    // 4. Device Doctor & Security Issues
    _deviceDoctorReport.value?.checks
      ?.filter { it.categoryTitleHe.lowercase().contains(q) || it.detailHe.lowercase().contains(q) }
      ?.forEach { chk ->
        results +=
          GlobalSearchResultItem(
            id = "doc_${chk.id}",
            title = chk.categoryTitleHe,
            subtitle = chk.statusTitleHe,
            categoryLabel = "אבחון",
            targetRoute = chk.targetRoute ?: NexusDestination.DEVICE_DOCTOR.route
          )
      }

    securityReport?.findings
      ?.filter { it.title.lowercase().contains(q) || it.description.lowercase().contains(q) }
      ?.take(5)
      ?.forEach { f ->
        results +=
          GlobalSearchResultItem(
            id = "sec_${f.id}",
            title = f.title,
            subtitle = f.description,
            categoryLabel = "אבטחה",
            targetRoute = NexusDestination.SECURITY.route
          )
      }

    // 5. Pending Approvals
    pendingApprovals
      .filter { it.title.lowercase().contains(q) || it.targetName.lowercase().contains(q) }
      .take(6)
      .forEach { prop ->
        results +=
          GlobalSearchResultItem(
            id = "prop_${prop.id}",
            title = prop.title,
            subtitle = prop.reasonHe,
            categoryLabel = "ממתין לאישור",
            targetRoute = NexusDestination.APPROVAL_CENTER.route
          )
      }

    return results.take(30)
  }

  private suspend fun markApproved(proposal: ApprovalProposalEntity, msg: String) {
    db.approvalProposalDao().updateStatus(proposal.id, "APPROVED_EXECUTED", msg)
    insertAudit("מרכז אישורים", proposal.title, true, msg)
  }

  private suspend fun markFailed(proposal: ApprovalProposalEntity, reason: String) {
    db.approvalProposalDao().updateStatus(proposal.id, "FAILED", reason)
    insertAudit("מרכז אישורים", proposal.title, false, "נכשל בביצוע", reason)
  }

  private suspend fun recordUndo(
    title: String,
    undoType: String,
    targetUriString: String? = null,
    originalParentDocId: String? = null,
    originalTreeUriString: String? = null,
    previousName: String? = null,
    backupManifestId: Long? = null,
    isUndoable: Boolean,
    noteHe: String
  ) {
    db.undoRecordDao().insert(
      UndoRecordEntity(
        createdAtMillis = System.currentTimeMillis(),
        actionTitle = title,
        undoType = undoType,
        targetUriString = targetUriString,
        originalParentDocId = originalParentDocId,
        originalTreeUriString = originalTreeUriString,
        previousName = previousName,
        backupManifestId = backupManifestId,
        isUndoable = isUndoable,
        undone = false,
        noteHe = noteHe
      )
    )
  }

  private suspend fun insertAudit(
    category: String,
    title: String,
    succeeded: Boolean,
    details: String,
    failureReason: String? = null
  ) {
    db.actionAuditDao().insert(
      ActionAuditEntity(
        timestampMillis = System.currentTimeMillis(),
        category = category,
        actionTitle = title,
        succeeded = succeeded,
        details = details,
        failureReason = failureReason
      )
    )
  }
}
