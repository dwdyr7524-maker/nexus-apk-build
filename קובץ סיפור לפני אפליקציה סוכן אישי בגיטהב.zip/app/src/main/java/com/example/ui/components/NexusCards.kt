package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalPerformanceMode
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusCharcoal
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusLightCard
import com.example.ui.theme.NexusLightCardElevated
import com.example.ui.theme.NexusLightSurface
import com.example.ui.theme.NexusTitaniumCard
import com.example.ui.theme.NexusTitaniumElevated

@Composable
fun NexusHudCard(
  modifier: Modifier = Modifier,
  selected: Boolean = false,
  isAlert: Boolean = false,
  accentColor: Color = NexusBorderGlow,
  contentPadding: Dp = 16.dp,
  content: @Composable ColumnScope.() -> Unit
) {
  val perfMode = LocalPerformanceMode.current
  val isDark = LocalIsDarkTheme.current
  val primaryColor = MaterialTheme.colorScheme.primary
  val errorColor = MaterialTheme.colorScheme.error

  val alertPulse =
    if (isAlert && !perfMode) {
      val inf = rememberInfiniteTransition(label = "alert_pulse")
      val v by
        inf.animateFloat(
          initialValue = 0.45f,
          targetValue = 1f,
          animationSpec =
            infiniteRepeatable(
              animation = tween(900, easing = FastOutSlowInEasing),
              repeatMode = RepeatMode.Reverse
            ),
          label = "alert_alpha"
        )
      v
    } else {
      0.85f
    }

  val borderColor by
    animateColorAsState(
      targetValue =
        when {
          isAlert -> errorColor.copy(alpha = alertPulse)
          selected -> primaryColor
          else -> accentColor.copy(alpha = if (isDark) 0.35f else 0.45f)
        },
      label = "card_border"
    )

  val elevation by
    animateDpAsState(
      targetValue = if (selected) 10.dp else if (isDark) 3.dp else 2.dp,
      label = "card_elevation"
    )

  val cardBgColors =
    if (isDark) {
      listOf(
        if (selected) NexusTitaniumElevated else NexusTitaniumCard.copy(alpha = 0.92f),
        NexusCharcoal.copy(alpha = 0.95f)
      )
    } else {
      listOf(
        if (selected) NexusLightCardElevated else NexusLightSurface,
        NexusLightCard
      )
    }

  Surface(
    modifier =
      modifier.graphicsLayer {
        if (selected && !perfMode) {
          scaleX = 1.012f
          scaleY = 1.012f
        }
      },
    shape = RoundedCornerShape(20.dp),
    color = Color.Transparent,
    tonalElevation = elevation,
    shadowElevation = elevation,
    border = BorderStroke(1.2.dp, borderColor)
  ) {
    Box(
      modifier =
        Modifier
          .background(Brush.linearGradient(colors = cardBgColors))
          .padding(contentPadding)
    ) {
      Column(content = content)
    }
  }
}

@Composable
fun NexusConfirmationDialog(
  title: String,
  message: String,
  confirmText: String,
  cancelText: String = "ביטול",
  isDestructive: Boolean = false,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = MaterialTheme.colorScheme.surfaceVariant,
    titleContentColor = MaterialTheme.colorScheme.onSurface,
    textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
    shape = RoundedCornerShape(22.dp),
    title = {
      Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        color = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
      )
    },
    text = {
      Text(
        text = message,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
            contentColor = MaterialTheme.colorScheme.onSecondary
          ),
        modifier = Modifier.testTag("dialog_confirm_button")
      ) {
        Text(text = confirmText)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.testTag("dialog_cancel_button")
      ) {
        Text(text = cancelText, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
  )
}
