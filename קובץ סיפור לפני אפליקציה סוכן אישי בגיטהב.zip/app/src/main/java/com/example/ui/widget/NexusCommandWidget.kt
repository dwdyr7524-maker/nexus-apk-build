package com.example.ui.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.Button
import androidx.glance.ButtonDefaults
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.MainActivity
import com.example.data.local.PreferencesManager
import com.example.data.system.NexusNotificationHelper
import com.example.data.system.SystemTelemetryProvider
import com.example.data.system.formatBytes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class NexusCommandWidget : GlanceAppWidget() {

  override suspend fun provideGlance(context: Context, id: GlanceId) {
    val snapshot =
      withContext(Dispatchers.IO) {
        val foldersCount = runCatching { PreferencesManager(context).safTreeUrisFlow.first().size }.getOrDefault(0)
        SystemTelemetryProvider(context).captureTelemetry(foldersCount)
      }

    val updatedTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(snapshot.capturedAtMillis))

    provideContent {
      NexusWidgetContent(
        context = context,
        healthScore = snapshot.healthScore,
        batteryPercent = snapshot.battery.levelPercent,
        batteryTempC = snapshot.battery.temperatureC,
        ramUsedPercent = snapshot.ram.usedPercent,
        freeStorage = formatBytes(snapshot.storage.freeBytes),
        updatedTime = updatedTime
      )
    }
  }

  @Composable
  private fun NexusWidgetContent(
    context: Context,
    healthScore: Int,
    batteryPercent: Int,
    batteryTempC: Float,
    ramUsedPercent: Int,
    freeStorage: String,
    updatedTime: String
  ) {
    val bg = ColorProvider(Color(0xFF0A1424))
    val cardBg = ColorProvider(Color(0xFF132238))
    val cyan = ColorProvider(Color(0xFF00E5FF))
    val emerald = ColorProvider(Color(0xFF10E59A))
    val amber = ColorProvider(Color(0xFFFFB74D))
    val textPrimary = ColorProvider(Color(0xFFF2F6FF))
    val textSecondary = ColorProvider(Color(0xFF9AB0CE))

    val scoreColor =
      when {
        healthScore >= 85 -> emerald
        healthScore >= 65 -> cyan
        else -> amber
      }

    Column(
      modifier =
        GlanceModifier
          .fillMaxSize()
          .background(bg)
          .cornerRadius(20.dp)
          .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = GlanceModifier.fillMaxWidth(),
        horizontalAlignment = Alignment.Start,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "NEXUS AI • בריאות $healthScore%",
          style = TextStyle(color = scoreColor, fontSize = 15.sp, fontWeight = FontWeight.Bold),
          modifier = GlanceModifier.defaultWeight()
        )
        Text(
          text = "עודכן $updatedTime",
          style = TextStyle(color = textSecondary, fontSize = 11.sp)
        )
      }

      Spacer(modifier = GlanceModifier.height(8.dp))

      Row(modifier = GlanceModifier.fillMaxWidth()) {
        MetricPill(
          label = "סוללה",
          value = "$batteryPercent% • ${String.format(Locale.US, "%.0f", batteryTempC)}°C",
          valueColor = if (batteryPercent <= 15 || batteryTempC >= 42f) amber else emerald,
          cardBg = cardBg,
          labelColor = textSecondary,
          modifier = GlanceModifier.defaultWeight()
        )
        Spacer(modifier = GlanceModifier.width(6.dp))
        MetricPill(
          label = "RAM",
          value = "$ramUsedPercent% בשימוש",
          valueColor = cyan,
          cardBg = cardBg,
          labelColor = textSecondary,
          modifier = GlanceModifier.defaultWeight()
        )
        Spacer(modifier = GlanceModifier.width(6.dp))
        MetricPill(
          label = "פנוי",
          value = freeStorage,
          valueColor = textPrimary,
          cardBg = cardBg,
          labelColor = textSecondary,
          modifier = GlanceModifier.defaultWeight()
        )
      }

      Spacer(modifier = GlanceModifier.height(8.dp))

      Row(modifier = GlanceModifier.fillMaxWidth()) {
        Button(
          text = "עוזר AI",
          onClick = actionStartActivity(routeIntent(context, "assistant")),
          colors = ButtonDefaults.buttonColors(backgroundColor = ColorProvider(Color(0xFF1D4ED8)), contentColor = textPrimary),
          modifier = GlanceModifier.defaultWeight()
        )
        Spacer(modifier = GlanceModifier.width(6.dp))
        Button(
          text = "ניקוי",
          onClick = actionStartActivity(routeIntent(context, "deep_clean")),
          colors = ButtonDefaults.buttonColors(backgroundColor = ColorProvider(Color(0xFF0E7490)), contentColor = textPrimary),
          modifier = GlanceModifier.defaultWeight()
        )
        Spacer(modifier = GlanceModifier.width(6.dp))
        Button(
          text = "רענן",
          onClick = actionRunCallback<RefreshNexusWidgetAction>(),
          colors = ButtonDefaults.buttonColors(backgroundColor = cardBg, contentColor = cyan),
          modifier = GlanceModifier.defaultWeight()
        )
      }
    }
  }

  @Composable
  private fun MetricPill(
    label: String,
    value: String,
    valueColor: ColorProvider,
    cardBg: ColorProvider,
    labelColor: ColorProvider,
    modifier: GlanceModifier = GlanceModifier
  ) {
    Column(
      modifier =
        modifier
          .background(cardBg)
          .cornerRadius(12.dp)
          .padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = label, style = TextStyle(color = labelColor, fontSize = 11.sp))
      Text(
        text = value,
        style = TextStyle(color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.Bold),
        maxLines = 1
      )
    }
  }

  private fun routeIntent(context: Context, route: String): Intent {
    return Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
      putExtra(NexusNotificationHelper.EXTRA_TARGET_ROUTE, route)
    }
  }
}

class RefreshNexusWidgetAction : ActionCallback {
  override suspend fun onAction(
    context: Context,
    glanceId: GlanceId,
    parameters: ActionParameters
  ) {
    NexusCommandWidget().updateAll(context)
  }
}

class NexusCommandWidgetReceiver : GlanceAppWidgetReceiver() {
  override val glanceAppWidget: GlanceAppWidget = NexusCommandWidget()
}
