package com.example.ui.screens

import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Launch
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.model.AppDiagnosticInfo
import com.example.data.model.AppFilterMode
import com.example.data.model.AppSortMode
import com.example.data.model.SimilarAppGroup
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.components.NexusShimmerBox
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusBorderGlow
import com.example.ui.theme.NexusBorderSubtle
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.viewmodel.AppsUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppsScreen(
  state: AppsUiState,
  hasUsageAccess: Boolean,
  onSearchChange: (String) -> Unit,
  onSortChange: (AppSortMode) -> Unit,
  onFilterChange: (AppFilterMode) -> Unit,
  onSelectApp: (String) -> Unit,
  onLaunchApp: (String, String) -> Unit,
  onOpenAppSettings: (String, String) -> Unit,
  onOpenUsageAccess: () -> Unit,
  onBack: () -> Unit,
  similarAppGroups: List<SimilarAppGroup> = emptyList(),
  onRequestUninstallProposal: (AppDiagnosticInfo) -> Unit = {},
  modifier: Modifier = Modifier
) {
  BackHandler(onBack = onBack)

  val filteredApps =
    remember(state.allApps, state.searchQuery, state.sortMode, state.filterMode) {
      state.allApps
        .filter { app ->
          val matchesFilter =
            when (state.filterMode) {
              AppFilterMode.ALL -> true
              AppFilterMode.USER_APPS -> !app.isSystemApp
              AppFilterMode.SYSTEM_APPS -> app.isSystemApp
              AppFilterMode.DORMANT -> app.isDormant
            }
          val q = state.searchQuery.trim()
          val matchesQuery =
            q.isEmpty() ||
              app.appName.contains(q, ignoreCase = true) ||
              app.packageName.contains(q, ignoreCase = true)
          matchesFilter && matchesQuery
        }
        .let { list ->
          when (state.sortMode) {
            AppSortMode.SIZE_DESC -> list.sortedByDescending { it.totalSizeBytes }
            AppSortMode.NAME_ASC -> list.sortedBy { it.appName.lowercase() }
            AppSortMode.RECENT_UPDATED -> list.sortedByDescending { it.lastUpdateTime }
            AppSortMode.LEAST_USED ->
              list.sortedWith(
                compareBy<AppDiagnosticInfo> { it.isSystemApp }
                  .thenBy { it.lastTimeUsedMillis ?: 0L }
                  .thenByDescending { it.totalSizeBytes }
              )
          }
        }
    }

  val selectedApp =
    filteredApps.firstOrNull { it.packageName == state.selectedPackageName }
      ?: filteredApps.firstOrNull()

  BoxWithConstraints(modifier = modifier.fillMaxSize()) {
    val isTabletWide = maxWidth >= 760.dp

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
      NexusHudCard(contentPadding = 12.dp) {
        Text("APP INTELLIGENCE (${filteredApps.size})", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        if (!hasUsageAccess) {
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "הערה: מוצג נפח APK בסיסי. להצגת נתוני אפליקציה ומטמון מדויקים, לחץ כאן לאישור נתוני שימוש.",
            style = MaterialTheme.typography.bodyMedium,
            color = NexusAmber,
            modifier = Modifier.clickable(onClick = onOpenUsageAccess)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = state.searchQuery,
          onValueChange = onSearchChange,
          modifier = Modifier.fillMaxWidth().testTag("apps_search_field"),
          placeholder = { Text("חפש אפליקציה או שם חבילה...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaterialTheme.colorScheme.primary,
              unfocusedBorderColor = NexusBorderSubtle,
              focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
              unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
              focusedTextColor = MaterialTheme.colorScheme.onSurface,
              unfocusedTextColor = MaterialTheme.colorScheme.onSurface
            )
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          AppSortMode.entries.forEach { mode ->
            val label =
              when (mode) {
                AppSortMode.SIZE_DESC -> "מיון: נפח אחסון"
                AppSortMode.NAME_ASC -> "מיון: שם"
                AppSortMode.RECENT_UPDATED -> "מיון: עודכנו לאחרונה"
                AppSortMode.LEAST_USED -> "מיון: שימוש מועט"
              }
            FilterChip(
              selected = state.sortMode == mode,
              onClick = { onSortChange(mode) },
              label = { Text(label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NexusElectricBlue.copy(alpha = 0.25f),
                  selectedLabelColor = MaterialTheme.colorScheme.primary
                )
            )
          }
          AppFilterMode.entries.forEach { f ->
            val label =
              when (f) {
                AppFilterMode.ALL -> "הכול"
                AppFilterMode.USER_APPS -> "אפליקציות משתמש"
                AppFilterMode.SYSTEM_APPS -> "מערכת"
                AppFilterMode.DORMANT -> "רדומות (30+ יום)"
              }
            FilterChip(
              selected = state.filterMode == f,
              onClick = { onFilterChange(f) },
              label = { Text(label) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NexusEmerald.copy(alpha = 0.25f),
                  selectedLabelColor = NexusEmerald
                )
            )
          }
        }
      }

      if (similarAppGroups.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        NexusHudCard(accentColor = NexusAmber, contentPadding = 12.dp) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Apps, contentDescription = null, tint = NexusAmber, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              "זיהוי אפליקציות דומות בתפקידן (${similarAppGroups.size} קבוצות)",
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            similarAppGroups.forEach { grp ->
              Surface(
                color = NexusAmber.copy(alpha = 0.12f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.4f)),
                modifier = Modifier.width(260.dp)
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text("${grp.roleTitleHe} (${grp.apps.size})", style = MaterialTheme.typography.labelLarge, color = NexusAmber)
                  Text(grp.apps.joinToString(", ") { it.appName }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                  Text(grp.adviceHe, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (state.isLoading) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          repeat(5) { NexusShimmerBox(height = 72.dp) }
        }
      } else if (isTabletWide) {
        Row(
          modifier = Modifier.fillMaxSize(),
          horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          LazyColumn(
            modifier = Modifier.weight(0.55f).fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(filteredApps, key = { it.packageName }) { app ->
              AppListRow(
                app = app,
                selected = selectedApp?.packageName == app.packageName,
                onClick = { onSelectApp(app.packageName) },
                onLaunchApp = onLaunchApp,
                onOpenAppSettings = onOpenAppSettings,
                onRequestUninstallProposal = onRequestUninstallProposal,
                showInlineActions = false
              )
            }
          }
          Box(modifier = Modifier.weight(0.45f).fillMaxHeight()) {
            selectedApp?.let { detail ->
              AppDetailPane(
                app = detail,
                hasUsageAccess = hasUsageAccess,
                onLaunchApp = { onLaunchApp(detail.packageName, detail.appName) },
                onOpenSettings = { onOpenAppSettings(detail.packageName, detail.appName) },
                onRequestUninstall = { onRequestUninstallProposal(detail) }
              )
            }
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(filteredApps, key = { it.packageName }) { app ->
            AppListRow(
              app = app,
              selected = selectedApp?.packageName == app.packageName,
              onClick = { onSelectApp(app.packageName) },
              onLaunchApp = onLaunchApp,
              onOpenAppSettings = onOpenAppSettings,
              onRequestUninstallProposal = onRequestUninstallProposal,
              showInlineActions = true
            )
          }
        }
      }
    }
  }
}

@Composable
private fun AppListRow(
  app: AppDiagnosticInfo,
  selected: Boolean,
  onClick: () -> Unit,
  onLaunchApp: (String, String) -> Unit,
  onOpenAppSettings: (String, String) -> Unit,
  onRequestUninstallProposal: (AppDiagnosticInfo) -> Unit,
  showInlineActions: Boolean
) {
  NexusHudCard(
    selected = selected,
    modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
    contentPadding = 12.dp
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      AppDrawableIcon(drawable = app.iconDrawable, appName = app.appName)
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(text = app.appName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(
          text =
            (if (app.isSystemApp) "מערכת" else "משתמש") +
              " • הרשאות רגישות: ${app.grantedSensitivePermissions.size}",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (app.isDormant) {
          Spacer(modifier = Modifier.height(4.dp))
          Surface(
            color = NexusAmber.copy(alpha = 0.16f),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.45f))
          ) {
            Text(
              text = "רדומה 30+ יום",
              style = MaterialTheme.typography.labelSmall,
              color = NexusAmber,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )
          }
        }
      }
      Column(horizontalAlignment = Alignment.End) {
        Text(text = formatBytes(app.totalSizeBytes), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        app.cacheBytes?.let { cache ->
          Text(text = "מטמון: ${formatBytes(cache)}", style = MaterialTheme.typography.labelSmall, color = NexusAmber)
        }
      }
    }

    if (showInlineActions && selected) {
      Spacer(modifier = Modifier.height(10.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
          onClick = { onLaunchApp(app.packageName, app.appName) },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
        ) {
          Text("פתח")
        }
        OutlinedButton(
          onClick = { onOpenAppSettings(app.packageName, app.appName) },
          modifier = Modifier.weight(1f),
          border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
        ) {
          Text("פרטים", color = MaterialTheme.colorScheme.primary)
        }
        if (!app.isSystemApp) {
          OutlinedButton(
            onClick = { onRequestUninstallProposal(app) },
            modifier = Modifier.weight(1f),
            border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.55f))
          ) {
            Text("הסר", color = NexusCrimson)
          }
        }
      }
    }
  }
}

@Composable
private fun AppDetailPane(
  app: AppDiagnosticInfo,
  hasUsageAccess: Boolean,
  onLaunchApp: () -> Unit,
  onOpenSettings: () -> Unit,
  onRequestUninstall: () -> Unit
) {
  val fmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
  val lastUsedLabel =
    when {
      !hasUsageAccess -> "נדרשת הרשאת נתוני שימוש"
      app.lastTimeUsedMillis != null && app.lastTimeUsedMillis > 0L -> fmt.format(Date(app.lastTimeUsedMillis))
      else -> "לא זוהה שימוש ב-90 הימים האחרונים"
    }
  val fgMinutes = ((app.totalTimeInForegroundMillis ?: 0L) / 60_000L)
  val fgLabel =
    when {
      !hasUsageAccess -> "נדרשת הרשאת נתוני שימוש"
      fgMinutes <= 0L -> "פחות מדקה (90 יום)"
      fgMinutes < 60L -> "$fgMinutes דקות (90 יום)"
      else -> "${fgMinutes / 60L} שעות ו-${fgMinutes % 60L} דקות (90 יום)"
    }
  NexusHudCard(modifier = Modifier.fillMaxSize(), accentColor = if (app.isDormant) NexusAmber else MaterialTheme.colorScheme.primary) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      AppDrawableIcon(drawable = app.iconDrawable, appName = app.appName, sizeDp = 52)
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(app.appName, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
        Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      }
    }
    if (app.isDormant) {
      Spacer(modifier = Modifier.height(8.dp))
      Surface(
        color = NexusAmber.copy(alpha = 0.16f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, NexusAmber.copy(alpha = 0.5f))
      ) {
        Text(
          text = "אפליקציה רדומה (ללא שימוש 30+ יום) — מומלץ לבדוק הסרה או ניקוי בהגדרות המערכת.",
          style = MaterialTheme.typography.labelMedium,
          color = NexusAmber,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(12.dp))
    Text("גרסה: ${app.versionName} • עודכן: ${if (app.lastUpdateTime > 0) fmt.format(Date(app.lastUpdateTime)) else "—"}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text("שימוש אחרון: $lastUsedLabel", style = MaterialTheme.typography.bodyMedium, color = if (app.isDormant) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant)
    Text("זמן פעילות מסך: $fgLabel", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(modifier = Modifier.height(10.dp))
    Text("נפח כולל: ${formatBytes(app.totalSizeBytes)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    Text("קוד APK: ${formatBytes(app.apkSizeBytes)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text("נתונים: ${app.appDataBytes?.let { formatBytes(it) } ?: "נדרשת הרשאת נתוני שימוש"}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text("מטמון: ${app.cacheBytes?.let { formatBytes(it) } ?: "נדרשת הרשאת נתוני שימוש"}", style = MaterialTheme.typography.bodyMedium, color = NexusAmber)

    Spacer(modifier = Modifier.height(12.dp))
    Text("הרשאות רגישות מאושרות (${app.grantedSensitivePermissions.size}):", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    Spacer(modifier = Modifier.height(6.dp))
    if (app.grantedSensitivePermissions.isEmpty()) {
      Text("אין הרשאות רגישות מאושרות.", style = MaterialTheme.typography.bodyMedium, color = NexusEmerald)
    } else {
      LazyColumn(modifier = Modifier.weight(1f)) {
        items(app.grantedSensitivePermissions) { perm ->
          Text("• ${perm.substringAfterLast('.')}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      Button(
        onClick = onLaunchApp,
        modifier = Modifier.weight(1f).testTag("app_detail_launch"),
        colors = ButtonDefaults.buttonColors(containerColor = NexusElectricBlue)
      ) {
        Icon(Icons.AutoMirrored.Rounded.Launch, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("פתח")
      }
      OutlinedButton(
        onClick = onOpenSettings,
        modifier = Modifier.weight(1f).testTag("app_detail_settings"),
        border = BorderStroke(1.dp, NexusBorderGlow.copy(alpha = 0.5f))
      ) {
        Icon(Icons.Rounded.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("פרטים", color = MaterialTheme.colorScheme.primary)
      }
    }
    if (!app.isSystemApp) {
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedButton(
        onClick = onRequestUninstall,
        modifier = Modifier.fillMaxWidth().testTag("app_detail_uninstall"),
        border = BorderStroke(1.dp, NexusCrimson.copy(alpha = 0.6f))
      ) {
        Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = NexusCrimson, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("הסר אפליקציה (שלח לאישור)", color = NexusCrimson)
      }
    }
  }
}

@Composable
private fun AppDrawableIcon(
  drawable: Drawable?,
  appName: String,
  sizeDp: Int = 42
) {
  val bitmap =
    remember(drawable) {
      drawable?.let {
        runCatching { it.toBitmap(width = 96, height = 96).asImageBitmap() }.getOrNull()
      }
    }
  if (bitmap != null) {
    Image(
      bitmap = bitmap,
      contentDescription = appName,
      modifier = Modifier.size(sizeDp.dp)
    )
  } else {
    Box(modifier = Modifier.size(sizeDp.dp))
  }
}
