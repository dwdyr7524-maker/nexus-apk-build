package com.example.ui.screens

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AiOrganizationProposalDraft
import com.example.data.model.ApprovalOperationType
import com.example.data.model.ApprovalRiskLevel
import com.example.data.model.CategoryBreakdown
import com.example.data.model.FileCategory
import com.example.data.model.FileSortMode
import com.example.data.model.ScannedFileEntry
import com.example.data.model.SmartStorageScanReport
import com.example.data.model.StorageVolumeKind
import com.example.data.model.SystemTelemetry
import com.example.data.system.formatBytes
import com.example.ui.components.NexusHudCard
import com.example.ui.theme.NexusAmber
import com.example.ui.theme.NexusCrimson
import com.example.ui.theme.NexusElectricBlue
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusNeonCyan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CATEGORY_COLORS =
  listOf(
    NexusNeonCyan,
    NexusElectricBlue,
    NexusEmerald,
    NexusAmber,
    Color(0xFFA855F7),
    Color(0xFFEC4899),
    NexusCrimson,
    Color(0xFF14B8A6),
    Color(0xFF64748B)
  )

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SmartStorageScreen(
  report: SmartStorageScanReport?,
  telemetry: SystemTelemetry,
  safFolders: Set<String>,
  isScanning: Boolean,
  onRunFullScan: () -> Unit,
  onRequestAddSafFolder: () -> Unit,
  onRemoveSafFolder: (String) -> Unit,
  onStageProposal: (AiOrganizationProposalDraft, Boolean) -> Unit,
  onOpenAiFileManager: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf<FileCategory?>(null) }
  var sortMode by remember { mutableStateOf(FileSortMode.SIZE_DESC) }
  var volumeFilter by remember { mutableStateOf<StorageVolumeKind?>(null) }

  var renameTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var renameText by remember { mutableStateOf("") }
  var createFolderTree by remember { mutableStateOf<String?>(null) }
  var createFolderName by remember { mutableStateOf("") }
  var moveTarget by remember { mutableStateOf<ScannedFileEntry?>(null) }
  var moveDestTree by remember { mutableStateOf<String?>(null) }
  var moveDestSubfolder by remember { mutableStateOf("NEXUS_Moved") }

  val filteredFiles =
    remember(report, searchQuery, selectedCategory, sortMode, volumeFilter) {
      val base = report?.files.orEmpty()
      val q = searchQuery.trim().lowercase()
      val filtered =
        base.filter { file ->
          (selectedCategory == null || file.category == selectedCategory) &&
            (volumeFilter == null || file.volumeKind == volumeFilter) &&
            (q.isEmpty() ||
              file.name.lowercase().contains(q) ||
              file.relativePath.lowercase().contains(q))
        }
      when (sortMode) {
        FileSortMode.SIZE_DESC -> filtered.sortedByDescending { it.sizeBytes }
        FileSortMode.DATE_DESC -> filtered.sortedByDescending { it.lastModifiedMillis }
        FileSortMode.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
        FileSortMode.TYPE -> filtered.sortedBy { it.category.titleHe }
      }
    }

  val sdTreeUris =
    remember(report, safFolders) {
      report?.volumes?.firstOrNull { it.kind == StorageVolumeKind.SD_CARD }?.authorizedTreeUris
        ?: safFolders.filter { !it.contains("primary", ignoreCase = true) }
    }

  LazyColumn(
    modifier = modifier.fillMaxSize().testTag("smart_storage_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Header & Actions
    item {
      NexusHudCard(accentColor = MaterialTheme.colorScheme.primary) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              "מנהל אחסון חכם וכרטיס SD",
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              "פילוח קטגוריות אמיתי, מפת אחסון, חיפוש, מיון וניהול כרטיס זיכרון דרך Storage Access Framework (Android 10).",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = onRunFullScan,
            enabled = !isScanning,
            modifier = Modifier.testTag("smart_storage_scan_btn")
          ) {
            if (isScanning) {
              CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary
              )
            } else {
              Icon(Icons.Rounded.Radar, contentDescription = null)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isScanning) "סורק..." else "סריקת אחסון")
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedButton(
            onClick = onRequestAddSafFolder,
            modifier = Modifier.testTag("smart_storage_add_saf_btn")
          ) {
            Icon(Icons.Rounded.FolderOpen, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("אשר תיקייה / כרטיס SD")
          }
          if (safFolders.isNotEmpty()) {
            OutlinedButton(onClick = { createFolderTree = safFolders.first() }) {
              Icon(Icons.Rounded.CreateNewFolder, contentDescription = null)
              Spacer(modifier = Modifier.width(6.dp))
              Text("צור תיקייה (לאישור)")
            }
          }
        }

        if (safFolders.isNotEmpty()) {
          Spacer(modifier = Modifier.height(8.dp))
          FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            safFolders.forEach { uriStr ->
              val name = Uri.parse(uriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
              AssistChip(
                onClick = { onRemoveSafFolder(uriStr) },
                label = { Text("תיקייה: $name ×", maxLines = 1) }
              )
            }
          }
        }
      }
    }

    // 2. Internal Storage & SD Card Volumes Side-by-Side
    item {
      val volumes = report?.volumes.orEmpty()
      if (volumes.isEmpty()) {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.secondary) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Storage, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              "אחסון פנימי: פנוי ${formatBytes(telemetry.storage.freeBytes)} מתוך ${formatBytes(telemetry.storage.totalBytes)} (${telemetry.storage.usedPercent}% בשימוש)",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(
            progress = { telemetry.storage.usedPercent / 100f },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp))
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            "לחץ על 'סריקת אחסון' ובחר תיקיות (כגון Downloads או כרטיס SD) לסריקה מלאה וזיהוי כרטיס זיכרון.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          volumes.forEach { vol ->
            val isSd = vol.kind == StorageVolumeKind.SD_CARD
            NexusHudCard(
              accentColor =
                when {
                  !vol.isMounted -> MaterialTheme.colorScheme.outline
                  isSd -> NexusEmerald
                  else -> MaterialTheme.colorScheme.primary
                }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    if (isSd) Icons.Rounded.SdStorage else Icons.Rounded.Storage,
                    contentDescription = null,
                    tint = if (isSd) NexusEmerald else MaterialTheme.colorScheme.primary
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(vol.label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                      if (vol.isMounted) "מחובר וזמין • נסרקו ${vol.fileCountScanned} קבצים" else "לא מחובר",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }
                vol.usedPercent?.let { pct ->
                  Text(
                    "$pct%",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (pct >= 85) NexusCrimson else MaterialTheme.colorScheme.primary
                  )
                }
              }

              if (vol.totalBytes != null && vol.freeBytes != null && vol.usedPercent != null) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                  progress = { (vol.usedPercent / 100f).coerceIn(0f, 1f) },
                  modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(6.dp))
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("תפוס: ${formatBytes(vol.usedBytes ?: 0L)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text("פנוי: ${formatBytes(vol.freeBytes)} מתוך ${formatBytes(vol.totalBytes)}", style = MaterialTheme.typography.bodySmall, color = NexusEmerald)
                }
              }

              vol.sdHealthSummaryHe?.let { note ->
                Spacer(modifier = Modifier.height(6.dp))
                Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
            }
          }
        }
      }
    }

    // 3. Smart Storage Map + Category Breakdown + Storage Forecast
    if (report != null && report.categories.isNotEmpty()) {
      item {
        NexusHudCard(accentColor = MaterialTheme.colorScheme.secondary) {
          Text("מפת אחסון חכמה (Smart Storage Map)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
          Spacer(modifier = Modifier.height(8.dp))
          SmartStorageTreemapBar(categories = report.categories)
          Spacer(modifier = Modifier.height(10.dp))
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            report.categories.forEachIndexed { idx, cat ->
              val c = CATEGORY_COLORS[idx % CATEGORY_COLORS.size]
              Surface(
                color = c.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.clickable {
                  selectedCategory = if (selectedCategory == cat.category) null else cat.category
                }
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(modifier = Modifier.size(8.dp).background(c, RoundedCornerShape(4.dp)))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    "${cat.category.titleHe}: ${formatBytes(cat.totalBytes)} (${cat.fileCount})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Rounded.Timeline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                report.forecast.summaryHe,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // 4. Newly large files watcher & Media Integrity Issues
    if (report != null && (report.newlyLargeFiles.isNotEmpty() || report.mediaIssues.isNotEmpty())) {
      item {
        NexusHudCard(accentColor = NexusAmber) {
          Text("מעקב קבצים גדולים ובדיקת תקינות מדיה", style = MaterialTheme.typography.titleMedium, color = NexusAmber)
          if (report.newlyLargeFiles.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              "זוהו ${report.newlyLargeFiles.size} קבצים גדולים חדשים (>=15MB) מאז הסריקה הקודמת:",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface
            )
            report.newlyLargeFiles.take(3).forEach { f ->
              Text("• ${f.name} (${formatBytes(f.sizeBytes)})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
          if (report.mediaIssues.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              "בדיקת Media Inspector מצאה ${report.mediaIssues.size} קובצי תמונה/וידאו פגומים או לא קריאים:",
              style = MaterialTheme.typography.bodySmall,
              color = NexusCrimson
            )
            report.mediaIssues.take(3).forEach { m ->
              Text("• ${m.name}: ${m.reasonHe}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
          }
        }
      }
    }

    // 5. Explorer Tabs
    item {
      Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val tabs = listOf("קבצים וחיפוש (${filteredFiles.size})", "תיקיות ו-SD (${report?.folders?.size ?: 0})", "הורדות, APK וישנים")
        tabs.forEachIndexed { idx, label ->
          FilterChip(
            selected = selectedTab == idx,
            onClick = { selectedTab = idx },
            label = { Text(label) }
          )
        }
        AssistChip(
          onClick = onOpenAiFileManager,
          label = { Text("כפילויות וארגון AI ←") }
        )
      }
    }

    if (selectedTab == 0) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("חפש קובץ לפי שם או נתיב...") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("smart_storage_search")
          )
          Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FileSortMode.entries.forEach { mode ->
              FilterChip(
                selected = sortMode == mode,
                onClick = { sortMode = mode },
                label = { Text(mode.titleHe) }
              )
            }
            FilterChip(
              selected = volumeFilter == StorageVolumeKind.SD_CARD,
              onClick = {
                volumeFilter = if (volumeFilter == StorageVolumeKind.SD_CARD) null else StorageVolumeKind.SD_CARD
              },
              label = { Text("כרטיס SD בלבד") }
            )
          }
        }
      }

      if (filteredFiles.isEmpty()) {
        item {
          NexusHudCard {
            Text(
              if (safFolders.isEmpty())
                "עדיין לא הוענקה הרשאת תיקייה ב-SAF. לחץ למעלה על 'אשר תיקייה / כרטיס SD' כדי לסרוק קבצים."
              else
                "אין קבצים התואמים לחיפוש או לסינון הנוכחי.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      } else {
        items(filteredFiles.take(80), key = { it.uriString }) { file ->
          FileActionCard(
            file = file,
            hasSdTarget = sdTreeUris.isNotEmpty(),
            onRename = {
              renameTarget = file
              renameText = file.name
            },
            onMove = {
              moveTarget = file
              moveDestTree = sdTreeUris.firstOrNull() ?: safFolders.firstOrNull()
              moveDestSubfolder = if (sdTreeUris.isNotEmpty()) "NEXUS_SD_Archive" else "NEXUS_Organized"
            },
            onCopy = {
              val dstTree = sdTreeUris.firstOrNull() ?: file.treeUriString
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "העתקת קובץ: ${file.name}",
                  reasonHe = "בקשת העתקה של ${file.name} (${formatBytes(file.sizeBytes)}).",
                  targetName = file.name,
                  targetLocation = file.relativePath,
                  operationType = ApprovalOperationType.COPY_SAF_DOCUMENT,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "ייווצר עותק נוסף בתיקיית NEXUS_Copy.",
                  sourceUriString = file.uriString,
                  treeUriString = file.treeUriString,
                  destTreeUriString = dstTree,
                  destFolderName = "NEXUS_Copy",
                  bytesAffected = file.sizeBytes
                ),
                false
              )
            },
            onDelete = {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "מחיקת קובץ: ${file.name}",
                  reasonHe = "נבחר למחיקה ממנהל האחסון (${file.category.titleHe}).",
                  targetName = file.name,
                  targetLocation = file.relativePath,
                  operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                  riskLevel = ApprovalRiskLevel.HIGH,
                  isReversible = false,
                  expectedOutcomeHe = "מחיקה מהמכשיר ושחרור ${formatBytes(file.sizeBytes)}.",
                  sourceUriString = file.uriString,
                  treeUriString = file.treeUriString,
                  bytesAffected = file.sizeBytes
                ),
                true
              )
            }
          )
        }
      }
    } else if (selectedTab == 1) {
      val folders = report?.folders.orEmpty()
      if (folders.isEmpty()) {
        item {
          NexusHudCard {
            Text(
              "הרץ סריקת אחסון לאחר בחירת תיקייה או כרטיס SD לצפייה בעץ התיקיות והנפחים.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      } else {
        items(folders.take(60), key = { "${it.treeUriString}_${it.docId}" }) { folder ->
          NexusHudCard(
            accentColor =
              when {
                folder.isEmpty -> NexusAmber
                folder.volumeKind == StorageVolumeKind.SD_CARD -> NexusEmerald
                else -> MaterialTheme.colorScheme.primary
              }
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(folder.folderName, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                Text(
                  "${folder.relativePath} • ${folder.volumeKind.titleHe}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
              Column(horizontalAlignment = Alignment.End) {
                Text(formatBytes(folder.totalBytes), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(
                  if (folder.isEmpty) "תיקייה ריקה" else "${folder.fileCount} קבצים",
                  style = MaterialTheme.typography.labelSmall,
                  color = if (folder.isEmpty) NexusAmber else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            if (folder.isEmpty) {
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedButton(
                onClick = {
                  onStageProposal(
                    AiOrganizationProposalDraft(
                      title = "מחיקת תיקייה ריקה: ${folder.folderName}",
                      reasonHe = "תיקייה ללא תוכן שנסרקה בעץ התיקיות.",
                      targetName = folder.folderName,
                      targetLocation = folder.relativePath,
                      operationType = ApprovalOperationType.DELETE_SAF_DOCUMENT,
                      riskLevel = ApprovalRiskLevel.LOW,
                      isReversible = false,
                      expectedOutcomeHe = "הסרת התיקייה הריקה בלבד.",
                      sourceUriString =
                        android.provider.DocumentsContract.buildDocumentUriUsingTree(
                          Uri.parse(folder.treeUriString),
                          folder.docId
                        ).toString(),
                      treeUriString = folder.treeUriString,
                      bytesAffected = 0L
                    ),
                    false
                  )
                }
              ) {
                Text("שלח תיקייה ריקה למרכז האישורים")
              }
            }
          }
        }
      }
    } else {
      val timelineAndSpecial =
        report?.files
          ?.filter { it.isOldUnused || it.isInstallerApk || it.isLargeFile || it.isTempResidual || it.isBackupArchive }
          ?.sortedByDescending { it.lastModifiedMillis }
          .orEmpty()
      if (timelineAndSpecial.isEmpty()) {
        item {
          NexusHudCard {
            Text(
              "לא אותרו קבצי APK, קבצים ישנים (>90 יום), או קבצים גדולים בתיקיות שנסרקו.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      } else {
        items(timelineAndSpecial.take(50), key = { "spec_${it.uriString}" }) { f ->
          val tag =
            when {
              f.isInstallerApk -> "APK התקנה"
              f.isTempResidual -> "קובץ זמני"
              f.isBackupArchive -> "גיבוי"
              f.isLargeFile -> "גדול מאוד"
              else -> "לא שונה >90 יום"
            }
          val dateStr =
            if (f.lastModifiedMillis > 0)
              SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(f.lastModifiedMillis))
            else "—"
          NexusHudCard(accentColor = NexusAmber) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Column(modifier = Modifier.weight(1f)) {
                Text(f.name, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                Text("$tag • תאריך: $dateStr • ${f.relativePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              }
              Text(formatBytes(f.sizeBytes), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }
  }

  // Rename -> Approval Center dialog
  renameTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { renameTarget = null },
      title = { Text("שינוי שם (יישלח לאישור)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("שם נוכחי: ${target.name}", style = MaterialTheme.typography.bodySmall)
          OutlinedTextField(
            value = renameText,
            onValueChange = { renameText = it },
            label = { Text("שם חדש כולל סיומת") },
            singleLine = true
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (renameText.isNotBlank() && renameText != target.name) {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "שינוי שם: ${target.name} ← $renameText",
                  reasonHe = "שינוי שם יזום על ידי המשתמש במנהל האחסון.",
                  targetName = target.name,
                  targetLocation = target.relativePath,
                  operationType = ApprovalOperationType.RENAME_SAF_DOCUMENT,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "שינוי שם הקובץ ל-$renameText (הפיך דרך מרכז הביטול).",
                  sourceUriString = target.uriString,
                  treeUriString = target.treeUriString,
                  proposedNewName = renameText.trim(),
                  bytesAffected = target.sizeBytes
                ),
                true
              )
            }
            renameTarget = null
          }
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { renameTarget = null }) { Text("ביטול") }
      }
    )
  }

  // Create Folder -> Approval Center dialog
  createFolderTree?.let { treeStr ->
    AlertDialog(
      onDismissRequest = { createFolderTree = null },
      title = { Text("יצירת תיקייה חדשה (יישלח לאישור)") },
      text = {
        OutlinedTextField(
          value = createFolderName,
          onValueChange = { createFolderName = it },
          label = { Text("שם התיקייה החדשה") },
          singleLine = true
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val clean = createFolderName.trim()
            if (clean.isNotEmpty()) {
              onStageProposal(
                AiOrganizationProposalDraft(
                  title = "יצירת תיקייה: $clean",
                  reasonHe = "יצירת תיקייה חדשה בתיקיית השורש המאושרת.",
                  targetName = clean,
                  targetLocation = Uri.parse(treeStr).lastPathSegment ?: "תיקייה מאושרת",
                  operationType = ApprovalOperationType.CREATE_SAF_FOLDER,
                  riskLevel = ApprovalRiskLevel.LOW,
                  isReversible = true,
                  expectedOutcomeHe = "תיקייה חדשה '$clean' תיווצר בשורש התיקייה.",
                  treeUriString = treeStr,
                  destFolderName = clean,
                  bytesAffected = 0L
                ),
                true
              )
            }
            createFolderName = ""
            createFolderTree = null
          }
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { createFolderTree = null }) { Text("ביטול") }
      }
    )
  }

  // Move -> Approval Center dialog
  moveTarget?.let { target ->
    AlertDialog(
      onDismissRequest = { moveTarget = null },
      title = { Text("העברת קובץ (יישלח לאישור)") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("קובץ: ${target.name} (${formatBytes(target.sizeBytes)})", style = MaterialTheme.typography.bodySmall)
          OutlinedTextField(
            value = moveDestSubfolder,
            onValueChange = { moveDestSubfolder = it },
            label = { Text("שם תת-תיקיית יעד") },
            singleLine = true
          )
          if (safFolders.size > 1) {
            Text("בחר עץ יעד (כולל SD אם אושר):", style = MaterialTheme.typography.labelSmall)
            safFolders.forEach { treeUriStr ->
              val label = Uri.parse(treeUriStr).lastPathSegment?.substringAfterLast(':') ?: "תיקייה"
              FilterChip(
                selected = moveDestTree == treeUriStr,
                onClick = { moveDestTree = treeUriStr },
                label = { Text(label) }
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val dest = moveDestTree ?: target.treeUriString
            onStageProposal(
              AiOrganizationProposalDraft(
                title = "העברת קובץ: ${target.name}",
                reasonHe = "העברה לתת-תיקייה '$moveDestSubfolder' עם אימות שלמות SHA-256.",
                targetName = target.name,
                targetLocation = "${target.relativePath} ← $moveDestSubfolder",
                operationType = ApprovalOperationType.MOVE_SAF_DOCUMENT,
                riskLevel = ApprovalRiskLevel.MEDIUM,
                isReversible = true,
                expectedOutcomeHe = "העברה בטוחה ללא מחיקת המקור לפני אימות ההעתקה.",
                sourceUriString = target.uriString,
                treeUriString = target.treeUriString,
                destTreeUriString = dest,
                destFolderName = moveDestSubfolder.trim().ifBlank { "NEXUS_Moved" },
                bytesAffected = target.sizeBytes
              ),
              true
            )
            moveTarget = null
          }
        ) {
          Text("שלח למרכז האישורים")
        }
      },
      dismissButton = {
        TextButton(onClick = { moveTarget = null }) { Text("ביטול") }
      }
    )
  }
}

@Composable
private fun SmartStorageTreemapBar(categories: List<CategoryBreakdown>) {
  val total = categories.sumOf { it.totalBytes }.coerceAtLeast(1L).toFloat()
  Canvas(
    modifier =
      Modifier
        .fillMaxWidth()
        .height(26.dp)
        .clip(RoundedCornerShape(10.dp))
  ) {
    var curX = 0f
    categories.forEachIndexed { idx, cat ->
      val frac = (cat.totalBytes.toFloat() / total).coerceAtLeast(0.02f)
      val w = (size.width * frac).coerceAtMost(size.width - curX)
      if (w > 1f) {
        drawRoundRect(
          color = CATEGORY_COLORS[idx % CATEGORY_COLORS.size],
          topLeft = Offset(curX, 0f),
          size = Size(w - 2f, size.height),
          cornerRadius = CornerRadius(6f, 6f)
        )
        curX += w
      }
    }
  }
}

@Composable
private fun FileActionCard(
  file: ScannedFileEntry,
  hasSdTarget: Boolean,
  onRename: () -> Unit,
  onMove: () -> Unit,
  onCopy: () -> Unit,
  onDelete: () -> Unit
) {
  NexusHudCard(
    accentColor =
      if (file.volumeKind == StorageVolumeKind.SD_CARD) NexusEmerald
      else MaterialTheme.colorScheme.outline
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          file.name,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          "${file.category.titleHe} • ${file.volumeKind.titleHe} • ${file.relativePath}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        formatBytes(file.sizeBytes),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary
      )
    }
    Spacer(modifier = Modifier.height(6.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.End)
    ) {
      IconButton(onClick = onRename, modifier = Modifier.size(40.dp)) {
        Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = "שנה שם", tint = MaterialTheme.colorScheme.primary)
      }
      IconButton(onClick = onMove, modifier = Modifier.size(40.dp)) {
        Icon(
          Icons.Rounded.DriveFileMove,
          contentDescription = if (hasSdTarget) "העבר ל-SD/תיקייה" else "העבר לתיקייה",
          tint = NexusEmerald
        )
      }
      IconButton(onClick = onCopy, modifier = Modifier.size(40.dp)) {
        Icon(Icons.Rounded.FileCopy, contentDescription = "העתק", tint = MaterialTheme.colorScheme.secondary)
      }
      IconButton(onClick = onDelete, modifier = Modifier.size(40.dp)) {
        Icon(Icons.Rounded.DeleteOutline, contentDescription = "מחק (לאישור)", tint = NexusCrimson)
      }
    }
  }
}
