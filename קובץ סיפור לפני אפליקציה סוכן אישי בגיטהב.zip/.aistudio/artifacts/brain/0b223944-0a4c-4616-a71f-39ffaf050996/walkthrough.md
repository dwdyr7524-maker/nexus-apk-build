# Security Summary & AI Audit Verification

## AI & API Security Audit Findings & Fixes Applied
1. **Model Routing & Paid Tier Guard (`NexusAiSecurityAndRouting.kt`, `FirebaseNexusAiProvider.kt`)**:
   - Enforced free-tier fallback chains (`gemini-3.8-flash` -> `gemini-3.5-flash-lite` for reasoning/vision; `gemini-3.5-transcribe` -> `gemini-3.8-flash` -> `gemini-3.5-flash-lite` for audio transcription).
   - Explicitly blocked paid/Blaze-only models (`gemini-4-argon`, `gemini-nano-banana-2.1`, `gemini-3-pro-image`) in `ModelRoutingPolicy.fallbackChainFor(..., allowPaidAutoFallback = false)` and flagged `gemini-4-argon` as `BLOCKED_PAID_TIER` in diagnostics.
2. **Prompt Injection, Hallucinated Execution & Output Guards (`NexusAiSecurityGuard`, `FirebaseNexusAiProvider.kt`)**:
   - Neutralized control chars, XML boundary tags (`<system>`, `<device_context>`, `<untrusted_user_input>`), and English/Hebrew injection patterns in user prompts and device/folder/app labels.
   - Forced `requiresConfirmation = true` on mutating/settings assistant actions (`REQUEST_START_CLEAN`, `OPEN_*_SETTINGS`, `RUN_AUTOMATION`, `STAGE_*_PROPOSALS`).
   - Added blank/punctuation-only output rejection, `AIza...` secret string redaction, and explicit NEXUS system disclaimer if a model claims unperformed execution (`מחקתי בפועל`, `ניקיתי כבר`, etc.).
3. **Conversation Context & Rate Limiting (`NexusAiHistorySanitizer`, `NexusAiRateLimiter`, `NexusViewModel.kt`)**:
   - Fixed duplicate/ordering bug in `NexusViewModel.sendAssistantCommand`: snapshots recent history (`getRecentOnce(10)`) BEFORE inserting the new user message, and normalizes alternating `user -> model` turns ending on a `model` reply for `startChat(history)`.
   - Added sliding-window rate limiter (`12 req / 60s`), `800ms` burst guard, `12s` 429 quota cooldown backoff, and `AtomicBoolean` concurrency guards (`isAssistantRequestInFlight`, `isAudioTranscribeInFlight`).
   - Added scan signature caching (`lastInsightsSignature`) in `CommanderDelegate.runFullDeviceScan` to prevent redundant AI insights calls when storage scan results are unchanged or re-scanned post-approval/undo.
4. **App Check & Release Configuration Note**:
   - `AppCheckHelper.kt` uses `DebugAppCheckProviderFactory` for debug builds; release builds look up `@string/recaptcha_site_key` in `strings.xml`, which is intentionally absent so no key is hardcoded. Release distribution requires configuring a real reCAPTCHA site key.
5. **Play Policy & Permissions**:
   - Verified `AndroidManifest.xml` uses zero broad storage permissions (`READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE`, `READ_MEDIA_*`, `MANAGE_EXTERNAL_STORAGE`, `REQUEST_DELETE_PACKAGES`, `QUERY_ALL_PACKAGES`), relying on SAF (`OpenDocumentTree`), Photo Picker (`PickVisualMedia`), and official `PackageInstaller`/`Settings` intents.

## PoC Verification
- `compile_applet`: **Build succeeded** (verified after all Kotlin & UI updates including `MainActivity.kt`, Commander screens, `FirebaseNexusAiProvider.kt`, and Light/Dark Material 3 theme support).
- `gradle :app:testDebugUnitTest --tests "com.example.NexusPureUnitTests" --tests "com.example.NexusStage2ModelTests" --tests "com.example.CommanderEngineTests"`:
  - `CommanderEngineTests`: 10 passed, 0 failed, 0 skipped
  - `NexusPureUnitTests`: 7 passed, 0 failed, 0 skipped
  - `NexusStage2ModelTests`: 1 passed, 0 failed, 0 skipped
- **Environment Limitation**: Live Firebase AI cloud inference (`gemini-3.8-flash`, `gemini-3.5-flash-lite`, `gemini-3.5-transcribe`, `gemini-3.8-live`) and App Check server handshake require running on an Android device/emulator with internet access (no ADB/emulator in build container).
